<?php

	/**
	* Cac setting cho website
	*/

	$setting['contestphoto']['imageDirectory'] = 'uploads/contestphoto/vn/';
	$setting['contestphoto']['imageThumb1Width'] = '800';
	$setting['contestphoto']['imageThumb1Height'] = '600';
	$setting['contestphoto']['imageThumb2Width'] = '250';
	$setting['contestphoto']['imageThumb2Height'] = '250';
	$setting['contestphoto']['imageQuality'] = '100';
	$setting['contestphoto']['validType'] = array('JPG', 'JPEG');
	$setting['contestphoto']['maxFileSize'] = 10*1024*1024;	//10 MB
	$setting['contestphoto']['minWidth'] = 1024;	//in pixel
	$setting['contestphoto']['minHeight'] = 500;	//in pixel
    $setting['contestphoto']['maxPhotoPerSection'] = 4;    //so hinh toi da 1 user duoc upload cho 1 section
	$setting['contestphoto']['maxPhotoPerSubSection'] = 1;	//so hinh toi da 1 user duoc upload cho 1 subsection
	
?>
