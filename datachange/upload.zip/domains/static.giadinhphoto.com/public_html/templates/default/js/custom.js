function placeHolder(element){
	var standard_message = $(element).val();
	$(element).focus(
		function() {
			if ($(this).val() == standard_message)
				$(this).val("");
		}
	);
	$(element).blur(
		function() {
			if ($(this).val() == "")
				$(this).val(standard_message);
		}
	);
}

jQuery(function(){	
	jQuery('.fnav li:last-child').addClass('last');
	
	jQuery(".search input[type='text']").each(function(index, element) {
		  placeHolder(jQuery(this));     
	});
	
	jQuery('#tab-content .block-item:first-child').show();
	jQuery(".tab-list li").click(function(){
		if(jQuery(this).hasClass("active")){return false;}
		jQuery(".tab-list li").removeClass("active");
		jQuery(this).addClass("active");
		var index = jQuery(".tab-list li").index(jQuery(this));
		jQuery("#tab-content .block-item").hide(0);
		jQuery("#tab-content .block-item").eq(index).fadeIn(300);						
		
		return false;
	})
})


