<?php /* Smarty version 2.6.26, created on 2010-06-30 21:21:45
         compiled from _controller/site/entrysharebookmark.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', '_controller/site/entrysharebookmark.tpl', 5, false),array('modifier', 'strip_tags', '_controller/site/entrysharebookmark.tpl', 7, false),array('modifier', 'truncate', '_controller/site/entrysharebookmark.tpl', 7, false),)), $this); ?>

<div id="share-bookmark">
	<div class="title"><?php echo $this->_tpl_vars['lang']['controllergroup']['bookmarkTitle']; ?>
</div>
	<div class="icon">
		<a href="http://www.facebook.com/share.php?u=<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
&amp;t=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
" title="Share on Facebook"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/facebook.png" alt="facebook" /></a>
		<a href="http://twitter.com/home?status=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
-<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
" title="Tweet This!"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/twitter.png" alt="twitter" /></a>
		<a href="http://delicious.com/post?url=<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
&amp;title=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
&amp;notes=<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['myEntry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 400, '..') : smarty_modifier_truncate($_tmp, 400, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
" title="Bookmark on Del.icio.us"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/delicious.png" alt="delicious" /></a>
		<a href="http://buzz.yahoo.com/buzz?targetUrl=<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
&amp;headline=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
&amp;summary=<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['myEntry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 400, '..') : smarty_modifier_truncate($_tmp, 400, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
&amp;category=lifestyle&amp;assetType=text" title="Yahoo Buzz Up"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/yahoo.png" alt="yahoo-buzz" /></a>
		
		<a href="http://www.google.com/reader/link?url=<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
&amp;title=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
&amp;srcURL=<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
" title="Submit on Google Buzz"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/google.png" alt="google-buzz" /></a>
		<a href="http://digg.com/submit?phase=2&amp;url=<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
&amp;title=<?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'url') : smarty_modifier_escape($_tmp, 'url')); ?>
" title="Digg this!"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bookmark/digg.png" alt="digg" /></a>
	</div>
</div>