<?php /* Smarty version 2.6.26, created on 2010-07-15 22:52:39
         compiled from _controller/site/entryphotoalbum/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entryphotoalbum/index.tpl', 18, false),array('modifier', 'strip_tags', '_controller/site/entryphotoalbum/index.tpl', 29, false),array('modifier', 'truncate', '_controller/site/entryphotoalbum/index.tpl', 29, false),array('modifier', 'escape', '_controller/site/entryphotoalbum/index.tpl', 29, false),array('modifier', 'date_format', '_controller/site/entryphotoalbum/index.tpl', 36, false),array('modifier', 'relative_datetime', '_controller/site/entryphotoalbum/index.tpl', 36, false),array('function', 'paginate', '_controller/site/entryphotoalbum/index.tpl', 57, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div id="content-wide">
	<div id="heading">
		<h1><?php echo $this->_tpl_vars['myCategory']->name; ?>
<?php if ($this->_tpl_vars['parentCategory']->id == 0): ?>
		<span>
		<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][41]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoCelebration']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoCelebration']; ?>
</a> &middot;
		<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][42]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoWedding']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoWedding']; ?>
</a> &middot;
		<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][43]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoTravel']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoTravel']; ?>
</a> &middot;
		<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][44]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoBaby']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoBaby']; ?>
</a> &middot;
		<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][45]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoWallpaper']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoWallpaper']; ?>
</a>
		</span>
		<?php endif; ?></h1>
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysortbar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	</div>
	<div id="page-content">
		<div id="entry-listing">
			<?php if (count($this->_tpl_vars['entries']) > 0): ?>
				<div class="entry-post entryphotoalbum-post">
				<table cellpadding="0" cellspacing="0">
					<tr>
					<?php $this->assign('index', 1); ?>
						<?php $_from = $this->_tpl_vars['entries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['entrylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['entrylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['entry']):
        $this->_foreach['entrylist']['iteration']++;
?>
						<td width="140" align="center" valign="middle" class="image">
							<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/nophotoalbum-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" class="<?php echo $this->_tpl_vars['entry']->getImageDirection(); ?>
" /></a>
						</td>
						<td width="200" align="left">
							<div class="more">
								<h3 class="title"><?php if ($this->_tpl_vars['entry']->commentCount > 0): ?><div class="commentscloud" title="<?php echo $this->_tpl_vars['entry']->commentCount; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
#commentbox" title="<?php echo $this->_tpl_vars['entry']->title; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><?php echo $this->_tpl_vars['entry']->commentCount; ?>
</a></div><?php endif; ?><a class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a></h3>
								<div class="rating">
									<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
								</div>
								
								
								<div class="poster">
									&raquo; <strong><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['entry']->username; ?>
" class="username" title="<?php echo $this->_tpl_vars['entry']->username; ?>
"><?php echo $this->_tpl_vars['entry']->username; ?>
</a></strong> <?php echo $this->_tpl_vars['lang']['controllergroup']['entryPost']; ?>
 <span title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentPostAt']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat'])); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span></span>
								</div>
								
								<div>&raquo; <span><?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewLabel']; ?>
 : <?php echo $this->_tpl_vars['entry']->view; ?>
</span></div>
							
							</div>
							
							<?php if ($this->_tpl_vars['entry']->canModify()): ?>
							<div class="action">
								<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
/edit" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditLabel']; ?>
</a> |
								<a href="javascript:delm('<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
/delete<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>?token=<?php echo $_SESSION['securityToken']; ?>
')" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
</a>
							</div>
							<?php endif; ?>	
						</td><?php if ($this->_tpl_vars['index'] == 2): ?></tr><tr><?php $this->assign('index', 0); ?><?php endif; ?>
							<?php $this->assign('index', $this->_tpl_vars['index']+1); ?>
						
					<?php endforeach; endif; unset($_from); ?>
					</tr>
				</table>
				</div>
				<?php $this->assign('pageurl', "trang-::PAGE::"); ?>
				<?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

			<?php else: ?>
				<div id="entry-listing-empty"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryListingEmpty']; ?>
</div>
			<?php endif; ?>
		</div><!-- end of #entry-listing -->
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryotherbox.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


<div class="footer-banner">
	<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/footer-photoalbum.jpg" alt="footer photoalbum" />
</div>

