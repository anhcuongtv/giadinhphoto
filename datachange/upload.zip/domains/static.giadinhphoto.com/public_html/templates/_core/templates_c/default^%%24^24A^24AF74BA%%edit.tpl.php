<?php /* Smarty version 2.6.26, created on 2010-07-10 10:37:37
         compiled from _controller/site/entrymovie/edit.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['headingPrefixEdit']; ?>
 <?php if ($this->_tpl_vars['formData']['parentCategory']->id > 0): ?><em>"<?php echo $this->_tpl_vars['formData']['myCategory']->name; ?>
"</em><?php endif; ?></h1></div>
	<div id="page-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<div id="mainform-form">
			<form action="" method="post" enctype="multipart/form-data">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['entryEditToken']; ?>
" />
			
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditBtn']; ?>
" />
					
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['titleLabel']; ?>
 :</label></div>
					<div class="form-entry-big-textbox"><input class="entry-textbox-long" type="text" id="ftitle" name="ftitle" value="<?php echo $this->_tpl_vars['formData']['ftitle']; ?>
" /></div>
				</div>
				

				<div class="form-entry" style="display:none;">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCategory']; ?>
 :</label></div>
					<div>
						<select class="entry-selectbox" id="fcategoryidentifier" name="fcategoryidentifier">
							<option value="phim-dvd" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'phim-dvd'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mMovieFilm']; ?>
</option>
						</select>
					</div>
				</div>
				
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['durationLabel']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="entry-textbox-tiny" type="text" id="fduration" name="fduration" value="<?php echo $this->_tpl_vars['formData']['fduration']; ?>
" /></div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['yearLabel']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="entry-textbox-tiny" type="text" id="fyear" name="fyear" value="<?php echo $this->_tpl_vars['formData']['fyear']; ?>
" /></div>
				</div>
				
				<?php if ($this->_tpl_vars['formData']['fimage'] != ''): ?>
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div>
							<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" target="_blank"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" width="100" border="0" /></a><input type="checkbox" name="fdeleteimage" value="1" /><?php echo $this->_tpl_vars['lang']['controller']['formImageDeleteLabel']; ?>

						</div>
				</div>
				<?php endif; ?>
				
				
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryImage']; ?>
 :</label></div>
					<div class="form-entry-textbox">
						
						<input type="file" id="fimage" name="fimage" />
					</div>
				</div>
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryslideshowform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['descriptionLabel']; ?>
 :</label></div>
					<div class="form-entry-input">
						<textarea name="fdescription" class="entry-textarea disablefocusfx wysiwyg" rows="10"><?php echo $this->_tpl_vars['myEntry']->description; ?>
</textarea><br />
					</div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryTag']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryTagTooltip']; ?>
" type="text" id="ftag" name="ftag" value="<?php echo $this->_tpl_vars['formData']['ftag']; ?>
" /></div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['websiteLabel']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="entry-textbox-short" type="text" id="fwebsite" name="fwebsite" value="<?php echo $this->_tpl_vars['formData']['fwebsite']; ?>
" /></div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['embedcodeLabel']; ?>
 :</label></div>
					<div class="form-entry-textbox"><textarea name="fembedcode" class="entry-textarea disablefocusfx" rows="5"><?php echo $this->_tpl_vars['formData']['fembedcode']; ?>
</textarea><br /></div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelated']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelatedTooltip']; ?>
 <?php echo $this->_tpl_vars['setting']['entry']['maxRelatedNumber']; ?>
)" type="text" id="frelated" name="frelated" value="<?php echo $this->_tpl_vars['formData']['frelated']; ?>
" /></div>
				</div>
				
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryseoform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrymoderatorform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				

				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditBtn']; ?>
" />
					<div class="form-entry-delete-link"><a href="javascript:delm('<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/delete<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>?token=<?php echo $_SESSION['securityToken']; ?>
')"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
</a></div>
				</div>
				
				<div class="clearboth"></div>
				
				</div>
				
			</form>
		</div><!-- end of .mainform-form -->
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


