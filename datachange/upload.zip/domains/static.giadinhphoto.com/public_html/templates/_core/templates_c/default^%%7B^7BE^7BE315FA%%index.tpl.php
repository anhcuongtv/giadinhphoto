<?php /* Smarty version 2.6.26, created on 2010-07-15 21:18:41
         compiled from _controller/site/sitemap/index.tpl */ ?>

<div id="content-full">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</h1></div>
	<div id="page-content">
		<div>
			<ul class="sitemap">
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
" title="<?php echo $this->_tpl_vars['lang']['global']['mHomepage']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mHomepage']; ?>
</a></li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['quiz']['seoUrl']; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mQuiz']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mQuiz']; ?>
</a></li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlace']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlace']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][11]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlaceEat']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlaceEat']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][12]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlacePlay']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlacePlay']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][13]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlaceTravel']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlaceTravel']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][14]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlacePhoto']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlacePhoto']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][1]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][15]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPlaceShopping']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPlaceShopping']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][2]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mMovie']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mMovie']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][2]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][21]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mMovieFilm']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mMovieFilm']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][3]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mMusic']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mMusic']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][3]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][31]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mMusicMp3']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mMusicMp3']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][3]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][32]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mMusicClip']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mMusicClip']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhoto']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhoto']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][41]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoCelebration']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoCelebration']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][42]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoWedding']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoWedding']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][43]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoTravel']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoTravel']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][44]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoBaby']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoBaby']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][4]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][45]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mPhotoWallpaper']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mPhotoWallpaper']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][6]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mLovestory']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLovestory']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][6]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][61]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mLovestoryBeginning']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLovestoryBeginning']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][6]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][62]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mLovestoryDeep']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLovestoryDeep']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][6]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][63]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mLovestorySad']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLovestorySad']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][6]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][64]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mLovestorySelf']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLovestorySelf']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJoke']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJoke']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][71]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJokeWork']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJokeWork']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][72]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJokeFamily']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJokeFamily']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][73]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJokeSchool']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJokeSchool']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][74]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJokeLoveFamily']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJokeLoveFamily']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][7]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][74]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mJokeOther']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mJokeOther']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][8]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mBook']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mBook']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][8]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][81]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mBookForeign']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mBookForeign']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][8]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][82]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mBookNation']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mBookNation']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticle']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticle']; ?>
</a>
					<ul>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][91]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticleRomance']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticleRomance']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][92]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticleBeaty']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticleBeaty']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][93]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticleHealthy']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticleHealthy']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][94]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticleFamily']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticleFamily']; ?>
</a>
						<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][9]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][95]; ?>
/" title="<?php echo $this->_tpl_vars['lang']['global']['mArticleCook']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mArticleCook']; ?>
</a>
					</ul>
				</li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html" title="<?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
</a></li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
tos.html" title="<?php echo $this->_tpl_vars['lang']['global']['mTos']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mTos']; ?>
</a></li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
sitemap.html" title="<?php echo $this->_tpl_vars['lang']['global']['mSitemap']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mSitemap']; ?>
</a></li>
				<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
contact.html" title="<?php echo $this->_tpl_vars['lang']['global']['mContact']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mContact']; ?>
</a></li>
			</ul>
			
		</div>
	</div>	
	
</div><!-- end of #content -->