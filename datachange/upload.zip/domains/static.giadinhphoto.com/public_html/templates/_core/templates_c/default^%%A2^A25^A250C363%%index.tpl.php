<?php /* Smarty version 2.6.26, created on 2010-07-30 11:14:06
         compiled from _controller/admin/banner/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/admin/banner/index.tpl', 32, false),array('modifier', 'date_format', '_controller/admin/banner/index.tpl', 91, false),array('modifier', 'htmlspecialchars', '_controller/admin/banner/index.tpl', 118, false),array('function', 'paginate', '_controller/admin/banner/index.tpl', 62, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_list']; ?>
</h2>
<div id="page-intro"><?php echo $this->_tpl_vars['lang']['controller']['intro_list']; ?>
</div>




<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_list']; ?>
 <?php if ($this->_tpl_vars['formData']['search'] != ''): ?>| <?php echo $this->_tpl_vars['lang']['controller']['title_listSearch']; ?>
 <?php endif; ?>(<?php echo $this->_tpl_vars['total']; ?>
)</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['tableTabLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controllergroup']['filterLabel']; ?>
</a></li>
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
banner/add/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['title_add']; ?>
</a></li>
		</ul>
		<?php if ($this->_tpl_vars['formData']['search'] != ''): ?>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
banner"><?php echo $this->_tpl_vars['lang']['controllergroup']['formViewAll']; ?>
</a></li>
		</ul>
		<?php endif; ?>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			<form action="" method="post" name="manage" onsubmit="return confirm('Are You Sure ?');">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['bannerDeleteToken']; ?>
" />
				<table class="grid">
					
				<?php if (count($this->_tpl_vars['banners']) > 0): ?>
					<thead>
						<tr>
						   <th width="40"><input class="check-all" type="checkbox" /></th>
							<th width="30"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</th>
							<th width="50"><?php echo $this->_tpl_vars['lang']['controllergroup']['formOrderLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formNameLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formPositionLabel']; ?>
</th>
							<th width="100" class="td_center"><?php echo $this->_tpl_vars['lang']['controller']['formEnableLabel']; ?>
</th>
							<th width="50"><?php echo $this->_tpl_vars['lang']['controller']['formSizeLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formSourceLabel']; ?>
</th>							
							<th width="120"><?php echo $this->_tpl_vars['lang']['controller']['formDatecreatedLabel']; ?>
</th>
							<th width="70"></th>
						</tr>
					</thead>
					
					<tfoot>
						<tr>
							<td colspan="8">
								<div class="bulk-actions align-left">
									<select name="fbulkaction">
										<option value=""><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSelectLabel']; ?>
</option>
										<option value="delete"><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionDeletetLabel']; ?>
</option>
									</select>
									<input type="submit" name="fsubmitbulk" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSubmit']; ?>
" />
									<input type="submit" name="fchangeorder" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formChangeOrderSubmit']; ?>
" />
								</div>
								
								<div class="pagination">
								   <?php $this->assign('pageurl', "page/::PAGE::"); ?>
									<?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

								</div> <!-- End .pagination -->
		
								<div class="clear"></div>
							</td>
						</tr>
					</tfoot>
					<tbody>
					<?php $_from = $this->_tpl_vars['banners']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['banner']):
?>
					
						<tr>
							<td><input type="checkbox" name="fbulkid[]" value="<?php echo $this->_tpl_vars['banner']->id; ?>
" <?php if (in_array ( $this->_tpl_vars['banner']->id , $this->_tpl_vars['formData']['fbulkid'] )): ?>checked="checked"<?php endif; ?>/></td>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['banner']->id; ?>
</td>
							<td><input type="text" size="3" value="<?php echo $this->_tpl_vars['banner']->order; ?>
" name="forder[<?php echo $this->_tpl_vars['banner']->id; ?>
]" class="text-input" /></td>
							<td><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
banner/edit/id/<?php echo $this->_tpl_vars['banner']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" title="<?php echo $this->_tpl_vars['banner']->link; ?>
"><?php echo $this->_tpl_vars['banner']->name; ?>
</a></td>
							<td><?php echo $this->_tpl_vars['banner']->position->name; ?>
</td>
							<td class="td_center"><?php if ($this->_tpl_vars['banner']->enable == 1): ?><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/tick_circle.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formYesLabel']; ?>
" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formYesLabel']; ?>
" width="16"/><?php else: ?><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross_circle.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formNoLabel']; ?>
" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formNoLabel']; ?>
" width="16"/><?php endif; ?></td>
							<td><?php echo $this->_tpl_vars['banner']->width; ?>
x<?php if ($this->_tpl_vars['banner']->height > 0): ?><?php echo $this->_tpl_vars['banner']->height; ?>
<?php else: ?>...<?php endif; ?></td>
							<td>
								<?php if ($this->_tpl_vars['banner']->extension == 'SWF'): ?>
									<object data="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['banner']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['banner']->source; ?>
"  type="application/x-shockwave-flash" width="<?php echo $this->_tpl_vars['banner']->width; ?>
" height="<?php if ($this->_tpl_vars['banner']->height > 0): ?><?php echo $this->_tpl_vars['banner']->height; ?>
<?php else: ?>100<?php endif; ?>">
										<param name="movie" value="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['banner']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['banner']->source; ?>
"/>
									</object>
								<?php else: ?>
									<a href="<?php echo $this->_tpl_vars['banner']->link; ?>
" title="<?php echo $this->_tpl_vars['banner']->link; ?>
">
										<img style="border:1px solid #999999;" alt="<?php echo $this->_tpl_vars['banner']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['banner']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['banner']->source; ?>
" width="<?php echo $this->_tpl_vars['banner']->width; ?>
" <?php if ($this->_tpl_vars['banner']->height > 0): ?> height="<?php echo $this->_tpl_vars['banner']->height; ?>
" <?php endif; ?>/>
									</a>
								<?php endif; ?>	
							</td>
							<td><?php echo ((is_array($_tmp=$this->_tpl_vars['banner']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatSmarty'])); ?>
</td>
							<td><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
banner/edit/id/<?php echo $this->_tpl_vars['banner']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
								<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
banner/delete/id/<?php echo $this->_tpl_vars['banner']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
?token=<?php echo $_SESSION['securityToken']; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a>
							</td>
						</tr>
						
					
					<?php endforeach; endif; unset($_from); ?>
					</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="10"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
			
		</div>
			
			
		<div class="tab-content" id="tab2">
			<form action="" method="post" style="padding:0px;margin:0px;" onsubmit="return false;">
	
				<?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
: 
				<input type="text" name="fid" id="fid" size="8" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fid']); ?>
" class="text-input" /> - 
				<?php echo $this->_tpl_vars['lang']['controller']['formKeywordLabel']; ?>
:
				
					<input type="text" name="fkeyword" id="fkeyword" size="20" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fkeyword']); ?>
" class="text-input" /><select name="fsearchin" id="fsearchin">
						<option value="">- - - - - - - - - - - - -</option>
						<option value="name" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'name'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInNameLabel']; ?>
</option>
						
					</select>
					-
				
				<?php echo $this->_tpl_vars['lang']['controller']['formPositionLabel']; ?>
:
				
					<select name="fposition" id="fposition">
						<option value="0">- - - - - - - - - - - - - - - - - - -</option>
						<?php $_from = $this->_tpl_vars['positions']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['position']):
?>
							<option value="<?php echo $this->_tpl_vars['position']->id; ?>
" title="<?php echo $this->_tpl_vars['position']->description; ?>
" <?php if ($this->_tpl_vars['position']->id == $this->_tpl_vars['formData']['fposition']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['position']->name; ?>
</option>
						<?php endforeach; endif; unset($_from); ?>
					</select>
				
				<input type="button" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['filterSubmit']; ?>
" class="button" onclick="gosearchbanner();"  />
		
			</form>
		</div>
	
	</div>

    	
</div>

<?php echo '
<script type="text/javascript">
	function gosearchbanner()
	{
		var path = rooturl_admin + "banner/index";
		
		var id = $("#fid").val();
		if(parseInt(id) > 0)
		{
			path += "/id/" + id;
		}
		
		var keyword = $("#fkeyword").val();
		if(keyword.length > 0)
		{
			path += "/keyword/" + keyword;
		}
		
		var keywordin = $("#fsearchin").val();
		if(keywordin.length > 0)
		{
			path += "/searchin/" + keywordin;
		}
		
		var positionid = $("#fposition").val();
		if(positionid > 0)
		{
			path += "/positionid/" + positionid;
		}
		
		
		
		document.location.href= path;
	}
</script>
'; ?>



