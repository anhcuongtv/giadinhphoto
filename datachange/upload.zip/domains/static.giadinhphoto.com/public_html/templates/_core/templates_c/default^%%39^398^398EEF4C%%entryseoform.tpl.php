<?php /* Smarty version 2.6.26, created on 2010-07-03 20:31:31
         compiled from _controller/site/entryseoform.tpl */ ?>
<?php if ($this->_tpl_vars['me']->groupid == @GROUPID_ADMIN): ?>
<div class="form-entry">
	<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"></div>
	<div class="form-entry-textbox"><hr size="1" /><strong>Search Engine Optimization:</strong></div>
</div>

<div class="form-entry">
	<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySeoUrl']; ?>
 :</label></div>
	<div class="form-entry-textbox"><input type="text" id="fseourl" name="fseourl" value="<?php echo $this->_tpl_vars['formData']['fseourl']; ?>
" /></div>
</div>

<div class="form-entry">
	<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySeoTitle']; ?>
 :</label></div>
	<div class="form-entry-textbox"><input type="text" id="fseotitle" name="fseotitle" value="<?php echo $this->_tpl_vars['formData']['fseotitle']; ?>
" /></div>
</div>

<div class="form-entry">
	<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySeoKeyword']; ?>
 :</label></div>
	<div class="form-entry-textbox"><input type="text" id="fseokeyword" name="fseokeyword" value="<?php echo $this->_tpl_vars['formData']['fseokeyword']; ?>
" /></div>
</div>

<div class="form-entry">
	<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySeoDescription']; ?>
 :</label></div>
	<div class="form-entry-textbox"><textarea name="fseodescription" class="entry-textarea" rows="5"><?php echo $this->_tpl_vars['formData']['fseodescription']; ?>
</textarea></div>
</div>
<?php endif; ?>