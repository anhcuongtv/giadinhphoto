<?php /* Smarty version 2.6.26, created on 2013-10-28 13:35:55
         compiled from _controller/site/index/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'lower', '_controller/site/index/index.tpl', 138, false),)), $this); ?>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/jquery.countdown.min.js"></script>
<?php echo '
<style type="text/css">
.counter-day{font-size: 90px; margin:0; line-height:90px; font-weight:bold; text-align:center; color:#ff6600;}
.counter-day span{font-size:16px; line-height:0;}
.counter-time{font-size: 16px; font-weight:bold; text-align:center; color:#ff6600;}
</style>
'; ?>

<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
        	<div class="cat-block clearfix">
            	<div class="left">
                	<p><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-cat01.jpg" alt="" /><span><?php echo $this->_tpl_vars['lang']['global']['photoSectionIn']; ?>
</span></a></p>
                    <p><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-cat02.jpg" alt="" /><span><?php echo $this->_tpl_vars['lang']['global']['photoSectionWild']; ?>
</span></a></p>
                </div>
                <div class="center">
                	<p><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-cat03.jpg" alt="" /><span><?php echo $this->_tpl_vars['lang']['global']['photoSectionLand']; ?>
</span></a></p>
                </div>
                <div class="right">
                	<p><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-cat04.jpg" alt="" /><span><?php echo $this->_tpl_vars['lang']['global']['photoSectionFlo']; ?>
</span></a></p>
                    <p><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-cat05.jpg" alt="" /><span><?php echo $this->_tpl_vars['lang']['global']['photoSectionEnvir']; ?>
</span></a></p>
                </div>
            </div><!-- cat-block -->
            
        	<div class="clearfix">
            	<div id="primary">
                	<div class="block-table">
                        <table id="statistics" cellpadding="0" cellspacing="0">
                            <tr>
                                <td rowspan="2" class="w220 non-boder-left">
                                    <p class="exam"><?php echo $this->_tpl_vars['lang']['global']['rightboxYear']; ?>
<br /><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDate']; ?>
: <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDateValue']; ?>
</p>
                                    <div id="countdowntimer"></div>
                                </td>
                                <th class="w150"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxEvent']; ?>
</th>
                                <th class="non-boder-left"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxDate']; ?>
</th>
                                <td rowspan="2" class="w220">
                                    <p class="title-statistic"><strong><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxStatistic']; ?>
</strong><br />3 <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxStatisticText']; ?>
</p>
                                    <ul class="statistics-list">
                                        <li>* <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxRegisteredUser']; ?>
: </li>
                                        <li>* # <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxOfPhotoOnline']; ?>
: </li>
                                        <li>* # <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxOfPhotoView']; ?>
: </li>
                                        <li>* # <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxOfCountry']; ?>
: </li>
                                    </ul>
                                </td>
                            </tr>
                            
                            <tr>
                                <td>
                                    <ul class="events-list">
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDate']; ?>
</li>    
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxJudging']; ?>
</li>
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxNotification']; ?>
</li>  
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxExhibitionDate']; ?>
</li>
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxCatalogue']; ?>
</li>
                                    </ul>
                                </td>
                                <td>
                                    <ul class="events-list">
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDateValue']; ?>
</li>    
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxJudgingValue']; ?>
</li>
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxNotificationValue']; ?>
</li>  
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxExhibitionDateValue']; ?>
</li>
                                        <li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxCatalogueValue']; ?>
</li>
                                    </ul>
                                </td>
                            </tr>
                        </table>
                    </div><!-- block-table -->
                                        <p>&nbsp;</p>
                	<div class="section">
                    	<h2>About this contest</h2>
                        <ul class="contest-list">
                        	<li class="clearfix">
                            	<div class="left">
                                	<p class="image"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-contest.jpg" alt="" /></p>
                                    <div>
                                    	<p class="photographer">Photographer</p>
                                    </div>
                                </div>
                                <div class="right">
                                	<p><?php echo $this->_tpl_vars['lang']['controllergroup']['defaultHomeDescription']; ?>

                                    </p>

                                </div>
                            </li>
                        </ul>
                    </div>
                </div><!-- primary -->
                
                <div id="secondary">
                	<p><a href="#" target="_blank"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/digital-slr-store.jpg" alt="" /></a></p>
                    <div class="social clearfix">
                    	<span class="title">Social network</span>
                    	<div class="tweeter"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/tweeter.gif" alt="" /></div>
                        <div class="fb-share"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/fb-share.gif" alt="" /></div>
                    </div>
                    <p class="paypal">
                    	<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/img-paypal.gif" alt="" />
                        <span>Secure Payments by Paypal</span>
                    </p>
                </div><!-- secondary -->
            </div><!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->

<?php echo '    
        <script type="text/javascript">
    $(document).ready(function() {
    
        //$("#time").countdown({date:"may 1, 2011"});
        
        $("#countdowntimer").countdown({date:"'; ?>
<?php echo ((is_array($_tmp=$this->_tpl_vars['jsCountdown'])) ? $this->_run_mod_handler('lower', true, $_tmp) : smarty_modifier_lower($_tmp)); ?>
<?php echo '",
                                        htmlTemplate: \'<div class="counter-day">%{d}<span>'; ?>
<?php echo $this->_tpl_vars['lang']['controller']['countDay']; ?>
<?php echo '</span></div><div class="counter-time">%{h} <span class="small">'; ?>
<?php echo $this->_tpl_vars['lang']['controller']['countHour']; ?>
<?php echo '</span> %{m} <span class="small">'; ?>
<?php echo $this->_tpl_vars['lang']['controller']['countMinute']; ?>
<?php echo '</span> %{s} <span class="small">'; ?>
<?php echo $this->_tpl_vars['lang']['controller']['countSecond']; ?>
<?php echo '</span></div>\',
                                        });
    
        //$("#time").countdown({date:"april 15, 2011"});
    });
</script>
'; ?>