<?php /* Smarty version 2.6.26, created on 2010-07-03 20:16:40
         compiled from _controller/admin/log/detail.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_controller/admin/log/detail.tpl', 43, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_detail']; ?>
 : #<?php echo $this->_tpl_vars['log']->id; ?>
</h2>
<div id="page-intro"><?php echo $this->_tpl_vars['lang']['controller']['intro_detail']; ?>
</div>


<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_detail']; ?>
</h3>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
			<table class="grid">
				<tr>
					<td width="150" class="td_right"><strong>Entry ID :</strong></td>
					<td><?php echo $this->_tpl_vars['log']->id; ?>
</td>
				</tr>
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
 :</strong></td>
					<td><?php echo $this->_tpl_vars['log']->username; ?>
 (UID: <?php echo $this->_tpl_vars['log']->uid; ?>
)</td>
				</tr>
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formGroupLabel']; ?>
 :</strong></td>
					<td><?php echo $this->_tpl_vars['log']->groupname; ?>
 (GROUPID: <?php echo $this->_tpl_vars['log']->groupid; ?>
)</td>
				</tr>
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
 :</strong></td>
					<td> <?php echo $this->_tpl_vars['log']->type; ?>
</td>
				</tr>
				
				
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formIpLabel']; ?>
 :</strong></td>
					<td><?php echo $this->_tpl_vars['log']->ip; ?>
</td>
				</tr>
				
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formDatecreatedLabel']; ?>
 :</strong></td>
					<td><?php echo ((is_array($_tmp=$this->_tpl_vars['log']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty'])); ?>
</td>
				</tr>
				
				<tr>
					<td class="td_right"><strong><?php echo $this->_tpl_vars['lang']['controller']['formMoreDataLabel']; ?>
 :</strong></td>
					<td>
						<ul>
							<li><em><?php echo $this->_tpl_vars['lang']['controller']['formMainIdLabel']; ?>
</em>: <?php echo $this->_tpl_vars['log']->mainid; ?>
</li>
						<?php $_from = $this->_tpl_vars['log']->moredata; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['v']):
?>
							<li><em><?php echo $this->_tpl_vars['k']; ?>
</em>: <?php echo $this->_tpl_vars['v']; ?>
</li>
						<?php endforeach; endif; unset($_from); ?>
						</ul>
					</td>
				</tr>
				
			</table>
			
			<p>
				<a class="button button-delete buttonbig" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
log/delete/id/<?php echo $this->_tpl_vars['log']->id; ?>
/redirect/<?php echo $this->_tpl_vars['encodedRedirectUrl']; ?>
?token=<?php echo $_SESSION['securityToken']; ?>
');"><?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
</a>
				&nbsp;
				
			</p>
	
	</div>

    	
</div>
