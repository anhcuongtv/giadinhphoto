<?php /* Smarty version 2.6.26, created on 2013-10-27 18:13:02
         compiled from _controller/site/page/index.tpl */ ?>
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
				<div id="page">
<table width="580" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
	<td height="8"></td>
	</tr>  
	<tr>
	<td height="40" align="left" style="border-bottom:2px solid #67b718; text-transform:uppercase"><strong style="font-size:21px"><?php echo $this->_tpl_vars['page']->title[$this->_tpl_vars['langCode']]; ?>
</strong></td>
	</tr>
	
	<tr>
	<td height="8"></td>
</tr>  
</tbody></table>
					<div class="contents"><?php echo $this->_tpl_vars['page']->contents[$this->_tpl_vars['langCode']]; ?>
</div>
				</div>		
		<!-- ---->       	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->    
</div><!-- wrapper -->