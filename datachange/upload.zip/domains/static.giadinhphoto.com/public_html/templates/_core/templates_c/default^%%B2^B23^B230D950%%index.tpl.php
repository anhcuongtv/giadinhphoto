<?php /* Smarty version 2.6.26, created on 2010-07-06 16:09:09
         compiled from _controller/admin/abusequizcomment/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/admin/abusequizcomment/index.tpl', 25, false),array('modifier', 'upper', '_controller/admin/abusequizcomment/index.tpl', 29, false),array('modifier', 'date_format', '_controller/admin/abusequizcomment/index.tpl', 74, false),array('modifier', 'relative_datetime', '_controller/admin/abusequizcomment/index.tpl', 74, false),array('modifier', 'htmlspecialchars', '_controller/admin/abusequizcomment/index.tpl', 100, false),array('function', 'paginate', '_controller/admin/abusequizcomment/index.tpl', 53, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_list']; ?>
</h2>
<div id="page-intro"><?php echo $this->_tpl_vars['lang']['controller']['intro_list']; ?>
</div>

<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_list']; ?>
 <?php if ($this->_tpl_vars['formData']['search'] != ''): ?>| <?php echo $this->_tpl_vars['lang']['controller']['title_listSearch']; ?>
 <?php endif; ?>(<?php echo $this->_tpl_vars['total']; ?>
)</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['tableTabLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controllergroup']['filterLabel']; ?>
</a></li>
		</ul>
		<?php if ($this->_tpl_vars['formData']['search'] != ''): ?>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
abusequizcomment"><?php echo $this->_tpl_vars['lang']['controllergroup']['formViewAll']; ?>
</a></li>
		</ul>
		<?php endif; ?>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			<form action="" method="post" name="manage" onsubmit="return confirm('Are You Sure ?');">
				<table class="grid">
					
				<?php if (count($this->_tpl_vars['abuses']) > 0): ?>
					<thead>
						<tr>
						   <th width="40"><input class="check-all" type="checkbox" /></th>
							<th width="30"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</a></th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formQuizLabel']; ?>
 / <?php echo $this->_tpl_vars['lang']['controller']['formCommentLabel']; ?>
</th>	
							<th width="50"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/view/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'view'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formViewLabel']; ?>
</a></th>	
							<th width="70"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/rating/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'rating'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formRatingLabel']; ?>
</a></th>	
							<th><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/status/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'status'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formStatusLabel']; ?>
</a></th>	
							<th width="100"><?php echo $this->_tpl_vars['lang']['controller']['formIpAddressLabel']; ?>
</th>
							<th width="100"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formDateCreatedLabel']; ?>
</a></th>
							<th width="70"></th>
						</tr>
					</thead>
					
					<tfoot>
						<tr>
							<td colspan="9">
								<div class="bulk-actions align-left">
									<select name="fbulkaction">
										<option value=""><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSelectLabel']; ?>
</option>
										<option value="delete"><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionDeletetLabel']; ?>
</option>
									</select>
									<input type="submit" name="fsubmitbulk" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSubmit']; ?>
" />
								</div>
								
								<div class="pagination">
								   <?php $this->assign('pageurl', "page/::PAGE::"); ?>
									<?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

								</div> <!-- End .pagination -->
		
								<div class="clear"></div>
							</td>
						</tr>
					</tfoot>
					<tbody>
				<?php $_from = $this->_tpl_vars['abuses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['abuse']):
?>
					
						<tr>
							<td><input type="checkbox" name="fbulkid[]" value="<?php echo $this->_tpl_vars['abuse']->id; ?>
" <?php if (in_array ( $this->_tpl_vars['abuse']->id , $this->_tpl_vars['formData']['fbulkid'] )): ?>checked="checked"<?php endif; ?>/></td>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['abuse']->id; ?>
</td>
							<td><a href="<?php echo $this->_tpl_vars['abuse']->quiz->getFullSeoUrl(); ?>
/edit/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['abuse']->quiz->title; ?>
</a>
							<div style="font-style:italic;"><small>"<?php echo $this->_tpl_vars['abuse']->comment->content; ?>
"</small></div>
							</td>
							<td><?php echo $this->_tpl_vars['abuse']->quiz->view; ?>
</td>
							<td title="<?php echo $this->_tpl_vars['abuse']->quiz->ratingCount; ?>
 vote"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['abuse']->quiz->getRoundRating(); ?>
.png"  title="<?php if ($this->_tpl_vars['abuse']->quiz->rating == 0): ?>Not set<?php else: ?>Rating : <?php echo $this->_tpl_vars['abuse']->quiz->rating; ?>
<?php endif; ?>" /></td><td><?php if ($this->_tpl_vars['abuse']->status == 'completed'): ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/completed.png" title="Completed" alt="completed" /><?php elseif ($this->_tpl_vars['abuse']->status == 'pending'): ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pending.png" title="Pending" alt="pending" /><?php else: ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/new.png" title="New" alt="new" /><?php endif; ?>
								<?php if ($this->_tpl_vars['abuse']->note != ''): ?><div style="font-style:italic;" title="<?php echo $this->_tpl_vars['abuse']->note; ?>
"><small><?php echo $this->_tpl_vars['lang']['controller']['formNoteLabel']; ?>
: <?php echo $this->_tpl_vars['abuse']->note; ?>
</small></div><?php endif; ?>
							</td>
							<td><?php echo $this->_tpl_vars['abuse']->ipaddress; ?>
</td>
							<td title="<?php echo ((is_array($_tmp=$this->_tpl_vars['abuse']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['abuse']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</td>
							<td><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
abusequizcomment/edit/id/<?php echo $this->_tpl_vars['abuse']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
							<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
abusequizcomment/delete/id/<?php echo $this->_tpl_vars['abuse']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
?token=<?php echo $_SESSION['securityToken']; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a>
							</td>
						</tr>
						
					
				<?php endforeach; endif; unset($_from); ?>
				</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="9"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
	
		</div>
		
		<div class="tab-content" id="tab2">
			<form action="" method="post" style="padding:0px;margin:0px;" onsubmit="return false;">
	
				<?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
: 
				<input type="text" name="fid" id="fid" size="8" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fid']); ?>
" class="text-input" /> - 
				
				
					<?php echo $this->_tpl_vars['lang']['controller']['formStatusLabel']; ?>
:	
					<select name="fstatus" id="fstatus">
						<option value="">- - - - - - - - - - - - -</option>
						<option value="new" <?php if ($this->_tpl_vars['formData']['fstatus'] == 'new'): ?>selected="selected"<?php endif; ?>>New</option>
						<option value="pending" <?php if ($this->_tpl_vars['formData']['fstatus'] == 'pending'): ?>selected="selected"<?php endif; ?>>Pending</option>
						<option value="completed" <?php if ($this->_tpl_vars['formData']['fstatus'] == 'completed'): ?>selected="selected"<?php endif; ?>>Completed</option>
					</select> -
					
					<?php echo $this->_tpl_vars['lang']['controller']['formKeywordLabel']; ?>
:
				
					<input type="text" name="fkeyword" id="fkeyword" size="20" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fkeyword']); ?>
" class="text-input" /><select name="fsearchin" id="fsearchin">
						<option value="">- - - - - - - - - - - - -</option>
						<option value="title" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'title'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInQuizLabel']; ?>
</option>
						<option value="content" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'content'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInContentLabel']; ?>
</option>
						<option value="ipaddress" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'ipaddress'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInIpAddressLabel']; ?>
</option>
						<option value="note" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'note'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInNoteLabel']; ?>
</option>
						
					</select>
					
				
				
				
				<input type="button" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['filterSubmit']; ?>
" class="button" onclick="gosearchabusequizcomment();"  />
		
			</form>
		</div>
		
		
	
	</div>
	

    	
</div>

<?php echo '
<script type="text/javascript">
	function gosearchabusequizcomment()
	{
		var path = rooturl_admin + "abusequizcomment/index";
		
		var id = $("#fid").val();
		if(parseInt(id) > 0)
		{
			path += "/id/" + id;
		}
		
				
		var status = $("#fstatus").val();
		if(status.length > 0)
		{
			path += "/status/" + status;
		}
		
		var keyword = $("#fkeyword").val();
		if(keyword.length > 0)
		{
			path += "/keyword/" + keyword;
		}
		
		var keywordin = $("#fsearchin").val();
		if(keywordin.length > 0)
		{
			path += "/searchin/" + keywordin;
		}
		
				
		document.location.href= path;
	}
</script>
'; ?>



