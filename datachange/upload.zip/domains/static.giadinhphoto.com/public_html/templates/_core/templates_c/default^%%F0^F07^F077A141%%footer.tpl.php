<?php /* Smarty version 2.6.26, created on 2013-10-24 16:36:31
         compiled from _mail/site/footer.tpl */ ?>
	</div>
	<hr  size="1" style="margin-top:20px;color:#ccc;" />
	<h4><a href="http://"<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
">The Green Environment 2013</a></h4>
	<p>
		
	</p>
</div><!-- end container -->