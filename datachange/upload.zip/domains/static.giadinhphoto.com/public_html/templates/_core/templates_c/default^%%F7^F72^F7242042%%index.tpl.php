<?php /* Smarty version 2.6.26, created on 2013-10-28 13:58:03
         compiled from _controller/site/login/index.tpl */ ?>
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
		
		<div id="page">

<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tbody>
      
      <tr>     
      
		<td align="center"><table width="960" border="0" cellspacing="0" cellpadding="0">
		  <tbody>
		  <tr>
<td>
<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" class="form_input">
  <tbody><tr>
    <td><table width="580" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
          	<td height="8"></td>
          </tr>  
          <tr>
            <td  height="40" align="left" style="border-bottom:2px solid #67b718; text-transform:uppercase"><strong style="font-size:21px"><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</strong></td>
          </tr>
  
          <tr>
          	<td height="8"></td>
          </tr>  
        </tbody></table></td>
  </tr>
  <tr>
    <td height="40">&nbsp;</td>
  </tr>
  <tr>
    <td>
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    <form method="post" action="">    
    <!-- END ERROR BOX-->    
    <table width="630" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="8" valign="top"></td>
        <td>
        <table width="614" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['username']; ?>
</td>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['password']; ?>
</td>
          </tr>
		  
          <tr>
            <td height="12">&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td><input name="fusername" type="text" id="email" style="width:280px;" maxlength="75"></td>
            <td>
				<input name="fpassword" type="password" id="email" style="width:280px;" maxlength="75">
			</td>
          </tr>
		  
          <tr>
            <td height="30" colspan="2"><span class="footer_btn"><em class="content_txt_10"><?php echo $this->_tpl_vars['lang']['controller']['help']; ?>
</em></span></td>
            <td height="30"></td>
          </tr>
          
          
          <tr>
            <td>
				<input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['btnSend']; ?>
.gif" name="fsubmit"  /> 
                
			</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="20">&nbsp;</td>
            <td height="20">&nbsp;</td>
          </tr>
          <tr>
            <td><span class="content_txt_12"><?php if ($this->_tpl_vars['setting']['extra']['enableRegister']): ?><span class="form-entry-login-register"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>?redirect=<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
</a></span><?php endif; ?></span> | <span class="content_txt_12"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
forgotpass.html<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>?redirect=<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['controller']['forgotpass']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['forgotpass']; ?>
</a></span></td>
            <td></td>
			 
          </tr>
        </tbody></table></td>
        <td width="8" valign="bottom">&nbsp;</td>
      </tr>
    </tbody></table>
    </form>
    
    
    </td>
  </tr>
</tbody></table>
</td>		  	
		  
		  </tr>	
		  
		  <tr>
			<td valign="top"> <br /><br /><br /><br /><br /><br /><br /><br /><br /></td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		</tbody></table></td>
	</tr>	  
	</tbody>
</table>
			</div>
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->




