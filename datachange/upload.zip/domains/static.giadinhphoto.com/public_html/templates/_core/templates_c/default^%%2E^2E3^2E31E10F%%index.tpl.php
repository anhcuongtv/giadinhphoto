<?php /* Smarty version 2.6.26, created on 2010-06-30 21:10:43
         compiled from _controller/site/reportabuse/index.tpl */ ?>
<html>
	<head><title>Loving.vn Report Abuse</title></head>
	
	<style type="text/css">
	<?php echo '
	h1{margin:0; padding:10px; font-size:18px;}
	p{margin:0;padding:0;}
	body{background:#fff; font-family:Verdana, Geneva, sans-serif; font-size:12px;}
	table{font-size:12px;}
	input, textarea{padding:3px;border:1px solid #ccc;border-radius: 4px; -moz-border-radius: 4px; -webkit-border-radius: 4px;}
	textarea{width:350px;}
	.submit{font-weight:bold; background:#F39; color:#fff; border:1px solid #F09; cursor:pointer;}
	.submit:hover{background:#369; border-color:#36C;}
	/* ---- NOTIFY BAR ---- */
	.notify-bar{padding:10px;border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px;margin-bottom:10px;}
	.notify-bar-success{background:#eaffa5;color:#6c8c00;}
	.notify-bar-error{background:#ffcfce;color:#9e3737;}
	.notify-bar-warning{background:#ffeeb1;color:#e37b00;}
	.notify-bar-info{background:#d6e2ff;color:#577bd1;}
	.notify-bar-icon{float:left;width:45px;}
	.notify-bar-text{padding:0 20px 0 45px; font-size:18px;line-height:1.5;}
	.notify-bar-text-sep{border-top:1px solid #eee;margin:10px 0;}
	.notify-bar-button{float:right;width:15px;text-align:right;}
	
	'; ?>

	</style>
	<body>
		
		<form method="post">
		
			<input type="hidden" name="ftoken" value="<?php echo $_SESSION['abuseToken']; ?>
" />
			<input type="hidden" name="fabusetype" value="<?php echo $this->_tpl_vars['abuseType']; ?>
" />
			<input type="hidden" name="fabuseid" value="<?php echo $this->_tpl_vars['abuseId']; ?>
" />
			<table width="100%" cellpadding="3" cellspacing="0">
				<tr>
					<td align="center" colspan="2" style="background:#1575AE;color:#fff;"><h1><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</h1></td>
				</tr>
				<?php if ($this->_tpl_vars['formData']['hideform'] != 1): ?>
				<tr>
					<td width="100" align="right"><?php echo $this->_tpl_vars['lang']['controller']['note']; ?>
:</td>
					<td>
						<textarea name="fnote" cols="30" rows="4"></textarea>
					</td>
				</tr>
				<tr>
					<td align="right"></td>
					<td><input class="submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controller']['submit']; ?>
" /></td>
				</tr>
				<?php endif; ?>
			</table>
			
		
		</form>
		
		
		<div style="margin:10px;">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		</div>
		

<script type="text/javascript" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/jquery.js"></script>
	<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "googleanalytic.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	</body>
</html>