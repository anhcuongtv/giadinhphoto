<?php /* Smarty version 2.6.26, created on 2010-07-15 22:49:15
         compiled from _controller/site/entrysortbar.tpl */ ?>
<span class="sortbar">
	<a <?php if ($this->_tpl_vars['sortby'] == 'id' && $this->_tpl_vars['sorttype'] == 'DESC'): ?>class="active"<?php endif; ?> href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingLatest']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['sortLatest']; ?>
</a>
	<a <?php if ($this->_tpl_vars['sortby'] == 'id' && $this->_tpl_vars['sorttype'] == 'ASC'): ?>class="active"<?php endif; ?> href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/oldest" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingOldest']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['sortOldest']; ?>
</a>
	<a <?php if ($this->_tpl_vars['sortby'] == 'view' && $this->_tpl_vars['sorttype'] == 'DESC'): ?>class="active"<?php endif; ?> href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/topview" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingTopview']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['sortTopView']; ?>
</a>
	<a <?php if ($this->_tpl_vars['sortby'] == 'rating' && $this->_tpl_vars['sorttype'] == 'DESC'): ?>class="active"<?php endif; ?> href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/toprate" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingToprate']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['sortTopRate']; ?>
</a>
</span>