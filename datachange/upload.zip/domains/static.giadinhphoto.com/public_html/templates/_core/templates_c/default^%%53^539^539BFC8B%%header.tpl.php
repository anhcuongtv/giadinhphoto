<?php /* Smarty version 2.6.26, created on 2013-10-28 13:28:52
         compiled from _controller/site/header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', '_controller/site/header.tpl', 9, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<title><?php if ($this->_tpl_vars['pageTitle'] != ''): ?><?php echo $this->_tpl_vars['pageTitle']; ?>
<?php else: ?><?php echo $this->_tpl_vars['setting']['site']['defaultPageTitle']; ?>
<?php endif; ?></title>
<meta name="viewport" content = "user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
<meta name="description" content="<?php echo ((is_array($_tmp=@$this->_tpl_vars['pageDescription'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['site']['defaultPageDescription']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['site']['defaultPageDescription'])); ?>
">
<meta name="keywords" content="<?php echo ((is_array($_tmp=@$this->_tpl_vars['pageKeyword'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['site']['defaultPageKeyword']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['site']['defaultPageKeyword'])); ?>
">
<link href="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/css/site/main.css" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/jquery-1.7.min.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/site/script.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/main.js"></script>

<?php echo '
<!--[if lt IE 10]>
		<style type="text/css">
            #content,
            .cat-block p img
			{
					behavior: url(assets/PIE.php);
					position: relative;
					zoom: 1;
			}
		</style>
		<script type="text/javascript" src="{$staticserver}{$currentTemplate}/js/site/css3-mediaqueries.js"></script>
<![endif]-->
'; ?>

</head>
<?php echo '
<script type="text/javascript">
    var rooturl = "{$conf.rooturl}";
    var currentTemplate = "default";
    var delConfirm = "{$lang.controllergroup.jsDelConfirm}";
</script>
'; ?>


<body>
<div id="wrapper">
	<div id="header">
    	<p id="logo"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/logo.png" alt="Câu lạc bộ nhiếp ảnh Gia Định" /></a></p>
        <p class="front"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/image-sans-frontiere.png" alt="" /></p>
        <p class="desc"><?php echo $this->_tpl_vars['lang']['controllergroup']['defaultPageDescription']; ?>
</p>
        <div class="search-frm">
		<?php if ($this->_tpl_vars['me']->id == 0): ?>
        <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html"><?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
login.html"><?php echo $this->_tpl_vars['lang']['global']['mLogin']; ?>
</a>
		<?php else: ?>
			<?php echo $this->_tpl_vars['lang']['global']['hi']; ?>
<?php echo $this->_tpl_vars['me']->fullname; ?>
 - <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
logout.html"><?php echo $this->_tpl_vars['lang']['global']['mLogout']; ?>
</a>
		<?php endif; ?>
        </div>            

        <div class="lang">
<a href="?language=vn"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/lang-vn.png" alt="Tiếng Việt" /></a>&nbsp; 
<a href="?language=en"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/lang-en.png" alt="English" /></a>
        </div>
        <ul id="menu" class="clearfix">
        	<li <?php if ($this->_tpl_vars['controller'] == 'index'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['mTrangchu']; ?>
</a></li>
            <li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'rules'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-rules.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mThele']; ?>
</a></li>
            <li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'awards'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-awards.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mGiaithuong']; ?>
</a></li>
            <li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'judge'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-judge.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mGiamkhao']; ?>
</a></li>
            <li <?php if ($this->_tpl_vars['controller'] == 'statuslist'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
statuslist.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mTrangthai']; ?>
</a></li>
            <li <?php if ($this->_tpl_vars['controller'] == 'memberarea'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mGuianh']; ?>
</a></li>
        </ul>
    </div><!-- header -->