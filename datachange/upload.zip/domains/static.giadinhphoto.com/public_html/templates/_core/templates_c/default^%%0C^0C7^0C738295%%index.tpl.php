<?php /* Smarty version 2.6.26, created on 2010-09-05 11:18:00
         compiled from _controller/site/payment/index.tpl */ ?>


<div id="pageBody">
<div id="primary">
<dl class="information">
<dt><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</dt>
<dd></dd>
</dl>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div id="paymentContent">
	
	
	<?php if ($this->_tpl_vars['paymentSuccess'] == 1): ?>
		<div class="paymentSuccess">
			<?php if ($this->_tpl_vars['paymentGate'] == 'paypal' || $this->_tpl_vars['paymentGate'] == 'expresscheckout'): ?>
				<?php echo $this->_tpl_vars['lang']['controller']['succPaymentOnline']; ?>

			<?php else: ?>
				<?php echo $this->_tpl_vars['lang']['controller']['succPaymentOffline']; ?>

			<?php endif; ?>
		</div>
		
		<div>Quick Link: <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html" title="Member Area">Member Area</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=upload" title="Upload Photo">Upload Photo</a></div>
	<?php else: ?>
	
		<div class="infoSelectPayment"><?php echo $this->_tpl_vars['lang']['controller']['paymentYourSelect']; ?>
</div>
		<div class="paymentOptionList">
			<?php if ($this->_tpl_vars['packId'] == 1 || $this->_tpl_vars['packId'] == 3 || $this->_tpl_vars['packId'] == 5 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionColor']; ?>
 <br />
			
			<?php if ($this->_tpl_vars['packId'] == 2 || $this->_tpl_vars['packId'] == 3 || $this->_tpl_vars['packId'] == 6 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionMono']; ?>
 <br />
			
			<?php if ($this->_tpl_vars['packId'] == 4 || $this->_tpl_vars['packId'] == 5 || $this->_tpl_vars['packId'] == 6 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionNature']; ?>
 <br />
		</div>
		
		<div><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=payment" title="Back">Change</a></div>
		
		<div class="paymentOptionTotal">
			<?php echo $this->_tpl_vars['lang']['controller']['paymentTotal']; ?>
 : <span id="paymentOptionPrice"><?php echo $this->_tpl_vars['currency']->formatPrice($this->_tpl_vars['myProduct']->price); ?>
</span>
		</div>
		
		<div class="paymentMethodSelect">
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectPaypal">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectPaypal');">Thanh toan truc tuyen</div>
				<div class="paymentMethodBody">
					<table border="0" width="100%">
					 <tbody><tr>
						<td colspan="2">
						 <form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=paypal" name="manage">
							<table width="100%">
								<tbody><tr>
									<td style="font-weight: bold;" colspan="2">Fill information on your credit card</td>
								</tr>
								<tr>
									<td width="150" align="left">Card Type:</td>
									<td>
										<label><input type="radio" value="MasterCard" name="fcardtype"><img border="1" align="top" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cardtype_mastercard.gif" title="MasterCard" alt="MasterCard"></label>
										&nbsp;&nbsp;&nbsp;<label><input type="radio" value="Visa" name="fcardtype"><img border="1" align="top" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cardtype_visa.gif" title="Visa" alt="Visa"></label>
										&nbsp;&nbsp;&nbsp;<label><input type="radio" value="Discover" name="fcardtype"><img border="1" align="top" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cardtype_discover.gif" title="Discover" alt="Discover"></label>
										&nbsp;&nbsp;&nbsp;<label><input type="radio" value="Amex" name="fcardtype"><img border="1" align="top" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cardtype_amex.gif" title="Amex" alt="Amex"></label>
									</td>
								</tr>
								
								<tr class="directpayment_data">
									<td align="left">First Name:</td>
									<td align="left"><input type="text" value="Vo Duy" name="ffirstname"></td>
								</tr>
								<tr class="directpayment_data">
									<td align="left">Last Name:</td>
									<td align="left"><input type="text" value="Tuan" name="flastname"></td>
								</tr>
								
								<tr class="directpayment_data">
									<td align="left">ZIP Code:</td>
									<td align="left"><input type="text" size="5" value="" name="fzipcode"></td>
								</tr>
								<tr class="directpayment_data">
									<td align="left">Card Number:</td>
									<td align="left"><input type="text" size="30" value="" name="fcardnumber"></td>
								</tr>
								<tr class="directpayment_data">
									<td align="left">CVV2</td>
									<td align="left"><input type="text" size="5" value="" name="fcvvnumber"></td>
								</tr>
							 <tr class="directpayment_data">
									<td align="left">Expiration Date</td>
									<td align="left"><select name="fexpiredmonth"><option value="0">- Month -</option><option value="1" label="January">January</option>
	<option value="2" label="February">February</option>
	<option value="3" label="March">March</option>
	<option value="4" label="April">April</option>
	<option value="5" label="May">May</option>
	<option value="6" label="June">June</option>
	<option value="7" label="July">July</option>
	<option value="8" label="August">August</option>
	<option value="9" label="September">September</option>
	<option value="10" label="October">October</option>
	<option value="11" label="November">November</option>
	<option value="12" label="December">December</option>
	</select>
											<select name="fexpiredyear"><option value="0">- Year -</option><option value="2010" label="2010">2010</option>
	<option value="2011" label="2011">2011</option>
	<option value="2012" label="2012">2012</option>
	<option value="2013" label="2013">2013</option>
	<option value="2014" label="2014">2014</option>
	<option value="2015" label="2015">2015</option>
	<option value="2016" label="2016">2016</option>
	<option value="2017" label="2017">2017</option>
	<option value="2018" label="2018">2018</option>
	<option value="2019" label="2019">2019</option>
	<option value="2020" label="2020">2020</option>
	<option value="2021" label="2021">2021</option>
	<option value="2022" label="2022">2022</option>
	<option value="2023" label="2023">2023</option>
	<option value="2024" label="2024">2024</option>
	<option value="2025" label="2025">2025</option>
	<option value="2026" label="2026">2026</option>
	<option value="2027" label="2027">2027</option>
	<option value="2028" label="2028">2028</option>
	<option value="2029" label="2029">2029</option>
	<option value="2030" label="2030">2030</option>
	<option value="2031" label="2031">2031</option>
	<option value="2032" label="2032">2032</option>
	<option value="2033" label="2033">2033</option>
	<option value="2034" label="2034">2034</option>
	<option value="2035" label="2035">2035</option>
	<option value="2036" label="2036">2036</option>
	<option value="2037" label="2037">2037</option>
	<option value="2038" label="2038">2038</option>
	<option value="2039" label="2039">2039</option>
	<option value="2040" label="2040">2040</option>
	</select>
									
									</td>
								</tr>
								
								<tr>
									<td></td>
									<td align="left"><input type="image" name="submitimage" style="border: 0pt none ;" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/<?php echo $this->_tpl_vars['langCode']; ?>
/paynow_btn.gif">
											<input type="hidden" value="1" name="fsubmit">
									</td>
								</tr>
							</tbody></table>
						</form>
						</td>
						</tr>
						
					
						<tr>
							<td width="150"></td>
							<td align="right"><br><div style="padding-right: 70px; font-style: italic;">OR</div>
							<form action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=expresscheckout" method="post"> 
								 <input type="hidden" value="SetExpressCheckout" name="method">
								 <input type="hidden" value="1" name="fsubmit">
									<input type="image" style="border: 0pt none ;" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cardtype_paypal.gif">
							</form>
							</td>
						</tr>
						
											
					</tbody></table>		
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectCash">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectCash');">Thanh toan bang tien mat</div>
				<div class="paymentMethodBody">
					<div class="button"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=cash" title="Nhan vao day de Luu don hang"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/<?php echo $this->_tpl_vars['langCode']; ?>
/place_order_btn.gif" alt="Pay" /></a></div>
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectBank">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectBank');">Goi tien qua ngan hang</div>
				<div class="paymentMethodBody">
					<div class="button"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=bank" title="Nhan vao day de Luu don hang"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/<?php echo $this->_tpl_vars['langCode']; ?>
/place_order_btn.gif" alt="Pay" /></a></div>
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			
		</div>
		
		
		<?php echo '
		<script type="text/javascript">
			function togglePaymentMethodGroup(groupid)
			{
				$(\'#\' + groupid + \' .paymentMethodBody\').slideToggle();		
			}
		</script>
		'; ?>

		
		<div class="paymentMethod">
			<h2><?php echo $this->_tpl_vars['myPaymentPage']->title[$this->_tpl_vars['langCode']]; ?>
</h2>
			<div><?php echo $this->_tpl_vars['myPaymentPage']->contents[$this->_tpl_vars['langCode']]; ?>
</div>
		</div>
	
	<?php endif; ?>
</div>

<!-- / id primary --></div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."sidebar_home.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!-- / id pageBody --></div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."footer_banner.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>