<?php /* Smarty version 2.6.26, created on 2010-07-02 22:28:40
         compiled from _controller/site/rss/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', '_controller/site/rss/index.tpl', 17, false),array('modifier', 'strip_tags', '_controller/site/rss/index.tpl', 19, false),array('modifier', 'truncate', '_controller/site/rss/index.tpl', 19, false),array('modifier', 'codau2khongdau', '_controller/site/rss/index.tpl', 22, false),array('modifier', 'date_format', '_controller/site/rss/index.tpl', 24, false),)), $this); ?>
<?php echo '<?xml'; ?>
 version="1.0" encoding="iso-8859-1" <?php echo '?>'; ?>

<rss version="2.0">
	<channel>
		<title>Loving.vn - From lover to lover</title>
		<description><?php echo $this->_tpl_vars['setting']['site']['defaultPageDescription']; ?>
</description>
		<link><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
rss</link>
		<webMaster><?php echo $this->_tpl_vars['setting']['mail']['toEmail']; ?>
</webMaster>
		<image>
			<url><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/logo.png</url>
			<title>Loving.vn - From lover to lover</title>
			<link><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
rss</link>
		</image>
	<?php $_from = $this->_tpl_vars['entries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
		<item>
			<title><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
</title>
			<link><?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
</link>
			<description><?php if ($this->_tpl_vars['entry']->image != ''): ?>&lt;img alt="photo of <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
" width="150"  border="1"/&gt;<?php endif; ?>&lt;br /&gt;<![CDATA[<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 500) : smarty_modifier_truncate($_tmp, 500)); ?>
]]></description>
			<?php $this->assign('parentcategoryid', $this->_tpl_vars['entry']->parentcategoryid); ?>
			  <?php $this->assign('categoryid', $this->_tpl_vars['entry']->categoryid); ?>
			  <category domain="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['parentcategoryid']]; ?>
/"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->getParentCategoryName())) ? $this->_run_mod_handler('codau2khongdau', true, $_tmp) : smarty_modifier_codau2khongdau($_tmp)); ?>
</category>
			   <category domain="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['parentcategoryid']]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['categoryid']]; ?>
/"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->getParentCategoryName())) ? $this->_run_mod_handler('codau2khongdau', true, $_tmp) : smarty_modifier_codau2khongdau($_tmp)); ?>
 \ <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->getCategoryName())) ? $this->_run_mod_handler('codau2khongdau', true, $_tmp) : smarty_modifier_codau2khongdau($_tmp)); ?>
</category>
			<pubDate><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%a, %d %b %Y %H:%M:%S GMT") : smarty_modifier_date_format($_tmp, "%a, %d %b %Y %H:%M:%S GMT")); ?>
</pubDate>
			<guid isPermaLink="true"><?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
</guid>
		</item>
	<?php endforeach; endif; unset($_from); ?>
	</channel>
</rss>