<?php /* Smarty version 2.6.26, created on 2013-10-28 17:31:08
         compiled from _controller/site/contact/index.tpl */ ?>
<?php echo '
<script type="text/javascript">
var RecaptchaOptions = {
   theme : \'clean\'
};
</script>
'; ?>


<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
		  <div id="page">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <tbody><tr>
		<td align="center"><table width="960" border="0" cellspacing="0" cellpadding="0">
		  <tbody>
		  	<tr>
				<td>
					<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" class="form_input">
  <tbody><tr>
    <td><table width="630" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
          	<td height="40" style="border-bottom:2px solid #67b718; text-transform:uppercase"><strong><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</strong></td>
          </tr>        
   
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td align="left" class="content_txt_14"><?php echo $this->_tpl_vars['page']->contents[$this->_tpl_vars['langCode']]; ?>
</td>
          </tr>
          <tr>
          	<td height="8"></td>
          </tr> 
        </tbody></table></td>
  </tr>
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
  <tr>
    <td>
    
      <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
	  
    <form class="form_input" method="post" action="">    
    <table width="630" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="8" valign="top">&nbsp;</td>
        <td><table width="614" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td width="292" align="left" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['fullname']; ?>
</td>
            <td width="30" rowspan="17">&nbsp;</td>
            <td width="292" align="left" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['email']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td></td>
          </tr>
		  
          <tr>
            <td><input type="text" name="ffullname" id="fullname" style="width:280px;" value="<?php echo $this->_tpl_vars['formData']['ffullname']; ?>
"></td>
            <td><input type="text" name="femail" id="email" style="width:280px;" value="<?php echo $this->_tpl_vars['formData']['femail']; ?>
"></td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td height="25">&nbsp;</td>
          </tr>
          <tr>
            <td align="left" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['phone']; ?>
</td>
            <td align="left" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['reason']; ?>
</td>
          </tr>
          <tr>
            <td height="2"></td>
            <td></td>
          </tr>
          <tr>
		  	<td>
				<input type="text" id="fphone" name="fphone" value="<?php echo $this->_tpl_vars['formData']['fphone']; ?>
" style="width:280px;"/>
			</td>
            <td>
						<select class="entry-selectbox" name="freason" id="freason" style="width:280px;">
                            <option <?php if ($this->_tpl_vars['formData']['freason'] == 'general'): ?>selected="selected" <?php endif; ?> value="general"><?php echo $this->_tpl_vars['lang']['controller']['reasonGeneral']; ?>
</option>
                            <option <?php if ($this->_tpl_vars['formData']['freason'] == 'support'): ?>selected="selected" <?php endif; ?> value="support"><?php echo $this->_tpl_vars['lang']['controller']['reasonSupport']; ?>
</option>
                        </select>
			</td>
          </tr>
          <tr>
            <td height="10"></td>
            <td class="footer_btn"><em class="content_txt_10"></em></td>
          </tr>
          
          
        </tbody></table>
          <br>
          <table width="614" border="0" cellspacing="0" cellpadding="0">
            <tbody>
			<tr>
              <td align="left"><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['message']; ?>
</span></td>
            </tr>
            <tr>
              <td height="8"></td>
            </tr>
            <tr>
              <td><textarea name="fmessage" id="comment" style="width:582px;" cols="45" rows="5"></textarea></td>
            </tr>
			<tr>
              <td height="8"></td>
            </tr>
			<tr>
              <td align="left"><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['securityCode']; ?>
</span></td>
            </tr>
            <tr>
              <td height="8"></td>
            </tr>
			<tr>
				<td>
					<?php echo $this->_tpl_vars['recaptchahtml']; ?>

				</td>
			</tr>
			<tr>
              <td align="left"><span class="content_txt_12">&nbsp;</span></td>
            </tr>
            <tr>
              <td height="8"></td>
            </tr>
            <tr>
              	&nbsp;
            </tr>
			<tr>
              <td height="8"></td>
            </tr>
            <tr>
              <td height="30">&nbsp;</td>
            </tr>
            <tr>
              <td align="left">
			  <input type="image" name="fsubmit" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['btnSend']; ?>
.gif" /> </td>
            </tr>
          </tbody></table></td>
        <td width="8" valign="bottom">&nbsp;</td>
      </tr>
    </tbody></table>
    </form>
    
    
    
    </td>
  </tr>
</tbody></table>
    
				</td>
		  	</tr>
		  
		  <tr>
			<td valign="top">&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		</tbody></table></td>
	</tr>	  
	</tbody>
</table>

                    
			</div>		
		<!-- ---->       	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->    
</div><!-- wrapper -->



