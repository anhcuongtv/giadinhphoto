<?php /* Smarty version 2.6.26, created on 2010-07-12 23:23:52
         compiled from _controller/site/entryarticle/edit.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['headingPrefixEdit']; ?>
 <?php if ($this->_tpl_vars['formData']['parentCategory']->id > 0): ?><em></em><?php endif; ?></h1></div>
	<div id="page-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<div id="mainform-form">
			<form action="" method="post" enctype="multipart/form-data">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['entryEditToken']; ?>
" />
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditBtn']; ?>
" />
					
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['titleLabel']; ?>
 :</label></div>
					<div class="form-entry-big-textbox"><input class="entry-textbox-long" type="text" id="ftitle" name="ftitle" value="<?php echo $this->_tpl_vars['formData']['ftitle']; ?>
" /></div>
				</div>
				

				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCategory']; ?>
 :</label></div>
					<div>
						<select class="entry-selectbox" id="fcategoryidentifier" name="fcategoryidentifier">
							<option value="---">- - - - - - - - - -</option>
							<option value="lang-man" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'lang-man'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mArticleRomance']; ?>
</option>
							<option value="lam-dep" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'lam-dep'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mArticleBeaty']; ?>
</option>
							<option value="suc-khoe" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'suc-khoe'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mArticleHealthy']; ?>
</option>
							<option value="hon-nhan-gia-dinh" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'hon-nhan-gia-dinh'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mArticleFamily']; ?>
</option>
							<option value="nau-an" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'nau-an'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mArticleCook']; ?>
</option>
						</select>
					</div>
				</div>


				
				
				
				<?php if ($this->_tpl_vars['formData']['fimage'] != ''): ?>
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div>
							<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" target="_blank"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" width="100" border="0" /></a><input type="checkbox" name="fdeleteimage" value="1" /><?php echo $this->_tpl_vars['lang']['controller']['formImageDeleteLabel']; ?>

						</div>
				</div>
				<?php endif; ?>
				
				
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryImage']; ?>
 :</label></div>
					<div class="form-entry-textbox">
						
						<input type="file" id="fimage" name="fimage" />
					</div>
				</div>
				
				
				
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['descriptionLabel']; ?>
 :</label></div>
					<div class="form-entry-input">
						<textarea name="fdescription" class="entry-textarea disablefocusfx wysiwyg" rows="30"><?php echo $this->_tpl_vars['myEntry']->description; ?>
</textarea><br />
					</div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryTag']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryTagTooltip']; ?>
" type="text" id="ftag" name="ftag" value="<?php echo $this->_tpl_vars['formData']['ftag']; ?>
" /></div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelated']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelatedTooltip']; ?>
 <?php echo $this->_tpl_vars['setting']['entry']['maxRelatedNumber']; ?>
)" type="text" id="frelated" name="frelated" value="<?php echo $this->_tpl_vars['formData']['frelated']; ?>
" /></div>
				</div>
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryslideshowform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryseoform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrymoderatorform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				

				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditBtn']; ?>
" />
					<div class="form-entry-delete-link"><a href="javascript:delm('<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/delete?token=<?php echo $_SESSION['securityToken']; ?>
')"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
</a></div>
				</div>
				
				<div class="clearboth"></div>
				</div>
			</form>
		</div><!-- end of .mainform-form -->
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


