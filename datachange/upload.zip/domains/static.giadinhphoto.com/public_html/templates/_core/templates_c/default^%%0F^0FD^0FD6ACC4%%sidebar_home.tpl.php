<?php /* Smarty version 2.6.26, created on 2010-09-26 14:59:19
         compiled from _controller/site/sidebar_home.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'sidebar_news', '_controller/site/sidebar_home.tpl', 34, false),array('modifier', 'date_format', '_controller/site/sidebar_home.tpl', 43, false),)), $this); ?>
<div id="secondary">

<?php if ($this->_tpl_vars['me']->id > 0): ?>
	<dl class="member">
	<dt><?php echo $this->_tpl_vars['lang']['controllergroup']['hi']; ?>
, <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html" title="Memberarea"><?php echo $this->_tpl_vars['me']->username; ?>
</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
logout.html" title="<?php echo $this->_tpl_vars['lang']['global']['mLogout']; ?>
" style="color:#999;"><?php echo $this->_tpl_vars['lang']['global']['mLogout']; ?>
</a></dt>
	</dl>
	
	<hr size="1" style="background:#eee;" color="#eee" />
<?php else: ?>
	<dl class="member">
	<dt><?php echo $this->_tpl_vars['lang']['controllergroup']['hi']; ?>
, <?php echo $this->_tpl_vars['lang']['controllergroup']['guest']; ?>
 | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html" title="<?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
" style="color:#999;"><?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
</a></dt>
	
	</dl>
	
	<hr />
<?php endif; ?>

<p class="paypal"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-paymentmethod.html"><img alt="Secure Payments by Paypal" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/img_paypal.gif"></a><span><?php echo $this->_tpl_vars['lang']['controllergroup']['secureByPaypal']; ?>
</span></p>
<ul class="banner">
<li><a href="#"><img alt="Digital SLR Store" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_store.jpg"></a></li>
<li><a href="#"><img alt="Canon 550D" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_digital.jpg"></a></li>
</ul>

<dl class="contest">
<dt class="title"><?php echo $this->_tpl_vars['lang']['controllergroup']['aboutThisContest']; ?>
</dt>
<dd>
<div class="clearfix">
<p><img alt="" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/img_contest.jpg"></p>
<dl>
<dt><?php echo $this->_tpl_vars['lang']['controllergroup']['sidebarPhotographer']; ?>
 </dt>
<dd>Member<span>FIAP, VAPA, HOPA</span></dd>
</dl>
</div>
<?php echo smarty_function_sidebar_news(array(), $this);?>

</dd>
<!-- / class contest --></dl>

<table cellspacing="0" cellpadding="0">
<tbody><tr>
<th colspan="2"><img alt="40 DAYS LEFT" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/img_days.gif"></th>
</tr>
<tr>
<td class="year" colspan="2"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxHeadingYear']; ?>
 ( <?php echo ((is_array($_tmp=time())) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>
 Hanoi GMT +7 )</td>
</tr>
<tr class="title">
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxEvent']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxDate']; ?>
</td>
</tr>
<tr>
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDate']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxClosingDateValue']; ?>
</td>
</tr>
<tr>
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxJudging']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxJudgingValue']; ?>
</td>
</tr>
<tr>
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxNotification']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxNotificationValue']; ?>
</td>
</tr>
<tr>
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxExhibitionDate']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxExhibitionDateValue']; ?>
</td>
</tr>
<tr>
<td><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxCatalogue']; ?>
</td>
<td class="date"><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxCatalogueValue']; ?>
</td>
</tr>
<tr>
<td class="online" colspan="2"><b><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxStatistic']; ?>
:</b> <?php echo $this->_tpl_vars['onlineVisitor']; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxStatisticText']; ?>
</td>
</tr>
<tr>
<td colspan="2">
<ul>
<li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxRegisteredUser']; ?>
: <?php echo $this->_tpl_vars['siteTotalUsers']; ?>
</li>
<li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxOfPhotoOnline']; ?>
: <?php echo $this->_tpl_vars['siteTotalPhotos']; ?>
</li>
<li><?php echo $this->_tpl_vars['lang']['controllergroup']['rightboxOfPhotoView']; ?>
: <?php echo $this->_tpl_vars['siteTotalViewPhotos']; ?>
</li>
</ul>
</td>
</tr>
</tbody></table>
<!-- / id secondary --></div>