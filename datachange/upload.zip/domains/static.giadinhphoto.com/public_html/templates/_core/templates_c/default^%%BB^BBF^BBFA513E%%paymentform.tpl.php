<?php /* Smarty version 2.6.26, created on 2013-10-28 15:44:40
         compiled from _controller/site/checkout/paymentform.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', '_controller/site/checkout/paymentform.tpl', 82, false),)), $this); ?>
<script src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/tabcontent.js" type="text/javascript"></script>
<link href="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/css/tabcontent.css" rel="stylesheet" type="text/css" />
<div id="pagebody">
    	    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
		<!-- code html o day -->
		
		<div id="page"> <br /><br />
						<strong style="font-size:21px"><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</strong><br /><br />
						
						<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
								
								<div class="paymentOptionTotal">
									<?php echo $this->_tpl_vars['lang']['controller']['paymentTotal']; ?>
 : <span style="font-weight:bold"><?php echo $this->_tpl_vars['currency']->formatPrice($this->_tpl_vars['myProduct']->price); ?>
</span>
								</div>
								<br />								
								<strong style="font-size:21px"><?php echo $this->_tpl_vars['lang']['controller']['paymentSelectHeading']; ?>
</strong>
								<br /><br />		
									<?php if ($this->_tpl_vars['errorCheckout'] != ''): ?>
									<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['errorCheckout'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
									<?php endif; ?>
									
									
		<ul class="tabs" data-persist="true">
            <li><a href="#tab1"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCardTitle']; ?>
</a></li>
            <li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCashTitle']; ?>
</a></li>
            <li><a href="#tab3"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormBankTitle']; ?>
</a></li>
			<li><a href="#tab4"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormPostofficeTitle']; ?>
</a></li>
        </ul>
        <div class="tabcontents">
            <div id="tab1">
				<table border="0" width="100%" style="background:url(<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/paypal_verified.jpg) no-repeat top right;">
											 <tbody><tr>
												<td colspan="2">
												 <form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/payment" name="manage">
													<table width="100%">
													<tr>
														<td colspan="2" style="font-weight:bold; padding:10px 0 10px 0; "><?php echo $this->_tpl_vars['lang']['controller']['paymentFormHelp']; ?>
</td>
													</tr>
													<tr>
														<td width="150" align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCardType']; ?>
:</td>
														<td>
															<label><input type="radio" name="fcardtype" value="MasterCard" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'MasterCard'): ?>checked<?php endif; ?> /><img align="top" alt="MasterCard" title="MasterCard" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_mastercard.gif" border="1"/></label>
															&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Visa" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Visa'): ?>checked<?php endif; ?> /><img align="top" alt="Visa" title="Visa" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_visa.gif" border="1"/></label>
															&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Discover" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Discover'): ?>checked<?php endif; ?> /><img align="top" alt="Discover" title="Discover" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_discover.gif" border="1"/></label>
															&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Amex" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Amex'): ?>checked<?php endif; ?> /><img align="top" alt="Amex" title="Amex" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_amex.gif" border="1"/></label>
														</td>
													</tr>
													
													<tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormFirstname']; ?>
:</td>
														<td align="left"><input type="text" name="ffirstname" value="<?php if ($this->_tpl_vars['formData']['ffirstname'] != ''): ?><?php echo $this->_tpl_vars['formData']['ffirstname']; ?>
<?php else: ?><?php echo $this->_tpl_vars['orderInformation']['billing_firstname']; ?>
<?php endif; ?>"/></td>
													</tr>
													<tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormLastname']; ?>
:</td>
														<td align="left"><input type="text" name="flastname" value="<?php if ($this->_tpl_vars['formData']['flastname'] != ''): ?><?php echo $this->_tpl_vars['formData']['flastname']; ?>
<?php else: ?><?php echo $this->_tpl_vars['orderInformation']['billing_lastname']; ?>
<?php endif; ?>"/></td>
													</tr>
													
													<tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormZipcode']; ?>
:</td>
														<td align="left"><input type="text" name="fzipcode" value="<?php echo $this->_tpl_vars['formData']['fzipcode']; ?>
" size="5"/></td>
													</tr>
													<tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCardNumber']; ?>
:</td>
														<td align="left"><input type="text" name="fcardnumber" value="<?php echo $this->_tpl_vars['formData']['fcardnumber']; ?>
" size="30"/></td>
													</tr>
													<tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCvv']; ?>
:</td>
														<td align="left"><input type="text" name="fcvvnumber" value="<?php echo $this->_tpl_vars['formData']['cvvnumber']; ?>
" size="5"/></td>
													</tr>
												 <tr class="directpayment_data">
														<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDate']; ?>
:</td>
														<td align="left"><select name="fexpiredmonth"><option value="0">- <?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDateMonth']; ?>
 -</option><?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['monthOptions'],'selected' => $this->_tpl_vars['formData']['fexpiredmonth']), $this);?>
</select>
																<select name="fexpiredyear"><option value="0">- <?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDateYear']; ?>
 -</option><?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['yearOptions'],'selected' => $this->_tpl_vars['formData']['fexpiredyear']), $this);?>
</select>
														
														</td>
													</tr>
													
													<tr>
														<td></td>
														<td align="left"><br /><input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['paymentButton']; ?>
.gif" style="border:0;" name="submitimage" />
																<input type="hidden" name="fsubmit" value="1" />
														</td>
													</tr>
												</table>
												</form>
												</td>
												</tr>												
											
																												
											</tbody></table>
<p>&nbsp;</p>
<table width="500" border="4" bordercolor="#67b718" cellpadding="8" cellspacing="8">
												<tr>
													<td width="150" align="center"><strong><?php echo $this->_tpl_vars['lang']['controller']['paymentOrLabel']; ?>
 PayPal</strong></td>
													<td align="left">
													<form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/payment<?php if ($this->_tpl_vars['orderInformation']['invoiceid'] != ''): ?>/invoice/<?php echo $this->_tpl_vars['orderInformation']['invoiceid']; ?>
<?php endif; ?>#selectpayment"> 
														 <input type="hidden" name="method" value="SetExpressCheckout" />
														 <input type="hidden" name="fsubmit" value="1" />
															<input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_paypal.gif" style="border:0;"/>
													</form>
													</td>
												</tr>

</table> 
<p>&nbsp;</p>                                           
			</div>
			
			<div id="tab2">
				<form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/placeorder">
				<div class="paymentMethodSelectGroup" id="paymentMethodSelectCash">
					<div class="paymentMethodBody">
						<div class="paymentMethodText"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCashText']; ?>
<br /><br /></div>
						
						<div class="comment">
							<span style="font-size:11px; color:#555"><i><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCashCommentLabel']; ?>
:</i></span><br />
							<textarea name="fcomment" rows="4" cols="50"></textarea>
							<input type="hidden" name="ftype" value="cash" />
							<br />
						</div>
						<div class="button"><input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['paymentButton']; ?>
.gif" alt="Place Order" /></div>
						<div class="clear"></div>
					</div>
				</div><!-- end .paymentMethodSelectGroup -->
				</form>
			</div>
			<div id="tab3">
				<form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/placeorder">
				<div class="paymentMethodSelectGroup" id="paymentMethodSelectBank">
					<div class="paymentMethodBody">

						<div class="paymentMethodText"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormBankText']; ?>
<br /><br /></div>
						
						<div class="comment">
							<span style="font-size:11px; color:#555"><i><?php echo $this->_tpl_vars['lang']['controller']['paymentFormBankCommentLabel']; ?>
:</i></span><br />
							<textarea name="fcomment" rows="4" cols="50"></textarea>
							<input type="hidden" name="ftype" value="bank" />
							<br />
						</div>
						<div class="button"><input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['paymentButton']; ?>
.gif" alt="Place Order" /></div>
						<div class="clear"></div>
					</div>
				</div><!-- end .paymentMethodSelectGroup -->
				</form>			
			</div>
			
			<div id="tab4">
				<form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/placeorder">
				<div class="paymentMethodSelectGroup" id="paymentMethodSelectPostoffice">
					<div class="paymentMethodBody">
						<div class="paymentMethodText"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormPostofficeText']; ?>
<br /><br /></div>
						
						<div class="comment">
							<span style="font-size:11px; color:#555"><i><?php echo $this->_tpl_vars['lang']['controller']['paymentFormPostofficeCommentLabel']; ?>
:</i></span><br />
							<textarea name="fcomment" rows="4" cols="50"></textarea>
							<input type="hidden" name="ftype" value="postoffice" />
							<br />
						</div>
						<div class="button"><input type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['paymentButton']; ?>
.gif" alt="Place Order" /></div>
						<div class="clear"></div>
					</div>

				</form>
			</div>
		</div>
<p>&nbsp;</p>  								
								<div class="paymentMethod">
									<strong><?php echo $this->_tpl_vars['myPaymentPage']->title[$this->_tpl_vars['langCode']]; ?>
</strong>
									<div><?php echo $this->_tpl_vars['myPaymentPage']->contents[$this->_tpl_vars['langCode']]; ?>
</div>
								</div>
							
						
						</div>
					</div>
		
		
		
		<!-- ---->
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->