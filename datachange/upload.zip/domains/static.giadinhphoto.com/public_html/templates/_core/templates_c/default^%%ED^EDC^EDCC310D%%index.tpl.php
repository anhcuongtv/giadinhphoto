<?php /* Smarty version 2.6.26, created on 2010-07-09 10:50:44
         compiled from _controller/site/helloworld/index.tpl */ ?>
<html>
	<head>
		<title>Hello World App</title>
	</head>
	<body>
		<h1>This is Hello world App</h1>
		<hr />
		Variable 1: <?php echo $this->_tpl_vars['stringA']; ?>
<br />
		Variable 2: <?php echo $this->_tpl_vars['stringB']; ?>
<br />
		<hr />
		Copyright 2010 &copy; TOOSOL Company. All Rights Reserved.
	</body>
</html>
	