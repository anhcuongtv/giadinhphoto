<?php /* Smarty version 2.6.26, created on 2010-07-21 10:25:56
         compiled from _controller/site/helloworld/add.tpl */ ?>
<?php echo $this->_tpl_vars['success']; ?>