<?php /* Smarty version 2.6.26, created on 2010-07-15 13:17:43
         compiled from breadcrumb.tpl */ ?>
<?php if ($this->_tpl_vars['breadcrumb'] != ''): ?>
<div id="breadcrumb">
  <?php $_from = $this->_tpl_vars['breadcrumb']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['breadcrumb'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['breadcrumb']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['i']):
        $this->_foreach['breadcrumb']['iteration']++;
?>
	  <?php if (($this->_foreach['breadcrumb']['iteration'] <= 1)): ?>
	  <?php else: ?>
		  &raquo;
	  <?php endif; ?>
	  <?php if ($this->_tpl_vars['i']['link'] != ''): ?>
	  <a href="<?php echo $this->_tpl_vars['i']['link']; ?>
" title="<?php echo $this->_tpl_vars['i']['title']; ?>
"><?php echo $this->_tpl_vars['i']['title']; ?>
</a>
	  <?php else: ?>
	  <span><?php echo $this->_tpl_vars['i']['title']; ?>
</span>
	  <?php endif; ?>
  <?php endforeach; endif; unset($_from); ?>
 </div><!-- end of #breadcrumb -->
<?php endif; ?>