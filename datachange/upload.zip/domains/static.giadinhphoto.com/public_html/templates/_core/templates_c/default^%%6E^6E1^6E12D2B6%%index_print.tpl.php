<?php /* Smarty version 2.6.26, created on 2010-09-06 21:47:08
         compiled from _controller/admin/index_print.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', '_controller/admin/index_print.tpl', 8, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Vo Duy Tuan, tuanmaster2002@yahoo.com" />
<meta name="description" content="<?php echo $this->_tpl_vars['setting']['general_metatagDescription']; ?>
" />
<meta name="keywords" content="<?php echo $this->_tpl_vars['setting']['general_metatagKeyword']; ?>
" />
<title><?php echo ((is_array($_tmp=@$this->_tpl_vars['pageTitle'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['general_webtitle']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['general_webtitle'])); ?>
</title>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/styles/main.css" type="text/css" media="screen"/>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/jscripts/swfobject.js"></script>
</head>

<body bgcolor="#ffffff" style="background:#ffffff;">
<?php echo $this->_tpl_vars['contents']; ?>

<center>
<div class="print_this_page"><a href="javascript:window.print()"><img alt="print this page" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['langCode']; ?>
/print_page.png" width="91" height="28" border="0" /></a></div>
</center>
<hr />
<table cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top">
     
      
      <div>
      	Website: <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
"><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
</a>
      </div>
    </td>
    
  </tr>
</table>

</body>
</html>