<?php /* Smarty version 2.6.26, created on 2010-07-06 15:23:44
         compiled from _mail/site/reportabuse/admin.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'nl2br', '_mail/site/reportabuse/admin.tpl', 8, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyMailGroupContainer'])."header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

  <h2>Website has new Abuse Report at <?php echo $this->_tpl_vars['datecreated']; ?>
</h2>
  <p>Abuse Type: <b><?php echo $this->_tpl_vars['abuseType']; ?>
</b></p>
  <p>Abuse ID: <b><?php echo $this->_tpl_vars['myAbuse']->id; ?>
</b></p>
  <p>User ID: <b><?php echo $this->_tpl_vars['myAbuse']->userId; ?>
</b></p>
  <p>Username: <b><?php echo $this->_tpl_vars['me']->username; ?>
</b></p>
  <p>Note: "<i><?php echo ((is_array($_tmp=$this->_tpl_vars['myAbuse']->note)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</i>"</p>
  <p>------------more abuse information------------------------</p>
  <?php if ($this->_tpl_vars['abuseType'] == 'Entry'): ?>
  	<p>Entry Title: <b><a href="<?php echo $this->_tpl_vars['myAbuse']->entry->getFullSeoUrl(); ?>
" title="Click here to go this entry"><?php echo $this->_tpl_vars['myAbuse']->entry->title; ?>
</a> (ID: <?php echo $this->_tpl_vars['myAbuse']->entry->id; ?>
)</b>
		(<a href="<?php echo $this->_tpl_vars['myAbuse']->entry->getFullSeoUrl(); ?>
/edit">Edit this entry</a>)
	</p>
  <?php elseif ($this->_tpl_vars['abuseType'] == 'Entry Comment'): ?>
  	<p>Comment: "<i><?php echo ((is_array($_tmp=$this->_tpl_vars['myAbuse']->comment->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</i>"
		(<a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
entrycomment/edit/id/<?php echo $this->_tpl_vars['myAbuse']->id; ?>
">Edit this comment</a>)
	</p>
  <?php elseif ($this->_tpl_vars['abuseType'] == 'Quiz Comment'): ?>
  	<p>Comment: "<i><?php echo ((is_array($_tmp=$this->_tpl_vars['myAbuse']->comment->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</i>"
		(<a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quizcomment/edit/id/<?php echo $this->_tpl_vars['myAbuse']->id; ?>
">Edit this comment</a>)
	</p>
 	<?php endif; ?>
  
 
  

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyMailGroupContainer'])."footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>