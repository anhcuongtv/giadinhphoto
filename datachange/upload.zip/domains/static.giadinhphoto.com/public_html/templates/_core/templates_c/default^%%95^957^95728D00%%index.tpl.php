<?php /* Smarty version 2.6.26, created on 2013-10-30 16:40:57
         compiled from _controller/site/register/index.tpl */ ?>
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>		
		</h1>
        <div id="content">
		
				<div id="page">
					<strong style="font-size:21px"><?php echo $this->_tpl_vars['page']->title[$this->_tpl_vars['langCode']]; ?>
</strong>
					<div class="contents"><?php echo $this->_tpl_vars['page']->contents[$this->_tpl_vars['langCode']]; ?>
</div>



<?php echo '
<script type="text/javascript">
var RecaptchaOptions = {
   theme : \'clean\'
};
</script>
'; ?>

<table width="630" border="0" align="center" cellpadding="0" cellspacing="0" class="form_input">
  <tbody><tr>
    <td><table width="630" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
          	<td height="8"></td>
          </tr>  
          <tr>
            <td  height="40" align="left" style="border-bottom:2px solid #67b718; text-transform:uppercase"><strong><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</strong></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td class="help_txt" align="left"><?php echo $this->_tpl_vars['lang']['controller']['help']; ?>
</td>
          </tr>
          <tr>
          	<td height="8"></td>
          </tr>  
        </tbody></table></td>
  </tr>
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
  <tr>
    <td>
    
    
    <form method="post" action="">  
    <table width="630" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr>
        <td width="8" valign="top">&nbsp;</td>
        <td><table width="614" border="0" cellspacing="0" cellpadding="0">
          <tbody>
		  
		  <!-- row -->
          <tr>
            <td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['username']; ?>
</span> <span class="content_txt_10"></span></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td></td>
          </tr>
          <tr>
            <td><input name="fusername" type="text" id="username" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['formData']['fusername']; ?>
"></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
			<td colspan="2" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['username']; ?>
</em></td>
            <td height="20">&nbsp;</td>
          </tr>
		  <!-- end row -->
		  
		  <!-- Row -->
		  <tr>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['password']; ?>
</td>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['password2']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td height="8"></td>
          </tr>
          <tr>
            <td><input name="fpassword" type="password" id="password" style="width:280px;" maxlength="75"></td>
            <td><input name="fpassword2" type="password" id="password2" style="width:280px;" maxlength="75"></td>
          </tr>
          <tr>
            <td height="20" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['password']; ?>
</em></td>
            <td class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['password']; ?>
</em></td>
          </tr>
		  <!-- end row -->
		  
		   <!-- Row -->
		  <tr>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['email']; ?>
</td>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['email2']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td height="8"></td>
          </tr>
          <tr>
            <td><input name="femail" type="text" id="email" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['femail']; ?>
"></td>
            <td><input name="femail2" type="text" id="email2" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['femail2']; ?>
"></td>
          </tr>
          <tr>
			<td height="20" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['email']; ?>
</em></td>
			<td class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['email']; ?>
</em></td>
          </tr>
		  <!-- end row -->
		  
		  <!-- Row -->
		  <tr>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['fullname']; ?>
</td>
            <td width="292" class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['gioitinh']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td height="8"></td>
          </tr>
          <tr>
            <td><input name="ffullname" type="text" id="fullname" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['ffullname']; ?>
"></td>
            <td>
				<label for="selectBox">
							<select id="gioitinh" name="fgioitinh" style="height:25px; width:280px">
							  <option value="male" <?php if ($this->_tpl_vars['formData']['fgioitinh'] == 'male'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['gioitinhnam']; ?>
</option>							  
							  <option value="female" <?php if ($this->_tpl_vars['formData']['fgioitinh'] == 'female'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['gioitinhnu']; ?>
</option>
							  
							</select>
                </label>	
			</td>
          </tr>
          <tr>
            <td height="20" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['fullname']; ?>
</em></td>
			<td class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['gioitinh']; ?>
</em></td>
          </tr>
		  <!-- end row -->
		  
		  <!-- row -->
          <tr>
            <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['country']; ?>
</td>
            <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['city']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td height="8"></td>
          </tr>
          <tr>
            <td>
				<div> 
                	<label for="selectBox">
							<select id="country" name="fcountry" style="height:25px; width:280px">
							  <option value="0">Select one</option>
							  <?php $_from = $this->_tpl_vars['setting']['country']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['country']):
?>
							  	<option value="<?php echo $this->_tpl_vars['key']; ?>
" <?php if ($this->_tpl_vars['formData']['fcountry'] == $this->_tpl_vars['key']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['country']; ?>
</option>
							  <?php endforeach; endif; unset($_from); ?>                                   
							</select>
                </label>
                </div>
            </td>
            <td>
				<input name="fcity" type="text" id="city" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['fcity']; ?>
">
			</td>
          </tr>
          <tr>
            <td height="20" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['country']; ?>
</em></td>
			<td class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['city']; ?>
</em></td>
          </tr>
		  <!-- end row -->
		  
		  <!-- row -->
          <tr>
            <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['address']; ?>
</td>
            <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['phone1']; ?>
</td>
          </tr>
          <tr>
            <td height="8"></td>
            <td></td>
          </tr>
          <tr>
            <td>
				<input name="faddress" type="text" id="address" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['faddress']; ?>
">
            </td>
            <td>
				<input name="fphone1" type="text" id="phone1" style="width:280px;" maxlength="75" value="<?php echo $this->_tpl_vars['formData']['fphone1']; ?>
">				
			</td>
          </tr>
          <tr>
			<td height="20" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['address']; ?>
</em></td>
			<td class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['phone1']; ?>
</em></td>
          </tr>
		  <!-- end row -->
		  
		  <!-- row -->
          <tr>
            <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['securityCode']; ?>
</td>
            <td class="content_txt_12"></td>
          </tr>
          <tr>
            <td height="8"></td>
            <td></td>
          </tr>
          <tr>
            <td height="20" colspan="2"><?php echo $this->_tpl_vars['recaptchahtml']; ?>
</td>
            <td>&nbsp;</td>
          </tr>
          <tr>			
            <td colspan="2" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['captcha']; ?>
</em></td>
			<td height="20">&nbsp;</td>
          </tr>
		  <!-- end row -->
		  
          <tr>
            <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tbody><tr>
                <td width="16"><input type="checkbox" name="fdongy" id="dongy" value="1"></td>
                <td width="8"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/spacer.gif" width="8" height="8" align="top"></td>
                <td class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['foottext1']; ?>
</td>
              </tr>
			  <tr>			
				<td colspan="3" class="footer_btn"><em class="content_txt_10" style="color:#FF3300"><?php echo $this->_tpl_vars['error']['dongy']; ?>
</em></td>
				<td height="20">&nbsp;</td>
				<td height="20">&nbsp;</td>
			  </tr>
            </tbody></table></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="25">&nbsp;</td>
            <td height="25">&nbsp;</td>
          </tr>
          <tr>
            <td><input name="fsubmit" type="image" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['btnSend']; ?>
.gif" border="0" align="top" id="<?php echo $this->_tpl_vars['lang']['controller']['btnSend']; ?>
" /></td>
            <td>&nbsp;</td>
          </tr>
        </tbody></table></td>
        <td width="8" valign="bottom">&nbsp;</td>
      </tr>
    </tbody></table>
    </form>
	</td>
  </tr>
</tbody>
</table>
<br />
<br />
                    
				</div>		
		<!-- ---->       	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->    
</div><!-- wrapper -->