<?php /* Smarty version 2.6.26, created on 2010-07-30 11:56:57
         compiled from _controller/admin/newscategory/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'htmlspecialchars', '_controller/admin/newscategory/edit.tpl', 24, false),array('modifier', 'count', '_controller/admin/newscategory/edit.tpl', 95, false),array('modifier', 'date_format', '_controller/admin/newscategory/edit.tpl', 152, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_add']; ?>
</h2>

<form action="" method="post" name="myform">
<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_add']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['formFormLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoLabel']; ?>
</a></li>
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			
				<fieldset>
				<p>
					<label><?php echo $this->_tpl_vars['lang']['controller']['formNameLabel']; ?>
 <span class="star_require">*</span> : </label>
					<input type="text" name="fname" id="fname" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fname']); ?>
" class="text-input">
				</p>
				
				<p>
					<label><?php echo $this->_tpl_vars['lang']['controller']['formParentLabel']; ?>
: </label>
					<select name="fparentid" id="fparentid">
						<option value="0">- - - - - - - - - - - - - - - - - - -</option>
						<?php $_from = $this->_tpl_vars['parentCategories']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['parentCat']):
?>
							<?php if ($this->_tpl_vars['parentCat']->id != $this->_tpl_vars['formData']['fid']): ?>
								<option value="<?php echo $this->_tpl_vars['parentCat']->id; ?>
" title="<?php echo $this->_tpl_vars['parentCat']->title; ?>
" <?php if ($this->_tpl_vars['parentCat']->id == $this->_tpl_vars['formData']['fparentid']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['parentCat']->title; ?>
</option>
							<?php endif; ?>
						<?php endforeach; endif; unset($_from); ?>
					</select>
				</p>
				
				<p>
					<label><?php echo $this->_tpl_vars['lang']['controller']['formShowLabel']; ?>
: </label>
					<select name="fisshow" id="fisshow">
						<option value="1"><?php echo $this->_tpl_vars['lang']['controllergroup']['formYesLabel']; ?>
</option>
						<option value="0" <?php if ($this->_tpl_vars['formData']['fisshow'] == '0'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controllergroup']['formNoLabel']; ?>
</option>
					</select>
				</p>
				
				</fieldset>
			
		</div>
		
		<div class="tab-content" id="tab2">
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoUrlLabel']; ?>
 : </label>
				<input type="text" name="fseourl" id="fseourl" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseourl']); ?>
" class="text-input">
				<br />
				<small><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['conf']['seoDirNewsCategory']; ?>
/[SEO_URL]-[ID].html</small>
			</p>
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoTitleLabel']; ?>
 : </label>
				<input type="text" name="fseotitle" id="fseotitle" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseotitle']); ?>
" class="text-input">
			</p>
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoKeywordLabel']; ?>
 : </label>
				<textarea class="text-input"  rows="2" name="fseokeyword" id="fseokeyword"><?php echo $this->_tpl_vars['formData']['fseokeyword']; ?>
</textarea>
			</p>
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoDescriptionLabel']; ?>
 : </label>
				<textarea class="text-input"  rows="2" name="fseodescription" id="fseodescription"><?php echo $this->_tpl_vars['formData']['fseodescription']; ?>
</textarea>
			</p>
			
		</div>
	
		
	</div>
	
	<div class="content-box-content-alt">
		<fieldset>
		<p>
			<input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formAddSubmit']; ?>
" class="button buttonbig">
			<br /><small><span class="star_require">*</span> : <?php echo $this->_tpl_vars['lang']['controllergroup']['formRequiredLabel']; ?>
</small>
		</p>
		</fieldset>
	</div>

    	
</div>
</form>


<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_subcat']; ?>
 (<?php echo count($this->_tpl_vars['subcategories']); ?>
)</h3>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory/add/parentid/<?php echo $this->_tpl_vars['formData']['fid']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['head_addsub']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
			<form action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory" method="post" name="manage" onsubmit="return confirm('Are You Sure ?');">
				<table class="grid">
					
				<?php if (count($this->_tpl_vars['subcategories']) > 0): ?>
					<thead>
						<tr>
						   <th width="40"><input class="check-all" type="checkbox" /></th>
							<th width="30"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</th>
							<th width="50"><?php echo $this->_tpl_vars['lang']['controllergroup']['formOrderLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formNameLabel']; ?>
</th>							
							<th width="100" class="td_center"><?php echo $this->_tpl_vars['lang']['controller']['formShowLabel']; ?>
</th>
							<th width="120"><?php echo $this->_tpl_vars['lang']['controller']['formDateModifiedLabel']; ?>
</th>
							<th width="70"></th>
						</tr>
					</thead>
					
					<tfoot>
						<tr>
							<td colspan="8">
								<div class="bulk-actions align-left">
									<select name="fbulkaction">
										<option value=""><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSelectLabel']; ?>
</option>
										<option value="delete"><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionDeletetLabel']; ?>
</option>
									</select>
									<input type="submit" name="fsubmitbulk" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSubmit']; ?>
" />
									<input type="submit" name="fchangeorder" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formChangeOrderSubmit']; ?>
" />
								</div>
						
								<div class="clear"></div>
							</td>
						</tr>
					</tfoot>
					<tbody>
					<?php $_from = $this->_tpl_vars['subcategories']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['category']):
?>
					
						<tr>
							<td><input type="checkbox" name="fbulkid[]" value="<?php echo $this->_tpl_vars['category']->id; ?>
" <?php if (in_array ( $this->_tpl_vars['category']->id , $this->_tpl_vars['formData']['fbulkid'] )): ?>checked="checked"<?php endif; ?>/></td>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['category']->id; ?>
</td>
							<td><input type="text" size="3" value="<?php echo $this->_tpl_vars['category']->order; ?>
" name="forder[<?php echo $this->_tpl_vars['category']->id; ?>
]" class="text-input" /></td>
							<td><a title="URL: <?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['conf']['seoDirNewsCategory']; ?>
/<?php echo $this->_tpl_vars['category']->seoUrl; ?>
-<?php echo $this->_tpl_vars['category']->id; ?>
.html" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory/edit/id/<?php echo $this->_tpl_vars['category']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['category']->name; ?>
</a>
								<?php if (count($this->_tpl_vars['category']->sub) > 0): ?>
									<ul>
										<?php $_from = $this->_tpl_vars['category']->sub; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['subcat']):
?>
											<li><a title="URL: <?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['conf']['seoDirNewsCategory']; ?>
/<?php echo $this->_tpl_vars['subcat']->seoUrl; ?>
-<?php echo $this->_tpl_vars['subcat']->id; ?>
.html" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory/edit/id/<?php echo $this->_tpl_vars['subcat']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['subcat']->name; ?>
</a></li>
										<?php endforeach; endif; unset($_from); ?>
									</ul>
								<?php endif; ?>
							</td>
							<td class="td_center"><?php if ($this->_tpl_vars['category']->isshow == 1): ?><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/tick_circle.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formYesLabel']; ?>
" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formYesLabel']; ?>
" width="16"/><?php else: ?><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross_circle.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formNoLabel']; ?>
" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formNoLabel']; ?>
" width="16"/><?php endif; ?></td>
							<td><?php echo ((is_array($_tmp=$this->_tpl_vars['category']->datemodified)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatSmarty'])); ?>
</td>
							<td><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory/edit/id/<?php echo $this->_tpl_vars['category']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
								<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
newscategory/delete/id/<?php echo $this->_tpl_vars['category']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a>
							</td>
						</tr>
						
					
					<?php endforeach; endif; unset($_from); ?>
					</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="10"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
	
	</div>

    	
</div>
