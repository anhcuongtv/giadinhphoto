<?php /* Smarty version 2.6.26, created on 2013-10-26 02:18:57
         compiled from _controller/admin/user/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'htmlspecialchars', '_controller/admin/user/edit.tpl', 46, false),array('modifier', 'count', '_controller/admin/user/edit.tpl', 142, false),array('modifier', 'upper', '_controller/admin/user/edit.tpl', 146, false),array('modifier', 'date_format', '_controller/admin/user/edit.tpl', 178, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_edit']; ?>
</h2>

<form action="" method="post" name="myform">
<input type="hidden" name="ftoken" value="<?php echo $_SESSION['userEditToken']; ?>
" />
<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_edit']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['formFormLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
		</ul>
		<ul class="content-box-tabs">
			<li><a href="#tab2">Ảnh của thành viên</a></li> <!-- href must be unique and match the id of target div -->
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			
			<fieldset>
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['formGroupLabel']; ?>
 <span class="star_require">*</span> : </label>
				
				<?php if ($this->_tpl_vars['me']->id == $this->_tpl_vars['myUser']->id): ?>
					<input type="text" name="fgroupid" id="fgroupid" size="40" disabled="disabled" style="color:#aaa;" value="<?php echo $this->_tpl_vars['myUser']->groupname($this->_tpl_vars['myUser']->groupid,$this->_tpl_vars['lang']); ?>
" class="text-input">
				<?php else: ?>	
					<select id="fgroupid" name="fgroupid">
					<option value="">- - - -</option>
					<?php $_from = $this->_tpl_vars['userGroups']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['groupname']):
?>
						<?php if ($this->_tpl_vars['groupPriorityList'][$this->_tpl_vars['key']] > $this->_tpl_vars['me']->groupPriority): ?>
							<option value="<?php echo $this->_tpl_vars['key']; ?>
" <?php if ($this->_tpl_vars['formData']['fgroupid'] == $this->_tpl_vars['key']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['groupname']; ?>
</option>
						<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
					</select>
				<?php endif; ?>
					
				
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['formEmailLabel']; ?>
 <span class="star_require">*</span> : </label>
				<input type="text" name="femail" id="femail" size="40" disabled="disabled" style="color:#aaa;" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['femail']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['formUserNameLabel']; ?>
 : </label>
				<input type="text" name="fusername" id="fusername" size="40" disabled="disabled" style="color:#aaa;" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fusername']); ?>
" class="text-input">
			</p>
			
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['formPasswordLabel']; ?>
 <span class="star_require">*</span> : </label>
				<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
user/resetpass/id/<?php echo $this->_tpl_vars['myUser']->id; ?>
')"><?php echo $this->_tpl_vars['lang']['controller']['resetpass']; ?>
</a>
			</p>
			
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['formPasswordLabel']; ?>
 by admin <span class="star_require">*</span> : </label>
				<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
user/resetpassbyadmin/id/<?php echo $this->_tpl_vars['myUser']->id; ?>
')"><?php echo $this->_tpl_vars['lang']['controller']['resetpass']; ?>
</a>
			</p>
			
			
			<hr />
			<p>
				<label> FULL NAME  : </label>
				<input type="text" name="ffullname" id="ffullname" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['ffullname']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['honor']; ?>
  : </label>
				<input type="text" name="fhonor" id="fhonor" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fhonor']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['address']; ?>
  : </label>
				<input type="text" name="faddress" id="faddress" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['faddress']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['address2']; ?>
  : </label>
				<input type="text" name="faddress2" id="faddress2" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['faddress2']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['zipcode']; ?>
  : </label>
				<input type="text" name="fzipcode" id="fzipcode" size="10" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fzipcode']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['city']; ?>
  : </label>
				<input type="text" name="fcity" id="fcity" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fcity']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['region']; ?>
  : </label>
				<input type="text" name="fregion" id="fregion" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fregion']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['country']; ?>
  : </label>
				<select id="fcountry" name="fcountry">
					<option value="">- - - -</option>
					<?php $_from = $this->_tpl_vars['setting']['country']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['country']):
?>
						<option value="<?php echo $this->_tpl_vars['key']; ?>
" <?php if ($this->_tpl_vars['formData']['fcountry'] == $this->_tpl_vars['key']): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['country']; ?>
</option>
					<?php endforeach; endif; unset($_from); ?>
				</select>
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['phone1']; ?>
  : </label>
				<input type="text" name="fphone1" id="fphone1" size="20" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fphone1']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['phone2']; ?>
  : </label>
				<input type="text" name="fphone2" id="fphone2" size="20" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fphone2']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['psamembership']; ?>
  : </label>
				<input type="text" name="fpsamembership" id="fpsamembership" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fpsamembership']); ?>
" class="text-input">
			</p>
			<p>
				<label><?php echo $this->_tpl_vars['lang']['controller']['photoclub']; ?>
  : </label>
				<input type="text" name="fphotoclub" id="fphotoclub" size="40" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fphotoclub']); ?>
" class="text-input">
			</p>
            
            <p><input type="checkbox" name="fpaid" value="1" <?php if ($this->_tpl_vars['formData']['fpaid'] == 1): ?>checked="checked"<?php endif; ?> /> Da Thanh Toan</p>           

			</fieldset>
		
			
		</div>
		
		<div class="tab-content" id="tab2">		
			
			
			<form action="" method="post" name="manage" onsubmit="return confirm('Are You Sure ?');">
				<table class="grid" cellpadding="5" width="100%">
			<?php if (count($this->_tpl_vars['myPhotos']) > 0): ?>
					<thead>
						<tr>
						   
							<th width="30"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">ID</a></th>
							<th width="60">Photo</th>
							<th class="td_left"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/name/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'name'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">Name</a></th>
							<th>Section</th>		
							<th class="td_right"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/filesize/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'filesize'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">File Size</a></th>				
							<th class="td_center"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/resolution/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'resolution'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">Resolution</a></th>
							<th class="td_center"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/view/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'view'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">View</a></th>				
							<th align="left"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/username/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'username'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">Poster</a></th>				
							
							<th align="left"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>">Date Posted</a></th>
							<th width="70"></th>
						</tr>
					</thead>
					
					
					<tbody>
				<?php $_from = $this->_tpl_vars['myPhotos']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
					
						<tr>
							
							
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['photo']->id; ?>
</td>
							<td><a href="<?php if ($this->_tpl_vars['photo']->fileserver == 'vn'): ?><?php echo $this->_tpl_vars['setting']['statichost']; ?>
<?php echo $this->_tpl_vars['setting']['contestphoto']['imageDirectoryStatic']; ?>
<?php echo $this->_tpl_vars['photo']->filethumb1; ?>
<?php else: ?><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['contestphoto']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['photo']->filethumb1; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><img src="<?php if ($this->_tpl_vars['photo']->fileserver == 'vn'): ?><?php echo $this->_tpl_vars['setting']['statichost']; ?>
<?php echo $this->_tpl_vars['setting']['contestphoto']['imageDirectoryStatic']; ?>
<?php echo $this->_tpl_vars['photo']->filethumb2; ?>
<?php else: ?><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['contestphoto']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['photo']->filethumb2; ?>
<?php endif; ?>" width="60" /></a></td>
							<td><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
contestphoto/edit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><b><?php echo $this->_tpl_vars['photo']->name; ?>
</b></a>
								<div><small><?php if ($this->_tpl_vars['photo']->description != ''): ?>Tag: <?php echo $this->_tpl_vars['photo']->description; ?>
<?php endif; ?></small></div>

							</td>
							<td><?php echo $this->_tpl_vars['photo']->section; ?>
</td>
							<td class="td_right"><?php echo $this->_tpl_vars['photo']->formatFileSize(); ?>
</td>
							<td class="td_center"><?php echo $this->_tpl_vars['photo']->resolution; ?>
</td>
							<td class="td_center"><?php echo $this->_tpl_vars['photo']->view; ?>
</td>
							<td><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
user/edit/id/<?php echo $this->_tpl_vars['photo']->poster->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['photo']->poster->username; ?>
</a></td>
							<td><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp) : smarty_modifier_date_format($_tmp)); ?>
</td>
							<td><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
contestphoto/edit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
								<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
photocontest/delete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
?token=<?php echo $_SESSION['securityToken']; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a>
						</tr>
						
					
				<?php endforeach; endif; unset($_from); ?>
				</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="9"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
			
			
			
			
		</div>
		
	</div>
	
	<div class="content-box-content-alt">
		<fieldset>
		<p>
			<input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formUpdateSubmit']; ?>
" class="button buttonbig">
			<br /><small><span class="star_require">*</span> : <?php echo $this->_tpl_vars['lang']['controllergroup']['formRequiredLabel']; ?>
</small>
		</p>
		</fieldset>
	</div>

    	
</div>
</form>
