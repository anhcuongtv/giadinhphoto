<?php /* Smarty version 2.6.26, created on 2010-07-15 22:53:10
         compiled from _controller/site/entrylovestory/detail.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entrylovestory/detail.tpl', 18, false),array('modifier', 'date_format', '_controller/site/entrylovestory/detail.tpl', 26, false),array('modifier', 'relative_datetime', '_controller/site/entrylovestory/detail.tpl', 65, false),array('modifier', 'strip_tags', '_controller/site/entrylovestory/detail.tpl', 68, false),array('modifier', 'truncate', '_controller/site/entrylovestory/detail.tpl', 68, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<div id="content-wide">
	<div id="heading">
		<h1><?php echo $this->_tpl_vars['myEntry']->title; ?>
<?php if ($this->_tpl_vars['myEntry']->canModify()): ?> <span><a href="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/edit/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" title="<?php echo $this->_tpl_vars['myEntry']->title; ?>
">[<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditLabel']; ?>
]</a></span><?php endif; ?></h1></div>
	<div id="page-content" class="entryplace">
		<div id="detail">
			<div class="left">
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryratingbar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<div class="image">
					<?php if ($this->_tpl_vars['myEntry']->image == ''): ?>
						
					<?php else: ?>
						<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['myEntry']->image; ?>
" rel="shadowbox[gallery]" title="<?php echo $this->_tpl_vars['myEntry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['myEntry']->title; ?>
" <?php $this->assign('imagewidth', $this->_tpl_vars['myEntry']->getImageWidth()); ?><?php if ($this->_tpl_vars['imagewidth'] < $this->_tpl_vars['setting']['entry']['imageCssWidthInDetail']): ?>style="width:<?php echo $this->_tpl_vars['imagewidth']; ?>
px;"<?php endif; ?> src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['myEntry']->image; ?>
" /></a>
					<?php endif; ?>
				</div>
				<?php if (count($this->_tpl_vars['myEntry']->photos) > 0): ?>
				<div class="photos">
					<?php $_from = $this->_tpl_vars['myEntry']->photos; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['photo']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['photo']->filepath; ?>
" title="<?php if ($this->_tpl_vars['photo']->caption == ''): ?><?php echo $this->_tpl_vars['myEntry']->title; ?>
<?php else: ?><?php echo $this->_tpl_vars['photo']->caption; ?>
<?php endif; ?>" rel="shadowbox[gallery]"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['photo']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['photo']->filepathSmall; ?>
" alt="image" /></a>
					<?php endforeach; endif; unset($_from); ?>
				</div>
				<?php endif; ?>
				<div class="poster">
					<?php echo $this->_tpl_vars['lang']['controllergroup']['entryPostBy']; ?>
 <strong><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->username; ?>
" class="username" title="<?php echo $this->_tpl_vars['myEntry']->username; ?>
"><?php echo $this->_tpl_vars['myEntry']->username; ?>
</a></strong> &middot;  <span class="date"><?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</span>
				</div>
			</div>
			
			<div class="right">
				<div class="info">
					<?php if ($this->_tpl_vars['myEntry']->tag != ''): ?><div><strong><?php echo $this->_tpl_vars['lang']['controllergroup']['entryTag']; ?>
 :</strong> <?php echo $this->_tpl_vars['myEntry']->tag; ?>
<hr size="1" color="#ccc" style="margin-top:20px" /></div><?php endif; ?>
					<?php if ($this->_tpl_vars['myEntry']->description != ''): ?><div class="description"><?php echo $this->_tpl_vars['myEntry']->description; ?>
</div><?php endif; ?>
				</div>
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrystatbar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			</div>	
		</div><!-- end of #detail -->
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysharebookmark.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrycomment.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<?php if (count($this->_tpl_vars['myEntry']->relatedEntries) > 0): ?>
		<div id="related">
			<div class="head"><?php echo $this->_tpl_vars['lang']['controller']['relatedEntry']; ?>
</div>	
			<div id="entry-listing">
				<?php $_from = $this->_tpl_vars['myEntry']->relatedEntries; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['entrylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['entrylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['entry']):
        $this->_foreach['entrylist']['iteration']++;
?>
				<div class="entry-post-linesep"></div>
				<div class="entry-post entrylovestory-post">
				
					
					<div class="image"><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/nolovestory-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /><span><?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewLabel']; ?>
 : <?php echo $this->_tpl_vars['entry']->view; ?>
</span></a></div>
					<?php if ($this->_tpl_vars['entry']->canModify()): ?>
					<div class="action">
						<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
/edit" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryEditLabel']; ?>
</a> |
						<a href="javascript:delm('<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
/delete<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>?token=<?php echo $_SESSION['securityToken']; ?>
')" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryDeleteLabel']; ?>
</a>
					</div>
					<?php endif; ?>
					<div class="more">
						<h3 class="title"><?php if ($this->_tpl_vars['entry']->commentCount > 0): ?><div class="commentscloud" title="<?php echo $this->_tpl_vars['entry']->commentCount; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
#commentbox" title="<?php echo $this->_tpl_vars['entry']->title; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><?php echo $this->_tpl_vars['entry']->commentCount; ?>
</a></div><?php endif; ?><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a></h3>
						<div class="rating">
							<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						</div>
						
						<div class="poster">
							&raquo; <strong><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['entry']->username; ?>
" class="username" title="<?php echo $this->_tpl_vars['entry']->username; ?>
"><?php echo $this->_tpl_vars['entry']->username; ?>
</a></strong> <?php echo $this->_tpl_vars['lang']['controllergroup']['entryPost']; ?>
 <span title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentPostAt']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat'])); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span></span>
						</div>
						<div>
							<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 400, '..') : smarty_modifier_truncate($_tmp, 400, '..')); ?>
	<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="Map" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/s_arrow_green.gif" /></a>
						</div>
					</div>
					
					
				</div>
				<?php if (($this->_foreach['entrylist']['iteration'] == $this->_foreach['entrylist']['total'])): ?><div class="entry-post-linesep"></div><?php endif; ?>
				<?php endforeach; endif; unset($_from); ?>
			
			</div><!-- end of #entry-listing -->
		</div><!-- end of #related -->
		
		<?php endif; ?>
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryotherbox.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


