<?php /* Smarty version 2.6.26, created on 2010-07-12 14:18:19
         compiled from _controller/site/diary/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_controller/site/diary/index.tpl', 35, false),array('modifier', 'relative_datetime', '_controller/site/diary/index.tpl', 35, false),array('modifier', 'count', '_controller/site/diary/index.tpl', 57, false),array('modifier', 'nl2br', '_controller/site/diary/index.tpl', 70, false),array('function', 'paginate', '_controller/site/diary/index.tpl', 86, false),)), $this); ?>
<div id="sidebar1">
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-blue">
			<div><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myUser']->username; ?>
"><?php echo $this->_tpl_vars['myUser']->username; ?>
</a></div>
		</div>
		<div class="sidebar-box-body">
			<p><?php if ($this->_tpl_vars['myUser']->avatar != ''): ?>
						<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myUser']->username; ?>
"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['avatar']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['myUser']->avatar; ?>
" border="0" /></a><?php endif; ?></p>
			<p><strong><?php echo $this->_tpl_vars['lang']['controller']['fullname']; ?>
</strong> : <?php echo $this->_tpl_vars['myUser']->fullname; ?>
</p>
			<?php if ($this->_tpl_vars['myUser']->gender != 'unknown'): ?>
				<p><strong><?php echo $this->_tpl_vars['lang']['controllergroup']['userGender']; ?>
</strong> : 
					<?php if ($this->_tpl_vars['myUser']->gender == 'male'): ?>
						<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_male.png" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderMale']; ?>
" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderMale']; ?>
" />
					<?php else: ?>
						<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_female.png" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderFemale']; ?>
" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderFemale']; ?>
" />
					<?php endif; ?>
					
					<?php if ($this->_tpl_vars['myUser']->lovestatus != 'unknown'): ?>
							<?php if ($this->_tpl_vars['myUser']->lovestatus == 'single'): ?>
								<span class="lovestatus_badge lovestatus_badge_single"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusSingle']; ?>
</span>
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'just'): ?>
								<span class="lovestatus_badge lovestatus_badge_just"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusJust']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'deep'): ?>
								<span class="lovestatus_badge lovestatus_badge_deep"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusDeep']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'wedding'): ?>
								<span class="lovestatus_badge lovestatus_badge_wedding"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusWedding']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'old'): ?>
								<span class="lovestatus_badge lovestatus_badge_old"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusOld']; ?>
</span>	
							<?php endif; ?>
					<?php endif; ?>
					
				</p>
			<?php endif; ?>
			
			<p title="<?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty'])); ?>
"><strong><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
</strong> : <?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</p>
			<p title="<?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datelastlogin)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty'])); ?>
"><strong><?php echo $this->_tpl_vars['lang']['controller']['datelastlogin']; ?>
</strong> : <?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datelastlogin)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</p>
			
			<?php if ($this->_tpl_vars['myUser']->id == $this->_tpl_vars['me']->id): ?>
			<div style="padding:5px 0; background:#fff; text-align:center;">
				<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
profile.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['editProfileLabel']; ?>
</a>
			</div>
			<?php endif; ?>
		</div>
	</div>
	
	
</div><!-- end of #sidebar1 -->


<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</h1></div>
	<div id="page-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

		<div class="box2col">
			
			<?php if (count($this->_tpl_vars['diaryEntries']) > 0): ?>
			<div class="box2col-body">
				<?php $_from = $this->_tpl_vars['diaryEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['diarylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['diarylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['diaryEntry']):
        $this->_foreach['diarylist']['iteration']++;
?>
				<div class="box2col-entry box2col-entry-diary">
					<div class="image">
						<img alt="<?php echo $this->_tpl_vars['diaryEntry']->emoticon; ?>
" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/<?php echo $this->_tpl_vars['diaryEntry']->emoticon; ?>
.png" />
						
					</div>
					<div class="title">
						<div class="category"><span><?php echo $this->_tpl_vars['diaryEntry']->getTypeName(); ?>
</span> <span title="<?php echo $this->_tpl_vars['lang']['controllergroup']['diaryAboutTime']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['diaryEntry']->dateaction)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['diaryEntry']->dateaction)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span></div>
						<?php if ($this->_tpl_vars['diaryEntry']->mode == 'private'): ?>
							<div class="private"><img title="<?php echo $this->_tpl_vars['lang']['global']['diaryPrivate']; ?>
" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/lock.png" alt="private" /></div>
						<?php endif; ?>
						<p><?php echo ((is_array($_tmp=$this->_tpl_vars['diaryEntry']->parsedcontent)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/quote_icon.png" /></p>
					</div>
					<?php if ($this->_tpl_vars['diaryEntry']->canModify()): ?>
					<div class="action">
						<a href="<?php echo $this->_tpl_vars['diaryEntry']->getFullSeoUrl('edit'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controllergroup']['editLabel']; ?>
</a> |
						<a href="javascript:delm('<?php echo $this->_tpl_vars['diaryEntry']->getFullSeoUrl('delete'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>?token=<?php echo $_SESSION['securityToken']; ?>
')"><?php echo $this->_tpl_vars['lang']['controllergroup']['deleteLabel']; ?>
</a>
					</div>
					<?php endif; ?>
					
				</div>
				<div class="clear"></div>
				<?php endforeach; endif; unset($_from); ?>
				
			</div>
			<div class="box2col-foot">
				<?php $this->assign('pageurl', "trang-::PAGE::"); ?>
				<?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

			</div>
			<?php else: ?>
			<div class="box2col-body">
				<div id="entry-listing-empty"><?php echo $this->_tpl_vars['lang']['controllergroup']['diaryEmpty']; ?>
</div>
			</div>
			<?php endif; ?>
		</div><!-- end of .box2col -->
		
		
		
		
		
		
		
		
			
		
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->
