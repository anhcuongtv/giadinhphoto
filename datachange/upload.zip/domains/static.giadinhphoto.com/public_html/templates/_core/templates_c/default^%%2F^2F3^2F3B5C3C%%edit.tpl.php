<?php /* Smarty version 2.6.26, created on 2010-07-13 09:27:43
         compiled from _controller/admin/quiz/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'htmlspecialchars', '_controller/admin/quiz/edit.tpl', 26, false),array('modifier', 'count', '_controller/admin/quiz/edit.tpl', 125, false),array('modifier', 'default', '_controller/admin/quiz/edit.tpl', 143, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_edit']; ?>
</h2>


<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_edit']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" id="tab1_link" <?php if ($this->_tpl_vars['tab'] == '' || $this->_tpl_vars['tab'] == 1): ?>class="default-tab"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controllergroup']['formFormLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2" id="tab2_link" <?php if ($this->_tpl_vars['tab'] == 2): ?>class="default-tab"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formQuestionList']; ?>
</a></li>
			<li><a href="#tab3" id="tab3_link" <?php if ($this->_tpl_vars['tab'] == 3): ?>class="default-tab"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formResultList']; ?>
</a></li>
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['backUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		<div class="tab-content<?php if ($this->_tpl_vars['tab'] == '' || $this->_tpl_vars['tab'] == 1): ?> default-tab<?php endif; ?>" id="tab1">
			<form action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform" enctype="multipart/form-data">
			<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizEditToken']; ?>
" />
			<table class="form" cellpadding="5" cellspacing="5">
				<tr>
					<td width="150" class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTitleLabel']; ?>
 <span class="star_require">*</span> : </td>
					<td><input type="text" name="ftitle" id="ftitle" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['ftitle']); ?>
" class="text-input"></td>
				</tr>
				<tr>
					<td width="150" class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
 <span class="star_require">*</span> : </td>
					<td><label><input type="radio" name="ftype" value="abc" <?php if ($this->_tpl_vars['formData']['ftype'] == '' || $this->_tpl_vars['formData']['ftype'] == 'abc'): ?>checked="checked"<?php endif; ?> /><?php echo $this->_tpl_vars['lang']['controller']['formTypeAbc']; ?>
</label> - 
					<label><input type="radio" name="ftype" value="point" <?php if ($this->_tpl_vars['formData']['ftype'] == 'point'): ?>checked="checked"<?php endif; ?>/><?php echo $this->_tpl_vars['lang']['controller']['formTypePoint']; ?>
</label></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formImageLabel']; ?>
 : </td>
					<td><?php if ($this->_tpl_vars['formData']['fimage'] != ''): ?>
						
									<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myQuiz']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" target="_blank"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myQuiz']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['formData']['fimage']; ?>
" width="100" border="0" /></a><input type="checkbox" name="fdeleteimage" value="1" /><?php echo $this->_tpl_vars['lang']['controller']['formImageDeleteLabel']; ?>

								
						<?php endif; ?>
						
						<input type="file" id="fimage" name="fimage" /></td>
				</tr>
				
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formDescriptionLabel']; ?>
 : </td>
					<td><textarea class="text-input wysiwyg"  rows="8" name="fdescription" cols="80" id="fdescription"><?php echo $this->_tpl_vars['formData']['fdescription']; ?>
</textarea></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTagLabel']; ?>
 : </td>
					<td><input type="text" name="ftag" id="ftag" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['ftag']); ?>
" class="text-input"></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formRelatedLabel']; ?>
 :</td>
					<td><input type="text" name="frelated" id="frelated" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['frelated']); ?>
" class="text-input">
				<br />
				<small><?php echo $this->_tpl_vars['lang']['controller']['formRelatedHelpLabel']; ?>
</small></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoUrlLabel']; ?>
 :</td>
					<td><input type="text" name="fseourl" id="fseourl" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseourl']); ?>
" class="text-input">
				<br />
				<small><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['quiz']['seoUrl']; ?>
/[SEO_URL]-[ID].html</small></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoTitleLabel']; ?>
 :</td>
					<td><input type="text" name="fseotitle" id="fseotitle" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseotitle']); ?>
" class="text-input"></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoKeywordLabel']; ?>
 :</td>
					<td><textarea class="text-input"  rows="2" name="fseokeyword" id="fseokeyword"><?php echo $this->_tpl_vars['formData']['fseokeyword']; ?>
</textarea></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoDescriptionLabel']; ?>
 :</td>
					<td><textarea class="text-input"  rows="2" name="fseodescription" id="fseodescription"><?php echo $this->_tpl_vars['formData']['fseodescription']; ?>
</textarea></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedLabel']; ?>
 :</td>
					<td><input type="hidden" name="fismoderated" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedTooltip']; ?>
" type="checkbox" name="fismoderated" value="1"<?php if ($this->_tpl_vars['formData']['fismoderated'] == '1'): ?> checked="checked"<?php endif; ?> /></td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextLabel']; ?>
 :</td>
					<td><input type="hidden" name="fignorecleanbadword" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextTooltip']; ?>
" type="checkbox" name="fignorecleanbadword" value="1"<?php if ($this->_tpl_vars['formData']['fignorecleanbadword'] == '1'): ?> checked="checked"<?php endif; ?> /></td>
				</tr>
			</table>
			<fieldset>
			<p>
				<input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formUpdateSubmit']; ?>
" class="button buttonbig">
				<br /><small><span class="star_require">*</span> : <?php echo $this->_tpl_vars['lang']['controllergroup']['formRequiredLabel']; ?>
</small>
			</p>
			</fieldset>
			
			</form>
		</div>
		
		<div class="tab-content<?php if ($this->_tpl_vars['tab'] == 2): ?> default-tab<?php endif; ?>" id="tab2">
			<form action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform">
			<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizEditToken']; ?>
" />
				<table class="form" width="100%">
					<tr style="background:#ccc; font-size:16px;">
						<td><strong><?php echo $this->_tpl_vars['lang']['controller']['formQuestionAdd']; ?>
</strong></td>
						<td class="td_right"><input type="submit" name="fsubmitquestionadd" value="<?php echo $this->_tpl_vars['lang']['controller']['formQuestionAddBtn']; ?>
" /></td>
					</tr>
					<tr>
						<td width="400">
							<?php echo $this->_tpl_vars['lang']['controller']['formQuestionNameLabel']; ?>
: <br />
							<textarea  name="fquestionaddname" class="wysiwyg" rows="8" cols="50"><?php echo $this->_tpl_vars['formData']['fquestionaddname']; ?>
</textarea>
						</td>
						<td>
							<?php echo $this->_tpl_vars['lang']['controller']['formQuestionOptionLabel']; ?>
:<br />
							<ol>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[1]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['1']; ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[1]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['1']; ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[2]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['2']; ?>
"/> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[2]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['2']; ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[3]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['3']; ?>
"/> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[3]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['3']; ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[4]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['4']; ?>
"/> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[4]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['4']; ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[5]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['5']; ?>
"/> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[5]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['5']; ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestionaddoption[6]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoption']['6']; ?>
"/> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestionaddoptionpoint[6]" value="<?php echo $this->_tpl_vars['formData']['fquestionaddoptionpoint']['6']; ?>
" size="2" /></li>
								
								
							</ol>
						</td>
					</tr>
				</table>
				
				<table class="grid">
					<?php if (count($this->_tpl_vars['myQuiz']->questions) > 0): ?>
					<thead>
						<tr style="background:#ccc; font-size:16px;">
							<th colspan="3"><strong><?php echo $this->_tpl_vars['lang']['controller']['formQuestionList']; ?>
</strong></th>
							<th colspan="3" class="td_right"><input type="submit" name="fsubmitquestionchangeorder" value="<?php echo $this->_tpl_vars['lang']['controller']['formQuestionChangeOrderBtn']; ?>
" /></th>
						</tr>
						<tr>
							<th width="30"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</th>
							<th width="50"><?php echo $this->_tpl_vars['lang']['controllergroup']['formOrderLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formQuestionNameLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formQuestionOptionLabel']; ?>
</th>	
							<th width="70"></th>
						</tr>
					</thead>
					<tbody>
						<?php $_from = $this->_tpl_vars['myQuiz']->questions; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['question']):
?>
						<tr>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['question']->id; ?>
</td>
							<td><?php $this->assign('questionid', $this->_tpl_vars['question']->id); ?><input type="text" size="2" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['question']->order)) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['formData']['fquestionorder'][$this->_tpl_vars['questionid']]) : smarty_modifier_default($_tmp, @$this->_tpl_vars['formData']['fquestionorder'][$this->_tpl_vars['questionid']])); ?>
" name="fquestionorder[<?php echo $this->_tpl_vars['question']->id; ?>
]" class="text-input" /></td>
							<td><?php echo $this->_tpl_vars['question']->name; ?>
</td>
							<td>
								<ol>
								<?php $_from = $this->_tpl_vars['question']->options; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['option']):
?>
									<?php if ($this->_tpl_vars['option']['text'] != ''): ?><li><?php echo $this->_tpl_vars['option']['text']; ?>
 (<?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <?php echo $this->_tpl_vars['option']['point']; ?>
)</li><?php endif; ?>
								<?php endforeach; endif; unset($_from); ?>
								</ol>
							</td>	
							<th width="70"><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="javascript:void(0);" onclick="$('.formquestionedit').hide();$('#formquestionedit_<?php echo $this->_tpl_vars['question']->id; ?>
').show();scrollTo('#formquestionedit_<?php echo $this->_tpl_vars['question']->id; ?>
')"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
								<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/fsubmitquestiondelete/1/questionid/<?php echo $this->_tpl_vars['question']->id; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a></th>
						</tr>
						<?php endforeach; endif; unset($_from); ?>
					</tbody>
					<?php else: ?>
						<tr>
							<td colspan="5"><?php echo $this->_tpl_vars['lang']['controller']['formQuestionEmpty']; ?>
</td>
						</tr>
					<?php endif; ?>
				</table>
			</form>
			
			<?php $_from = $this->_tpl_vars['myQuiz']->questions; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['question']):
?>
			<form id="formquestionedit_<?php echo $this->_tpl_vars['question']->id; ?>
" style="display:none;" class="formquestionedit" action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizEditToken']; ?>
" />
				<input type="hidden" name="fquestioneditid" value="<?php echo $this->_tpl_vars['question']->id; ?>
" />
				<table class="form" width="100%">
					<tr style="background:#F96; font-size:16px;">
						<td><strong><?php echo $this->_tpl_vars['lang']['controller']['formQuestionEdit']; ?>
 (ID #<?php echo $this->_tpl_vars['question']->id; ?>
)</strong></td>
						<td class="td_right"><input type="submit" name="fsubmitquestionedit" value="<?php echo $this->_tpl_vars['lang']['controller']['formQuestionEditBtn']; ?>
" /></td>
					</tr>
					<tr>
						<td width="400">
							<?php echo $this->_tpl_vars['lang']['controller']['formQuestionNameLabel']; ?>
: <br />
							<textarea  name="fquestioneditname" class="wysiwyg" rows="8" cols="50"><?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditname'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->name) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->name)); ?>
</textarea>
						</td>
						<td>
							<?php echo $this->_tpl_vars['lang']['controller']['formQuestionOptionLabel']; ?>
:<br />
							<ol>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[1]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['1'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['1']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['1']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[1]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['1'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['1']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['1']['point'])); ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[2]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['2'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['2']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['2']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[2]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['2'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['2']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['2']['point'])); ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[3]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['3'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['3']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['3']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[3]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['3'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['3']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['3']['point'])); ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[4]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['4'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['4']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['4']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[4]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['4'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['4']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['4']['point'])); ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[5]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['5'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['5']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['5']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[5]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['5'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['5']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['5']['point'])); ?>
" size="2" /></li>
								<li><input size="50" class="text-input" type="text" name="fquestioneditoption[6]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoption']['6'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['6']['text']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['6']['text'])); ?>
" /> - <?php echo $this->_tpl_vars['lang']['controller']['formQuestionPointLabel']; ?>
 : <input class="text-input" type="text" name="fquestioneditoptionpoint[6]" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fquestioneditoptionpoint']['6'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['question']->options['6']['point']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['question']->options['6']['point'])); ?>
" size="2" /></li>
								
								
								
							</ol>
						</td>
					</tr>
				</table>
			</form>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		
		<div class="tab-content<?php if ($this->_tpl_vars['tab'] == 3): ?> default-tab<?php endif; ?>" id="tab3">
			
			<form action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizEditToken']; ?>
" />
				<table class="form" width="100%">
					<tr style="background:#ccc; font-size:16px;">
						<td><strong><?php echo $this->_tpl_vars['lang']['controller']['formResultAdd']; ?>
</strong></td>
						<td class="td_right"><input type="submit" name="fsubmitresultadd" value="<?php echo $this->_tpl_vars['lang']['controller']['formResultAddBtn']; ?>
" /></td>
					</tr>
					<tr>
						<td colspan="2">
							<?php echo $this->_tpl_vars['lang']['controller']['formResultMinLabel']; ?>
:
							<input  class="text-input" type="text" size="4"  name="fresultaddmin" value="<?php echo $this->_tpl_vars['formData']['fresultaddmin']; ?>
" /> -
							<?php echo $this->_tpl_vars['lang']['controller']['formResultMaxLabel']; ?>
:
							<input class="text-input" type="text" size="4"  name="fresultaddmax" value="<?php echo $this->_tpl_vars['formData']['fresultaddmax']; ?>
" /> (<small><em><?php echo $this->_tpl_vars['lang']['controller']['formResultMinMaxHelp']; ?>
</em></small>)<br /><br />
							<?php echo $this->_tpl_vars['lang']['controller']['formResultDescriptionLabel']; ?>
: <br />
							<textarea  name="fresultadddescription" class="wysiwyg" rows="10" cols="110"><?php echo $this->_tpl_vars['formData']['fresultadddescription']; ?>
</textarea>
						</td>
						
					</tr>
				</table>
				
				<table class="grid">
					<?php if (count($this->_tpl_vars['myQuiz']->results) > 0): ?>
					<thead>
						<tr style="background:#ccc; font-size:16px;">
							<th colspan="3"><strong><?php echo $this->_tpl_vars['lang']['controller']['formResultList']; ?>
</strong></th>
							<th colspan="3" class="td_right"><input type="submit" name="fsubmitresultchangeorder" value="<?php echo $this->_tpl_vars['lang']['controller']['formResultChangeOrderBtn']; ?>
" /></th>
						</tr>
						<tr>
							<th width="30"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</th>
							<th width="50"><?php echo $this->_tpl_vars['lang']['controllergroup']['formOrderLabel']; ?>
</th>
							<th width="100"><?php echo $this->_tpl_vars['lang']['controller']['formResultMinLabel']; ?>
</th>
							<th width="100"><?php echo $this->_tpl_vars['lang']['controller']['formResultMaxLabel']; ?>
</th>
							
							<th><?php echo $this->_tpl_vars['lang']['controller']['formResultDescriptionLabel']; ?>
</th>	
							<th width="70"></th>
						</tr>
					</thead>
					<tbody>
						<?php $_from = $this->_tpl_vars['myQuiz']->results; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['result']):
?>
						<tr>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['result']->id; ?>
</td>
							<td><?php $this->assign('resultid', $this->_tpl_vars['retult']->id); ?><input type="text" size="2" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['result']->order)) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['formData']['fresultorder'][$this->_tpl_vars['resultid']]) : smarty_modifier_default($_tmp, @$this->_tpl_vars['formData']['fresultorder'][$this->_tpl_vars['resultid']])); ?>
" name="fresultorder[<?php echo $this->_tpl_vars['result']->id; ?>
]" class="text-input" /></td>
							<td><?php echo $this->_tpl_vars['result']->min; ?>
</td>
							<td><?php echo $this->_tpl_vars['result']->max; ?>
</td>
							<td><?php echo $this->_tpl_vars['result']->description; ?>
</td>
							
							<th width="70"><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="javascript:void(0);" onclick="$('.formresultedit').hide();$('#formresultedit_<?php echo $this->_tpl_vars['result']->id; ?>
').show();scrollTo('#formresultedit_<?php echo $this->_tpl_vars['result']->id; ?>
')"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
								<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/fsubmitresultdelete/1/resultid/<?php echo $this->_tpl_vars['result']->id; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a></th>
						</tr>
						<?php endforeach; endif; unset($_from); ?>
					</tbody>
					<?php else: ?>
						<tr>
							<td colspan="5"><?php echo $this->_tpl_vars['lang']['controller']['formResultEmpty']; ?>
</td>
						</tr>
					<?php endif; ?>
				</table>
			</form>
			
			<?php $_from = $this->_tpl_vars['myQuiz']->results; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['result']):
?>
			<form id="formresultedit_<?php echo $this->_tpl_vars['result']->id; ?>
" style="display:none;" class="formresultedit" action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
quiz/edit/id/<?php echo $this->_tpl_vars['myQuiz']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizEditToken']; ?>
" />
				<input type="hidden" name="fresulteditid" value="<?php echo $this->_tpl_vars['result']->id; ?>
" />
				<table class="form" width="100%">
					<tr style="background:#F96; font-size:16px;">
						<td><strong><?php echo $this->_tpl_vars['lang']['controller']['formResultEdit']; ?>
 (ID #<?php echo $this->_tpl_vars['result']->id; ?>
)</strong></td>
						<td class="td_right"><input type="submit" name="fsubmitresultedit" value="<?php echo $this->_tpl_vars['lang']['controller']['formResultEditBtn']; ?>
" /></td>
					</tr>
					<tr>
						<td colspan="2">
							<?php echo $this->_tpl_vars['lang']['controller']['formResultMinLabel']; ?>
:
							<input  class="text-input" type="text" size="4"  name="fresulteditmin" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fresulteditmin'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['result']->min) : smarty_modifier_default($_tmp, @$this->_tpl_vars['result']->min)); ?>
" /> -
							<?php echo $this->_tpl_vars['lang']['controller']['formResultMaxLabel']; ?>
:
							<input class="text-input" type="text" size="4"  name="fresulteditmax" value="<?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fresulteditmax'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['result']->max) : smarty_modifier_default($_tmp, @$this->_tpl_vars['result']->max)); ?>
" /> (<small><em><?php echo $this->_tpl_vars['lang']['controller']['formResultMinMaxHelp']; ?>
</em></small>)<br /><br />
							<?php echo $this->_tpl_vars['lang']['controller']['formResultDescriptionLabel']; ?>
: <br />
							<textarea  name="fresulteditdescription" class="wysiwyg" rows="10" cols="110"><?php echo ((is_array($_tmp=@$this->_tpl_vars['formData']['fresulteditdescription'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['result']->description) : smarty_modifier_default($_tmp, @$this->_tpl_vars['result']->description)); ?>
</textarea>
						</td>
					</tr>
				</table>
			</form>
			<?php endforeach; endif; unset($_from); ?>	
			
		</div>
		
			
	</div>
	
	
</div>
