<?php /* Smarty version 2.6.26, created on 2012-11-08 02:03:32
         compiled from googleanalytic.tpl */ ?>
<?php echo '
<script type="text/javascript">

</script>
'; ?>