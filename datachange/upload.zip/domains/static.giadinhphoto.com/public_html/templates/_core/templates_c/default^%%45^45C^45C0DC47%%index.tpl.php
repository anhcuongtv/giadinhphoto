<?php /* Smarty version 2.6.26, created on 2010-07-15 21:18:57
         compiled from _controller/site/tos/index.tpl */ ?>
<div id="sidebar1">
	
	<div class="sidebar-banner">
		<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/policy-banner.jpg" alt="policy" />
	</div>
	
</div><!-- end of #sidebar1 -->


<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</h1></div>
	<div id="page-content">
		<?php echo $this->_tpl_vars['lang']['controller']['data']; ?>

	</div>	
	
</div><!-- end of #content -->