<?php /* Smarty version 2.6.26, created on 2010-07-15 21:13:32
         compiled from _controller/site/quiz/detail.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'counter', '_controller/site/quiz/detail.tpl', 38, false),array('modifier', 'count', '_controller/site/quiz/detail.tpl', 76, false),array('modifier', 'date_format', '_controller/site/quiz/detail.tpl', 93, false),array('modifier', 'relative_datetime', '_controller/site/quiz/detail.tpl', 93, false),array('modifier', 'strip_tags', '_controller/site/quiz/detail.tpl', 97, false),array('modifier', 'truncate', '_controller/site/quiz/detail.tpl', 97, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."quiz/sidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<div id="content-wide">
	<div id="heading">
		<h1><?php echo $this->_tpl_vars['myEntry']->title; ?>
<?php if ($this->_tpl_vars['myEntry']->canModify()): ?> <span><a title="<?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
" href="<?php echo $this->_tpl_vars['myEntry']->getModifyUrl('edit'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>">[<?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
]</a></span><?php endif; ?></h1></div>
	<div id="page-content" class="entryplace">
		<div id="detail" class="quiz-detail">
		
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
			
			<?php if ($this->_tpl_vars['myQuizResult']->id > 0): ?>
				<div id="quiz-result">
					<p><?php echo $this->_tpl_vars['myQuizResult']->description; ?>
</p>
					<div style="float:left;"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rose.png" /></div>
					<div class="playagain"><a title="Play again" href="javascript:void(0);" onclick="$('#quizquestions').show();scrollTo('#quizquestions');">Play again!</a></div>
				</div>
			<?php else: ?>
				<div class="info">
					<?php if ($this->_tpl_vars['myEntry']->description != ''): ?><div class="description"><?php echo $this->_tpl_vars['myEntry']->description; ?>
</div><?php endif; ?>
					
					
				</div>
			<?php endif; ?>
			
			
			
			<div class="left" id="quiz">
				
				<a name="start-quiz" title="start quiz"></a>
				<div id="quizquestions" style="<?php if ($this->_tpl_vars['myQuizResult']->id > 0): ?>display:none;<?php endif; ?>">
					<form method="post" action="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
" onsubmit="return quizSubmitValidate()">
					<?php $_from = $this->_tpl_vars['myEntry']->questions; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['questionlist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['questionlist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['question']):
        $this->_foreach['questionlist']['iteration']++;
?>
						<div class="question" id="question_<?php echo $this->_tpl_vars['question']->id; ?>
">
							<input type="hidden" class="flag_question" id="flag_question_<?php echo $this->_tpl_vars['question']->id; ?>
" value="" rel="<?php echo $this->_tpl_vars['lang']['controller']['jsQuestionRequired']; ?>
 <?php echo $this->_foreach['questionlist']['iteration']; ?>
" />
							<div class="questioncontent"><h3><span><?php echo $this->_foreach['questionlist']['iteration']; ?>
</span><?php echo $this->_tpl_vars['question']->name; ?>
</h3></div>
							<ol class="options"><?php echo smarty_function_counter(array('start' => 0,'print' => false), $this);?>

								<?php $_from = $this->_tpl_vars['question']->options; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['optionid'] => $this->_tpl_vars['option']):
?>
									<?php if ($this->_tpl_vars['option']['text'] != ''): ?><li class="opt question_<?php echo $this->_tpl_vars['question']->id; ?>
" id="opt_<?php echo $this->_tpl_vars['question']->id; ?>
_<?php echo $this->_tpl_vars['optionid']; ?>
" onclick="quizOptionClick('question_<?php echo $this->_tpl_vars['question']->id; ?>
', 'opt_<?php echo $this->_tpl_vars['question']->id; ?>
_<?php echo $this->_tpl_vars['optionid']; ?>
')"><input type="radio" name="foption[<?php echo $this->_tpl_vars['question']->id; ?>
]" value="<?php echo $this->_tpl_vars['optionid']; ?>
" /><div class="optcontent"><?php echo smarty_function_counter(array(), $this);?>
. <?php echo $this->_tpl_vars['option']['text']; ?>
</div></li><?php endif; ?>
								<?php endforeach; endif; unset($_from); ?>
							</ol>
						</div>
					
					<?php endforeach; endif; unset($_from); ?>
					<div id="quiz-bottom"><input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controller']['viewResultBtn']; ?>
" /></div>
					</form>
					<hr size="1" color="#fff" style="margin-top:20px;" />
				</div>
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryratingbar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				
								
				
			</div>
			
			<div class="right">
				<?php if ($this->_tpl_vars['myEntry']->tag != ''): ?><div class="tag"><strong><?php echo $this->_tpl_vars['lang']['controller']['tag']; ?>
 :</strong> <?php echo $this->_tpl_vars['myEntry']->tag; ?>
</div><?php endif; ?>
				
				<div class="moreinfo">
					
					
					<div class="moreinfosub">
						<div class="view"><?php echo $this->_tpl_vars['lang']['controller']['view']; ?>
: <?php echo $this->_tpl_vars['myEntry']->view; ?>
</div>
						<div class="rating"><div class="count">(<?php echo $this->_tpl_vars['myEntry']->ratingCount; ?>
)</div><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['myEntry']->getRoundRating(); ?>
.png"  title="<?php if ($this->_tpl_vars['myEntry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['myEntry']->rating; ?>
<?php endif; ?>" alt="rating" /></div>
					</div>
				</div>
			</div>	
		</div><!-- end of #detail -->
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysharebookmark.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrycomment.tpl", 'smarty_include_vars' => array('reportabusetype' => 'quizcomment')));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<?php if (count($this->_tpl_vars['myEntry']->relatedEntries) > 0): ?>
		<div id="related">
			<div class="head"><?php echo $this->_tpl_vars['lang']['controller']['relatedEntry']; ?>
</div>	
			<div id="entry-listing">
				<?php $_from = $this->_tpl_vars['myEntry']->relatedEntries; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['entrylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['entrylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['entry']):
        $this->_foreach['entrylist']['iteration']++;
?>
				<div class="entry-post quiz-post">
				
					
					<div class="image"><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noquiz-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /><span><?php echo $this->_tpl_vars['lang']['controller']['playNumber']; ?>
 : <?php echo $this->_tpl_vars['entry']->play; ?>
</span></a></div>
					
					<div class="more">
						<h3 class="title"><?php if ($this->_tpl_vars['entry']->commentCount > 0): ?><div class="commentscloud" title="<?php echo $this->_tpl_vars['entry']->commentCount; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
#commentbox" title="<?php echo $this->_tpl_vars['entry']->title; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryComment']; ?>
"><?php echo $this->_tpl_vars['entry']->commentCount; ?>
</a></div><?php endif; ?><a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a></h3>
						<div class="rating">
							<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						</div>
						
						<div class="poster" style="display:none;">
							<strong><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['entry']->username; ?>
" class="username" title="<?php echo $this->_tpl_vars['entry']->username; ?>
"><?php echo $this->_tpl_vars['entry']->username; ?>
</a></strong> <?php echo $this->_tpl_vars['lang']['controllergroup']['entryPost']; ?>
 <span title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentPostAt']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['entryPostSmartyFormat'])); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span></span>
						</div>
						
						<div>
							<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, "..") : smarty_modifier_truncate($_tmp, 200, "..")); ?>
	
							
						</div>
					</div>
					<?php if ($this->_tpl_vars['entry']->canModify()): ?>
					<div class="action">
						<a href="<?php echo $this->_tpl_vars['entry']->getModifyUrl('edit'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> |
						<a href="javascript:delm('<?php echo $this->_tpl_vars['entry']->getModifyUrl('delete'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>')" title="<?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a>
					</div>
					<?php endif; ?>
					
				</div>
				<?php if (($this->_foreach['entrylist']['iteration'] == $this->_foreach['entrylist']['total']) || $this->_foreach['entrylist']['iteration'] % 2 == 0): ?><div class="entry-post-linesep"></div><?php endif; ?>
				<?php endforeach; endif; unset($_from); ?>
			
			</div><!-- end of #entry-listing -->
		</div><!-- end of #related -->
		
		<?php endif; ?>
		
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."quiz/otherentrybox.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


