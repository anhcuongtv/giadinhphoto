<?php /* Smarty version 2.6.26, created on 2010-07-08 13:07:48
         compiled from _mail/site/entry_add.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'strip_tags', '_mail/site/entry_add.tpl', 23, false),array('modifier', 'truncate', '_mail/site/entry_add.tpl', 23, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyMailGroupContainer'])."header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
  <h2>Co bai moi goi luc <?php echo $this->_tpl_vars['datecreated']; ?>
</h2>
 
  <p><h3><a href="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
"><?php echo $this->_tpl_vars['myEntry']->title; ?>
</a> - <?php echo $this->_tpl_vars['myEntry']->id; ?>
</h3>
  	<?php if ($this->_tpl_vars['myEntry']->image != ''): ?>
	<br />
	<img alt="Photo of <?php echo $this->_tpl_vars['myEntry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['myEntry']->getSmallImage(); ?>
" />
	<?php endif; ?>
  </p>
   <p>Sender: <b><?php echo $this->_tpl_vars['myEntry']->username; ?>
 (ID #<?php echo $this->_tpl_vars['myEntry']->uid; ?>
)</b></p>
  <p>Type: <b><?php echo $this->_tpl_vars['myEntry']->type; ?>
</b></p>
  <?php $this->assign('parentcategoryid', $this->_tpl_vars['myEntry']->parentcategoryid); ?>
  <?php $this->assign('categoryid', $this->_tpl_vars['myEntry']->categoryid); ?>
  <p>Category: <b><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['parentcategoryid']]; ?>
/"><?php echo $this->_tpl_vars['myEntry']->getParentCategoryName(); ?>
</a> &raquo; <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['parentcategoryid']]; ?>
/<?php echo $this->_tpl_vars['catMapReverse'][$this->_tpl_vars['categoryid']]; ?>
/"><?php echo $this->_tpl_vars['myEntry']->getCategoryName(); ?>
</a></b></p>

  <p>Tags: <b><?php echo $this->_tpl_vars['myEntry']->tag; ?>
</b></p>
  <p>is Moderated: <b><?php echo $this->_tpl_vars['myEntry']->isModerated; ?>
</b></p>
  <p>Ignore Clean Badword: <b><?php echo $this->_tpl_vars['myEntry']->ignoreCleanBadword; ?>
</b></p>
  <p>IP Address: <b><?php echo $this->_tpl_vars['myEntry']->ipaddress; ?>
</b></p>
  <p>SEO Url: <b><?php echo $this->_tpl_vars['myEntry']->seoUrl; ?>
</b></p>
  <p>SEO Title: <b><?php echo $this->_tpl_vars['myEntry']->seoTitle; ?>
</b></p>
  <p>SEO Keyword: <b><?php echo $this->_tpl_vars['myEntry']->seoKeyword; ?>
</b></p>
  <p>Description: <b><?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['myEntry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 500) : smarty_modifier_truncate($_tmp, 500)); ?>
</b></p>
  <p>-----------------------------------------------------------------</p>
  <p><a href="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/edit" title="Edit this entry">Edit</a></p> 
  
  

  

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyMailGroupContainer'])."footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>