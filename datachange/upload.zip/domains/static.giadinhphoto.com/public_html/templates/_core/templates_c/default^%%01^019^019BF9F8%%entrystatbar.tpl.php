<?php /* Smarty version 2.6.26, created on 2010-07-15 22:49:39
         compiled from _controller/site/entrystatbar.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', '_controller/site/entrystatbar.tpl', 4, false),)), $this); ?>
<div class="moreinfo">
					<div class="moreinfosub">
						<div class="view"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewLabel']; ?>
: <?php echo $this->_tpl_vars['myEntry']->view; ?>

							<?php if ($this->_tpl_vars['me']->id > 0): ?><a class="reportabuse" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
reportabuse.html?type=entry&id=<?php echo $this->_tpl_vars['myEntry']->id; ?>
" rel="shadowbox;width=500;height=250" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
 : <?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->title)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_report.gif" /> <?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
</a><?php endif; ?>
						</div>
						<div class="rating"><div class="count">(<?php echo $this->_tpl_vars['myEntry']->ratingCount; ?>
)</div><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['myEntry']->getRoundRating(); ?>
.png"  title="<?php if ($this->_tpl_vars['myEntry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['myEntry']->rating; ?>
<?php endif; ?>" alt="rating" /></div>
					</div>
				</div>
				
				