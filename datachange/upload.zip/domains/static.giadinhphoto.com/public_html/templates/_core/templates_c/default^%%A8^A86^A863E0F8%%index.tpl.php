<?php /* Smarty version 2.6.26, created on 2010-07-31 23:11:44
         compiled from _controller/site/notfound/index.tpl */ ?>


<div id="pageBody">
<div id="primary">
<br />
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyWarning' => $this->_tpl_vars['lang']['global']['pagenotfound'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div>
<?php echo $this->_tpl_vars['page']->contents[$this->_tpl_vars['langCode']]; ?>

</div>


<!-- / id primary --></div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."sidebar_home.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!-- / id pageBody --></div>