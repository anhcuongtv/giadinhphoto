<?php /* Smarty version 2.6.26, created on 2010-07-19 10:17:20
         compiled from _controller/site/entryotherbox.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entryotherbox.tpl', 1, false),array('modifier', 'strip_tags', '_controller/site/entryotherbox.tpl', 15, false),array('modifier', 'truncate', '_controller/site/entryotherbox.tpl', 15, false),array('modifier', 'escape', '_controller/site/entryotherbox.tpl', 15, false),)), $this); ?>
<?php if (count($this->_tpl_vars['otherCategoryEntries']) > 0): ?>
	<div class="box2col">
		<div class="box2col-head box2col-head-grey">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['entryOtherCategoryLabel']; ?>
</div>
		</div>
		<div class="box2col-body">
			<?php $_from = $this->_tpl_vars['otherCategoryEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['entrylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['entrylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['entry']):
        $this->_foreach['entrylist']['iteration']++;
?>
			<div class="box2col-entry<?php if ($this->_foreach['entrylist']['iteration'] % 2 == 0): ?> box2col-entry-even<?php endif; ?>">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<div class="category"><a href="<?php echo $this->_tpl_vars['entry']->getParentCategoryFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->getParentCategoryName(); ?>
"><?php echo $this->_tpl_vars['entry']->getParentCategoryName(); ?>
</a></div>
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->view; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewTooltip']; ?>
"><?php echo $this->_tpl_vars['entry']->view; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
					</div>
				</div>
				
			</div>
			<?php if ($this->_foreach['entrylist']['iteration'] % 2 == 0): ?><div class="clear"></div><?php endif; ?>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="box2col-foot">
		</div>
	</div><!-- end of .box2col -->
	<?php endif; ?>
	
	
	
<?php if (count($this->_tpl_vars['websiteLatestEntries']) > 0): ?>
	<div class="box2col">
		<div class="box2col-head box2col-head-blue">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['entryLatestLabel']; ?>
</div>
		</div>
		<div class="box2col-body">
			<?php $_from = $this->_tpl_vars['websiteLatestEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['entrylist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['entrylist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['entry']):
        $this->_foreach['entrylist']['iteration']++;
?>
			<div class="box2col-entry<?php if ($this->_foreach['entrylist']['iteration'] % 2 == 0): ?> box2col-entry-even<?php endif; ?>">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<div class="category"><a href="<?php echo $this->_tpl_vars['entry']->getParentCategoryFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->getParentCategoryName(); ?>
"><?php echo $this->_tpl_vars['entry']->getParentCategoryName(); ?>
</a></div>
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->view; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewTooltip']; ?>
"><?php echo $this->_tpl_vars['entry']->view; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
					</div>
				</div>
				
			</div>
			<?php if ($this->_foreach['entrylist']['iteration'] % 2 == 0): ?><div class="clear"></div><?php endif; ?>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="box2col-foot">
		</div>
	</div><!-- end of .box2col -->
	<?php endif; ?>