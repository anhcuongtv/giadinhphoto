<?php /* Smarty version 2.6.26, created on 2010-07-12 12:43:17
         compiled from _controller/admin/diary/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/admin/diary/index.tpl', 25, false),array('modifier', 'upper', '_controller/admin/diary/index.tpl', 29, false),array('modifier', 'nl2br', '_controller/admin/diary/index.tpl', 70, false),array('modifier', 'date_format', '_controller/admin/diary/index.tpl', 79, false),array('modifier', 'relative_datetime', '_controller/admin/diary/index.tpl', 79, false),array('modifier', 'htmlspecialchars', '_controller/admin/diary/index.tpl', 106, false),array('function', 'paginate', '_controller/admin/diary/index.tpl', 55, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_list']; ?>
</h2>
<div id="page-intro"><?php echo $this->_tpl_vars['lang']['controller']['intro_list']; ?>
</div>

<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_list']; ?>
 <?php if ($this->_tpl_vars['formData']['search'] != ''): ?>| <?php echo $this->_tpl_vars['lang']['controller']['title_listSearch']; ?>
 <?php endif; ?>(<?php echo $this->_tpl_vars['total']; ?>
)</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['tableTabLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controllergroup']['filterLabel']; ?>
</a></li>
		</ul>
		<?php if ($this->_tpl_vars['formData']['search'] != ''): ?>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
diary"><?php echo $this->_tpl_vars['lang']['controllergroup']['formViewAll']; ?>
</a></li>
		</ul>
		<?php endif; ?>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			<form action="" method="post" name="manage" onsubmit="return confirm('Are You Sure ?');">
				<table class="grid">
					
				<?php if (count($this->_tpl_vars['entries']) > 0): ?>
					<thead>
						<tr>
						   <th width="40"><input class="check-all" type="checkbox" /></th>
							<th width="30"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
</a></th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
</th>	
							<th width="70"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/type/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'type'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
</a></th>	
							<th width="50"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/emoticon/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'emoticon'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formEmoticonLabel']; ?>
</a></th>	
							<th width="50"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/mode/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'mode'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formModeLabel']; ?>
</a></th>	
							<th width="50"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/status/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'status'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formEnableLabel']; ?>
</a></th>	
							<th width="50"><?php echo $this->_tpl_vars['lang']['controller']['formIpAddressLabel']; ?>
</th>
							<th width="100"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/dateaction/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'dateaction'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formDateActionLabel']; ?>
</a></th>
							<th width="100"><a href="<?php echo $this->_tpl_vars['filterUrl']; ?>
sortby/id/sorttype/<?php if ($this->_tpl_vars['formData']['sortby'] == 'id'): ?><?php if (((is_array($_tmp=$this->_tpl_vars['formData']['sorttype'])) ? $this->_run_mod_handler('upper', true, $_tmp) : smarty_modifier_upper($_tmp)) != 'DESC'): ?>DESC<?php else: ?>ASC<?php endif; ?><?php endif; ?>"><?php echo $this->_tpl_vars['lang']['controller']['formDateCreatedLabel']; ?>
</a></th>
							<th width="70"></th>
						</tr>
					</thead>
					
					<tfoot>
						<tr>
							<td colspan="13">
								<div class="bulk-actions align-left">
									<select name="fbulkaction">
										<option value=""><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSelectLabel']; ?>
</option>
										<option value="delete"><?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionDeletetLabel']; ?>
</option>
									</select>
									<input type="submit" name="fsubmitbulk" class="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['bulkActionSubmit']; ?>
" />
								</div>
								
								<div class="pagination">
								   <?php $this->assign('pageurl', "page/::PAGE::"); ?>
									<?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

								</div> <!-- End .pagination -->
		
								<div class="clear"></div>
							</td>
						</tr>
					</tfoot>
					<tbody>
				<?php $_from = $this->_tpl_vars['entries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
					
						<tr>
							<td><input type="checkbox" name="fbulkid[]" value="<?php echo $this->_tpl_vars['entry']->id; ?>
" <?php if (in_array ( $this->_tpl_vars['entry']->id , $this->_tpl_vars['formData']['fbulkid'] )): ?>checked="checked"<?php endif; ?>/></td>
							<td style="font-weight:bold;"><?php echo $this->_tpl_vars['entry']->id; ?>
</td>
							<td><a style="font-weight:bold;" target="_blank" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['entry']->user->username; ?>
"><?php echo $this->_tpl_vars['entry']->user->username; ?>
</a>
								<div style="font-size:11px;">
									<a target="_blank" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['diary']['seoUrl']; ?>
/index/user/<?php echo $this->_tpl_vars['entry']->user->username; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/quote_icon.png" alt="quote" border="0" /></a><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>

								</div>
							</td>
							<td><?php echo $this->_tpl_vars['entry']->getTypeName(); ?>
</td>
							<td><img title="<?php echo $this->_tpl_vars['entry']->emoticon; ?>
" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/<?php echo $this->_tpl_vars['entry']->emoticon; ?>
.png" alt="<?php echo $this->_tpl_vars['entry']->emoticon; ?>
" /></td>
							<td class="td_center"><?php if ($this->_tpl_vars['entry']->mode == 'private'): ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/lock.png" alt="private" /><?php endif; ?></td>
							<td><?php if ($this->_tpl_vars['entry']->enable == '1'): ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/tick_circle.png" title="Enable" alt="enable" /><?php else: ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross_circle.png" title="disable" alt="disable" /><?php endif; ?>
							</td>
							<td><?php echo $this->_tpl_vars['entry']->ipaddress; ?>
</td>
							<td title="<?php echo $this->_tpl_vars['lang']['controller']['formRelativetimeAboutLabel']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->dateaction)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->dateaction)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</td>
							<td title="<?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['entry']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</td>
							<td><a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionEditTooltip']; ?>
" href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
diary/edit/id/<?php echo $this->_tpl_vars['entry']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/pencil.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formEditLabel']; ?>
" width="16"/></a> &nbsp;
							<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['formActionDeleteTooltip']; ?>
" href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
diary/delete/id/<?php echo $this->_tpl_vars['entry']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
?token=<?php echo $_SESSION['securityToken']; ?>
');"><img border="0" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/admin/icons/cross.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['formDeleteLabel']; ?>
" width="16"/></a>
							</td>
						</tr>
						
					
				<?php endforeach; endif; unset($_from); ?>
				</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="13"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
	
		</div>
		
		<div class="tab-content" id="tab2">
			<form action="" method="post" style="padding:0px;margin:0px;" onsubmit="return false;">
	
				<?php echo $this->_tpl_vars['lang']['controllergroup']['formIdLabel']; ?>
: 
				<input type="text" name="fid" id="fid" size="8" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fid']); ?>
" class="text-input" /> - 
				
				
					<?php echo $this->_tpl_vars['lang']['controller']['formEnableLabel']; ?>
:	
					<select name="fenable" id="fenable">
						<option value="">- - - - - - - - - - - - -</option>
						<option value="1" <?php if ($this->_tpl_vars['formData']['fenable'] == '1'): ?>selected="selected"<?php endif; ?>>Enabled</option>
						<option value="0" <?php if ($this->_tpl_vars['formData']['fenable'] == '0'): ?>selected="selected"<?php endif; ?>>Disabled</option>
					</select> -
					
					<?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
:	
					<select name="ftype" id="ftype">
							<option value="">- - - - - - - - - - - - -</option>
							<option value="play" <?php if ($this->_tpl_vars['formData']['ftype'] == 'play'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypePlay']; ?>
</option>
							<option value="eat" <?php if ($this->_tpl_vars['formData']['ftype'] == 'eat'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeEat']; ?>
</option>
							<option value="shopping" <?php if ($this->_tpl_vars['formData']['ftype'] == 'shopping'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeShopping']; ?>
</option>
							<option value="meet" <?php if ($this->_tpl_vars['formData']['ftype'] == 'meet'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeMeet']; ?>
</option>
							<option value="sms" <?php if ($this->_tpl_vars['formData']['ftype'] == 'sms'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeSms']; ?>
</option>
							<option value="phone" <?php if ($this->_tpl_vars['formData']['ftype'] == 'phone'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypePhone']; ?>
</option>
							<option value="chat" <?php if ($this->_tpl_vars['formData']['ftype'] == 'chat'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeChat']; ?>
</option>
							<option value="think" <?php if ($this->_tpl_vars['formData']['ftype'] == 'think'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeThink']; ?>
</option>
					</select> -
					
					
					
					<?php echo $this->_tpl_vars['lang']['controller']['formKeywordLabel']; ?>
:
				
					<input type="text" name="fkeyword" id="fkeyword" size="20" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fkeyword']); ?>
" class="text-input" /><select name="fsearchin" id="fsearchin">
						<option value="">- - - - - - - - - - - - -</option>
						<option value="content" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'content'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInContentLabel']; ?>
</option>
						<option value="ipaddress" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'ipaddress'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInIpAddressLabel']; ?>
</option>
						<option value="username" <?php if ($this->_tpl_vars['formData']['fsearchin'] == 'username'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controller']['formKeywordInUsernameLabel']; ?>
</option>
						
					</select>
					
				
				
				
				<input type="button" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['filterSubmit']; ?>
" class="button" onclick="gosearchdiary();"  />
				<br /><br />
				
				<span title="Ignore emoticon">
					<input class="entry-radio" type="radio" name="femoticon" id="femoticon" value="" />
					<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/16/0.png" alt="" /></span> &nbsp; &nbsp; &nbsp;
					
				<span><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'happy'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="happy" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/happy.png" alt="happy" /></span> &nbsp; &nbsp; &nbsp;
							
				<span title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonLove']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'love'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="love" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/love.png" alt="love" /></span> &nbsp; &nbsp; &nbsp;
				
				<span title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonNormal']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'normal'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="normal" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/normal.png" alt="normal" /></span> &nbsp; &nbsp; &nbsp;
				
				<span title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonAngry']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'angry'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="angry" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/angry.png" alt="angry" /></span> &nbsp; &nbsp; &nbsp;
				
				<span title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonSad']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'sad'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="sad" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/sad.png" alt="sad" /></span> &nbsp; &nbsp; &nbsp;
				
				<span title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonCry']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'cry'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" id="femoticon" value="cry" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/cry.png" alt="cry" /></span>
						
				-
				
				<?php echo $this->_tpl_vars['lang']['controller']['formModeLabel']; ?>
:	
				<select name="fmode" id="fmode">
					<option value="">- - - - - - - - - - - - -</option>
					<option value="private" <?php if ($this->_tpl_vars['formData']['fmode'] == 'private'): ?>selected="selected"<?php endif; ?>>Private</option>
					<option value="public" <?php if ($this->_tpl_vars['formData']['fmode'] == 'public'): ?>selected="selected"<?php endif; ?>>Public</option>
				</select> 
							
			</form>
		</div>
		
		
	
	</div>
	

    	
</div>

<?php echo '
<script type="text/javascript">
	function gosearchdiary()
	{
		var path = rooturl_admin + "diary/index";
		
		var id = $("#fid").val();
		if(parseInt(id) > 0)
		{
			path += "/id/" + id;
		}
		
				
		var type = $("#ftype").val();
		if(type.length > 0)
		{
			path += "/type/" + type;
		}
		
		var emoticon = $("input[name=femoticon]:checked").val(); 
		if(emoticon.length > 0)
		{
			path += "/emoticon/" + emoticon;
		}
		
		var mode = $("#fmode").val();
		if(mode.length > 0)
		{
			path += "/mode/" + mode;
		}
		
		
		var enable = $("#fenable").val();
		if(enable.length > 0)
		{
			path += "/enable/" + enable;
		}
		
		
		
		var keyword = $("#fkeyword").val();
		if(keyword.length > 0)
		{
			path += "/keyword/" + keyword;
		}
		
		var keywordin = $("#fsearchin").val();
		if(keywordin.length > 0)
		{
			path += "/searchin/" + keywordin;
		}
		
				
		document.location.href= path;
	}
</script>
'; ?>



