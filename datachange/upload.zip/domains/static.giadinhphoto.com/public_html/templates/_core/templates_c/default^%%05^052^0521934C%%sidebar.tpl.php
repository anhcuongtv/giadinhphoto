<?php /* Smarty version 2.6.26, created on 2013-10-21 16:43:38
         compiled from _controller/site/sidebar.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'sidebar_news', '_controller/site/sidebar.tpl', 39, false),)), $this); ?>
 <div id="sidebar">
	<?php if ($this->_tpl_vars['controller'] != 'login'): ?>
            <div class="member-login">
            
                <?php if ($this->_tpl_vars['me']->id > 0): ?>
                    <p style="font-weight: bold; font-size: 16px;"><?php echo $this->_tpl_vars['lang']['controllergroup']['hi']; ?>
, <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html" title="Memberarea"><?php echo $this->_tpl_vars['me']->username; ?>
</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
logout.html" title="<?php echo $this->_tpl_vars['lang']['global']['mLogout']; ?>
" style="color:#999;"><?php echo $this->_tpl_vars['lang']['global']['mLogout']; ?>
</a></p>
                    
                    
                <?php else: ?>
                    <h2>Member Login</h2>
                <form action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
login.html" method="post">
                    <ul>
                        <li><label for="user">User name</label><input type="text" id="user" name="fusername" value="" /></li>
                        <li><label for="password">Password</label><input type="password" id="password" name="fpassword" value="" /></li>
                    </ul>
                    <p class="submit"><input type="submit" id="submit" value="Login" name="fsubmit" /></p>
                    <p class="note">
                        <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
forgotpass.html" style="float:left"><?php echo $this->_tpl_vars['lang']['controllergroup']['forgot']; ?>
</a>
                        <?php if ($this->_tpl_vars['setting']['extra']['enableRegister']): ?><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html" style="float:right"><?php echo $this->_tpl_vars['lang']['controllergroup']['register']; ?>
</a><?php endif; ?>
                    </p>
                </form>
                    
                    
                <?php endif; ?>
           
                
            </div>
<?php endif; ?>
            
            <p class="pb10"><a href="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/patronage-vn13.jpg"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/img-fiap-patronage.gif" alt="" /></a></p>
            <p class="paypal"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/img-paypal.gif" alt="" /><span>Secure Payments by Paypal</span></p>
            <p class="banner"><a href="#" target="_blank"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/banner01.jpg" alt="" /></a></p>
            <p class="banner"><a href="#" target="_blank"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/banner02.jpg" alt="" /></a></p>
            <div class="section">
                <?php if ($this->_tpl_vars['setting']['extra']['enableNews'] == TRUE): ?>
                <div id="sidebar-news">
                    <div class="head"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/greybox-logo.png" alt="" /> <?php echo $this->_tpl_vars['lang']['controllergroup']['aboutThisContest']; ?>
</div>
                    <div class="body">                        
                        <div class="detail"><?php echo smarty_function_sidebar_news(array(), $this);?>
</div>
                    </div>
                </div>
                <?php endif; ?>
            </div><!-- end section -->
        </div><!-- end sidebar -->