<?php /* Smarty version 2.6.26, created on 2013-10-27 16:20:40
         compiled from _controller/site/memberarea/editphoto.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_controller/site/memberarea/editphoto.tpl', 10, false),)), $this); ?>
<div id="pagebody">
    	<h1 id="title"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" /></h1>
        <div id="content">
		
		<!-- code html o day -->
<div id="photodetail">
<strong>Edit: <?php echo $this->_tpl_vars['myPhoto']->name; ?>
 - [<?php echo $this->_tpl_vars['myPhoto']->getSection(); ?>
]</strong>
<div class="poster">
<div class="avatar"><img alt="<?php echo $this->_tpl_vars['myPhoto']->name; ?>
" title="<?php echo $this->_tpl_vars['myPhoto']->description; ?>
" src="<?php echo $this->_tpl_vars['myPhoto']->getImage('thumb2'); ?>
" /></div>
<div class="box2"><?php echo $this->_tpl_vars['myPhoto']->resolution; ?>
 pixel<br /><?php echo ((is_array($_tmp=$this->_tpl_vars['myPhoto']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp) : smarty_modifier_date_format($_tmp)); ?>
</div>
<div class="box3"><strong><?php echo $this->_tpl_vars['myPhoto']->view; ?>
 view(s)</div>
</div>
</div>

<div id="page">
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

    <form method="post" action="">
    <input type="hidden" name="ftoken" value="<?php echo $_SESSION['editPhotoToken']; ?>
" />
        <table>
                <tr>
                    <td align="right" width="150" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['section']; ?>
:</td>
                    <td style="padding:5px;"><select name="fsection">
                            <option value=""><?php echo $this->_tpl_vars['lang']['global']['photoSectionSelectOne']; ?>
</option>
                                <option value="envir" <?php if ($this->_tpl_vars['formData']['fsection'] == 'envir'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionEnvir']; ?>
</option>
                                <option value="land" <?php if ($this->_tpl_vars['formData']['fsection'] == 'land'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionLand']; ?>
</option>
                                <option value="wild" <?php if ($this->_tpl_vars['formData']['fsection'] == 'wild'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionWild']; ?>
</option>
                                <option value="flo" <?php if ($this->_tpl_vars['formData']['fsection'] == 'flo'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionFlo']; ?>
</option>
								<option value="in" <?php if ($this->_tpl_vars['formData']['fsection'] == 'in'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionIn']; ?>
</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td align="right" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['photoname']; ?>
:</td>
                    <td style="padding:5px;"><input type="text" name="fname" value="<?php echo $this->_tpl_vars['formData']['fname']; ?>
" size="40" />
                    </td>
                </tr>
                
                
                <tr>
                    <td align="right" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['photodescription']; ?>
:</td>
                    <td style="padding:5px;"><input type="text" name="fdescription" value="<?php echo $this->_tpl_vars['formData']['fdescription']; ?>
" size="40" />
                    </td>
                </tr>
                <tr>
                    <td align="right" style="padding:5px;"></td>
                    <td style="padding:5px;"><input class="btnSubmit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controller']['updateBtn']; ?>
" />
                    </td>
                </tr>
            </table>
    </form>
</div>


		
		
		
		<!-- ---->
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->