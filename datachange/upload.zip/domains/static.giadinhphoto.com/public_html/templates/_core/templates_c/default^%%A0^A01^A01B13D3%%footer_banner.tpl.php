<?php /* Smarty version 2.6.26, created on 2010-08-14 14:33:59
         compiled from _controller/site/footer_banner.tpl */ ?>
<div id="bottom">
<p class="image"><a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_camera.jpg" alt="Camare"></a></p>
<h3>SPONSORS</h3>
<p class="banner">
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_canon.gif" alt="Canon"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_nikon.gif" alt="Nikon"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_samsung.gif" alt="SAMSUNG"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_sony.gif" alt="SONY"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_olympus.gif" alt="OLYMPUS"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_kodak.gif" alt="Kodak"></a>
<a href="#"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/bnr_hp.gif" alt="HP"></a>
</p>
<!-- / id bottom --></div>