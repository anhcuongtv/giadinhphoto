<?php /* Smarty version 2.6.26, created on 2010-07-13 09:25:52
         compiled from _controller/admin/quiz/add.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'htmlspecialchars', '_controller/admin/quiz/add.tpl', 24, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_add']; ?>
</h2>

<form action="" method="post" name="myform" enctype="multipart/form-data">
<input type="hidden" name="ftoken" value="<?php echo $_SESSION['quizAddToken']; ?>
" />
<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_add']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" id="tab1_link" <?php if ($this->_tpl_vars['tab'] == '' || $this->_tpl_vars['tab'] == 1): ?>class="default-tab"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['controllergroup']['formFormLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['redirectUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content<?php if ($this->_tpl_vars['tab'] == '' || $this->_tpl_vars['tab'] == 1): ?> default-tab<?php endif; ?>" id="tab1">
			<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			
				<table class="form" cellpadding="5" cellspacing="5">
					<tr>
						<td width="150" class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTitleLabel']; ?>
 <span class="star_require">*</span> : </td>
						<td><input type="text" name="ftitle" id="ftitle" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['ftitle']); ?>
" class="text-input"></td>
					</tr>
					<tr>
						<td width="150" class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
 <span class="star_require">*</span> : </td>
						<td><label><input type="radio" name="ftype" value="abc" <?php if ($this->_tpl_vars['formData']['ftype'] == '' || $this->_tpl_vars['formData']['ftype'] == 'abc'): ?>checked="checked"<?php endif; ?> /><?php echo $this->_tpl_vars['lang']['controller']['formTypeAbc']; ?>
</label> - 
						<label><input type="radio" name="ftype" value="point" <?php if ($this->_tpl_vars['formData']['ftype'] == 'point'): ?>checked="checked"<?php endif; ?>/><?php echo $this->_tpl_vars['lang']['controller']['formTypePoint']; ?>
</label></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formImageLabel']; ?>
 : </td>
						<td><input type="file" id="fimage" name="fimage" /></td>
					</tr>
					
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formDescriptionLabel']; ?>
 : </td>
						<td><textarea class="text-input wysiwyg"  rows="8" name="fdescription" cols="80" id="fdescription"><?php echo $this->_tpl_vars['formData']['fdescription']; ?>
</textarea></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTagLabel']; ?>
 : </td>
						<td><input type="text" name="ftag" id="ftag" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['ftag']); ?>
" class="text-input"></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formRelatedLabel']; ?>
 :</td>
						<td><input type="text" name="frelated" id="frelated" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['frelated']); ?>
" class="text-input">
					<br />
					<small><?php echo $this->_tpl_vars['lang']['controller']['formRelatedHelpLabel']; ?>
</small></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoUrlLabel']; ?>
 :</td>
						<td><input type="text" name="fseourl" id="fseourl" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseourl']); ?>
" class="text-input">
					<br />
					<small><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['quiz']['seoUrl']; ?>
/[SEO_URL]-[ID].html</small></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoTitleLabel']; ?>
 :</td>
						<td><input type="text" name="fseotitle" id="fseotitle" size="80" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['fseotitle']); ?>
" class="text-input"></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoKeywordLabel']; ?>
 :</td>
						<td><textarea class="text-input"  rows="2" name="fseokeyword" id="fseokeyword"><?php echo $this->_tpl_vars['formData']['fseokeyword']; ?>
</textarea></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['formSeoDescriptionLabel']; ?>
 :</td>
						<td><textarea class="text-input"  rows="2" name="fseodescription" id="fseodescription"><?php echo $this->_tpl_vars['formData']['fseodescription']; ?>
</textarea></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedLabel']; ?>
 :</td>
						<td><input type="hidden" name="fismoderated" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedTooltip']; ?>
" type="checkbox" name="fismoderated" value="1"<?php if ($this->_tpl_vars['formData']['fismoderated'] == '1'): ?> checked="checked"<?php endif; ?> /></td>
					</tr>
					<tr>
						<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextLabel']; ?>
 :</td>
						<td><input type="hidden" name="fignorecleanbadword" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextTooltip']; ?>
" type="checkbox" name="fignorecleanbadword" value="1"<?php if ($this->_tpl_vars['formData']['fignorecleanbadword'] == '1' || $this->_tpl_vars['formData']['fsubmit'] == ''): ?> checked="checked"<?php endif; ?> /></td>
					</tr>
					
				</table>
				
		</div>
		
				
	
		
	</div>
	
	<div class="content-box-content-alt">
		<fieldset>
		<p>
			<input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formAddSubmit']; ?>
" class="button buttonbig">
			<br /><small><span class="star_require">*</span> : <?php echo $this->_tpl_vars['lang']['controllergroup']['formRequiredLabel']; ?>
</small>
		</p>
		</fieldset>
	</div>

    	
</div>
</form>