<?php /* Smarty version 2.6.26, created on 2013-10-28 16:51:52
         compiled from _controller/site/checkout/placeorder.tpl */ ?>
<div id="pagebody">
    	    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content" style="background: none repeat scroll 0 0 #FFFFFF;">
        
    <div id="page">
    <strong style="font-size:21px"><?php echo $this->_tpl_vars['lang']['controller']['paymentTitle']; ?>
</strong><br /><br />

        <div>               
<p>&nbsp; </p>                
        <div align="left" style="font-weight:bold;font-size:20px;margin-left:10px;color:#67b718;"><?php echo $this->_tpl_vars['lang']['controller']['reviewBuySuccessText']; ?>

        
<p>&nbsp; </p>
<?php echo $this->_tpl_vars['lang']['controller']['reviewContinue']; ?>

<p>&nbsp; </p>       
        
        </div>
    
    </div>
    </div>

    
 </div>
		
		
		
		<!-- ---->
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->