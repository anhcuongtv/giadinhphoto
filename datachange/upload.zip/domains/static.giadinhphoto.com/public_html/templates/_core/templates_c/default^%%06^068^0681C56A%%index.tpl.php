<?php /* Smarty version 2.6.26, created on 2010-07-05 17:53:29
         compiled from _controller/site/map/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'default', '_controller/site/map/index.tpl', 6, false),)), $this); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/favicon.ico"/>
<title><?php echo ((is_array($_tmp=@$this->_tpl_vars['pageTitle'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['site']['defaultPageTitle']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['site']['defaultPageTitle'])); ?>
</title>
<meta name="author" content="Vo Duy Tuan, tuanmaster2002@yahoo.com" />
<meta name="keywords" content="<?php echo ((is_array($_tmp=@$this->_tpl_vars['pageKeyword'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['site']['defaultPageKeyword']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['site']['defaultPageKeyword'])); ?>
" />
<meta name="description" content="<?php echo ((is_array($_tmp=@$this->_tpl_vars['pageDescription'])) ? $this->_run_mod_handler('default', true, $_tmp, @$this->_tpl_vars['setting']['site']['defaultPageDescription']) : smarty_modifier_default($_tmp, @$this->_tpl_vars['setting']['site']['defaultPageDescription'])); ?>
" />
<style type="text/css">
<?php echo '
body{background:#fff;font-size:12px; font-family:Arial, Helvetica, sans-serif;}
#map-controller{ background:#FC69ED; padding:12px; font-size:16px; font-weight:bold;}
input{font-size:14px; padding:5px;border-radius: 8px; -moz-border-radius: 8px; -webkit-border-radius: 8px;}
#mapbtn{border:1px solid #069; color:#fff; padding:5px 10px; background:#09F; font-weight:bold;cursor:pointer;}
#mapbtn:hover{background:#F60;}
'; ?>

</style>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/jquery.js"></script>
<script src="http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=<?php echo $this->_tpl_vars['setting']['site']['googleMapApiKey']; ?>
" type="text/javascript"></script>
    <script type="text/javascript">

    var map = null;
    var geocoder = null;
	var directionsPanel;
    var directions;
	var latlng;
	var latlng2;
	var langNotFound = "<?php echo $this->_tpl_vars['lang']['controller']['jsAddressNotFound']; ?>
";
	
<?php echo '
    function initialize() {
      if (GBrowserIsCompatible()) {
        map = new GMap2(document.getElementById("map_canvas"));
        map.setCenter(new GLatLng(10.8145906, 106.6896164), 15);
		map.setUIToDefault();

        geocoder = new GClientGeocoder();
		
		

      }
    }

    function showAddress() {
		
		address = $("#faddress").val();
		
      if (geocoder) {
        geocoder.getLatLng(
          address,
          function(point) {
            if (!point) {
              alert(langNotFound + \' \' + address);
            } else {
              map.setCenter(point, 15);
              var marker = new GMarker(point);
              map.addOverlay(marker);
              marker.openInfoWindowHtml(address);
            }
          }
        );
      }
    }
	
	
	//jquery fx begin
	$(document).ready(function()
	{
		initialize();
		showAddress();	
	
	});
'; ?>
	
	
    </script>

</head>

<body>
<div id="map-controller">
	<?php echo $this->_tpl_vars['lang']['controller']['address']; ?>
 : <input type="text" name="faddress" id="faddress" style="width:500px;" value="<?php echo $this->_tpl_vars['faddress']; ?>
" /> <input id="mapbtn" type="button" value="<?php echo $this->_tpl_vars['lang']['controller']['viewAddressBtn']; ?>
" onclick="showAddress()" />
</div>


<div id="map_canvas" style="float:left;width:100%; height:440px;"></div>
</body>
</html>