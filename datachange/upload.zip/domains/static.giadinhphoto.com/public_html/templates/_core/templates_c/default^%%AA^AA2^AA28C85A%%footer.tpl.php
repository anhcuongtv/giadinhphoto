<?php /* Smarty version 2.6.26, created on 2013-10-27 13:42:11
         compiled from _controller/site/footer.tpl */ ?>

<div id="footer">
	<div id="footer-inner">
    	<p class="flogo"><img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/f-logo.png" alt="Câu lạc bộ nhiếp ảnh Gia Định" /></p>
        <div class="fblock">
			<ul>            	
				<li <?php if ($this->_tpl_vars['controller'] == 'index'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['mTrangchu']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'rules'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-rules.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mThele']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'awards'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-awards.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mGiaithuong']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'page' && $this->_tpl_vars['pagename'] == 'judge'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
article-judge.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mGiamkhao']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'statuslist'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
statuslist.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mTrangthai']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'memberarea'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mXemanh']; ?>
</a></li>
				<li <?php if ($this->_tpl_vars['controller'] == 'contact'): ?>class="active"<?php endif; ?>><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
contact.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['mLienhe']; ?>
</a></li>
		   
            </ul>        
            <p class="copyright"><?php echo $this->_tpl_vars['lang']['controllergroup']['copyrightText']; ?>
 <a href="#"><?php echo $this->_tpl_vars['lang']['controllergroup']['copyrightTextLinkPolicy']; ?>
</a></p>
            <p class="contest"><?php echo $this->_tpl_vars['lang']['controllergroup']['copyrightTextSub']; ?>
</p>
            <p class="dev"><?php echo $this->_tpl_vars['lang']['controllergroup']['copyrightDevText']; ?>
<a href="http://imsvietnam.com" title="iMS Vietnam"><?php echo $this->_tpl_vars['lang']['controllergroup']['copyrightDevLink']; ?>
</a></p>
        </div>
    </div>
</div><!-- footer -->
</body>
</html>