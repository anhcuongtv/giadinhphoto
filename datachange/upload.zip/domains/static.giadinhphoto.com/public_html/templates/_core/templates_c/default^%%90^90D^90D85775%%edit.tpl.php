<?php /* Smarty version 2.6.26, created on 2010-07-12 16:51:03
         compiled from _controller/site/diary/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_controller/site/diary/edit.tpl', 38, false),array('modifier', 'relative_datetime', '_controller/site/diary/edit.tpl', 38, false),)), $this); ?>
<div id="sidebar1">
	<div id="entry-addbutton">
		<a href="<?php echo $this->_tpl_vars['backUrl']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/entry-back-button.png" border="0" /></a>
	</div>
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-blue">
			<div><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myUser']->username; ?>
"><?php echo $this->_tpl_vars['myUser']->username; ?>
</a></div>
		</div>
		<div class="sidebar-box-body">
			<p><?php if ($this->_tpl_vars['myUser']->avatar != ''): ?>
						<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myUser']->username; ?>
"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['avatar']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['myUser']->avatar; ?>
" border="0" /></a><?php endif; ?></p>
			<p><strong><?php echo $this->_tpl_vars['lang']['controller']['fullname']; ?>
</strong> : <?php echo $this->_tpl_vars['myUser']->fullname; ?>
</p>
			<?php if ($this->_tpl_vars['myUser']->gender != 'unknown'): ?>
				<p><strong><?php echo $this->_tpl_vars['lang']['controllergroup']['userGender']; ?>
</strong> : 
					<?php if ($this->_tpl_vars['myUser']->gender == 'male'): ?>
						<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_male.png" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderMale']; ?>
" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderMale']; ?>
" />
					<?php else: ?>
						<img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_female.png" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderFemale']; ?>
" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['userGenderFemale']; ?>
" />
					<?php endif; ?>
					
					<?php if ($this->_tpl_vars['myUser']->lovestatus != 'unknown'): ?>
							<?php if ($this->_tpl_vars['myUser']->lovestatus == 'single'): ?>
								<span class="lovestatus_badge lovestatus_badge_single"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusSingle']; ?>
</span>
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'just'): ?>
								<span class="lovestatus_badge lovestatus_badge_just"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusJust']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'deep'): ?>
								<span class="lovestatus_badge lovestatus_badge_deep"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusDeep']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'wedding'): ?>
								<span class="lovestatus_badge lovestatus_badge_wedding"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusWedding']; ?>
</span>	
							<?php elseif ($this->_tpl_vars['myUser']->lovestatus == 'old'): ?>
								<span class="lovestatus_badge lovestatus_badge_old"><?php echo $this->_tpl_vars['lang']['controllergroup']['userLovestatusOld']; ?>
</span>	
							<?php endif; ?>
					<?php endif; ?>
					
				</p>
			<?php endif; ?>
			
			<p title="<?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty'])); ?>
"><strong><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
</strong> : <?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</p>
			<p title="<?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datelastlogin)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['global']['dateFormatSmarty'])); ?>
"><strong><?php echo $this->_tpl_vars['lang']['controller']['datelastlogin']; ?>
</strong> : <?php echo ((is_array($_tmp=$this->_tpl_vars['myUser']->datelastlogin)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</p>
			
			<?php if ($this->_tpl_vars['myUser']->id == $this->_tpl_vars['me']->id): ?>
			<div style="padding:5px 0; background:#fff; text-align:center;">
				<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
profile.html"><?php echo $this->_tpl_vars['lang']['controllergroup']['editProfileLabel']; ?>
</a>
			</div>
			<?php endif; ?>
		</div>
	</div>
	
	
</div><!-- end of #sidebar1 -->


<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['titleEdit']; ?>
</h1></div>
	<div id="page-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
			
			<div id="mainform-form-register">
				<form action="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl('edit'); ?>
<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" method="post">
					<input type="hidden" name="ftoken" value="<?php echo $_SESSION['diaryEditToken']; ?>
" />
					
					<div class="form-entry">
						<div class="form-entry-label"></div>
						<div>
							<span style="color:#aaa;"><em><?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->dateaction)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
 &lt;<?php echo $this->_tpl_vars['lang']['controllergroup']['diaryAboutTime']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->dateaction)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
&gt;</em></span>
						</div>
					</div>
					
					<div class="form-entry">
						<div class="form-entry-label form-entry-label-normalfont"><label><?php echo $this->_tpl_vars['lang']['controller']['type']; ?>
:</label></div>
						<div class="form-entry-big-textbox">
							<select class="entry-selectbox" name="ftype" class="diarybar-type">
								<optgroup label="<?php echo $this->_tpl_vars['lang']['global']['diaryType']; ?>
">
									<option value="play" <?php if ($this->_tpl_vars['formData']['ftype'] == 'play'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypePlay']; ?>
</option>
									<option value="eat" <?php if ($this->_tpl_vars['formData']['ftype'] == 'eat'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeEat']; ?>
</option>
									<option value="shopping" <?php if ($this->_tpl_vars['formData']['ftype'] == 'shopping'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeShopping']; ?>
</option>
									<option value="meet" <?php if ($this->_tpl_vars['formData']['ftype'] == 'meet'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeMeet']; ?>
</option>
									<option value="sms" <?php if ($this->_tpl_vars['formData']['ftype'] == 'sms'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeSms']; ?>
</option>
									<option value="phone" <?php if ($this->_tpl_vars['formData']['ftype'] == 'phone'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypePhone']; ?>
</option>
									<option value="chat" <?php if ($this->_tpl_vars['formData']['ftype'] == 'chat'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeChat']; ?>
</option>
									<option value="think" <?php if ($this->_tpl_vars['formData']['ftype'] == 'think'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['diaryTypeThink']; ?>
</option>
								</optgroup>
							</select>
							
						</div>
					</div>
					
					<div class="form-entry">
						<div class="form-entry-label form-entry-label-normalfont"><label><?php echo $this->_tpl_vars['formData']['femoticon']; ?>
</label></div>
						<div class="form-entry-radio">
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonHappy']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'happy'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="happy" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/happy.png" alt="happy" /></label> &nbsp; &nbsp; &nbsp;
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonLove']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'love'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="love" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/love.png" alt="love" /></label> &nbsp; &nbsp; &nbsp;
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonNormal']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'normal'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="normal" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/normal.png" alt="normal" /></label> &nbsp; &nbsp; &nbsp;
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonAngry']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'angry'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="angry" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/angry.png" alt="angry" /></label> &nbsp; &nbsp; &nbsp;
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonSad']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'sad'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="sad" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/sad.png" alt="sad" /></label> &nbsp; &nbsp; &nbsp;
							<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryEmoticonCry']; ?>
"><input class="entry-radio" <?php if ($this->_tpl_vars['formData']['femoticon'] == 'cry'): ?>checked="checked"<?php endif; ?> type="radio" name="femoticon" value="cry" /><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/cry.png" alt="cry" /></label>
							
						</div>
					</div>
			
					<div class="form-entry">
						<div class="form-entry-label form-entry-label-normalfont"><label><?php echo $this->_tpl_vars['lang']['controller']['content']; ?>
 :</label></div>
						<div class="form-entry-textbox">
							<textarea name="fcontent" class="entry-textarea" rows="15" style="width:400px;"><?php echo $this->_tpl_vars['formData']['fcontent']; ?>
</textarea>
							
							<div style="margin-left:210px;line-height:1.5;">
								<a href="javascript:void(0);" onclick="$('.form-bbcodehelp').toggle();$('.form-bbcode-toggler').toggle();" style="text-decoration:none; color:#FF1D5A;">&raquo;<span class="form-bbcode-toggler" style="display:none;"><?php echo $this->_tpl_vars['lang']['controller']['bbcodeHelpToggleHide']; ?>
 </span><?php echo $this->_tpl_vars['lang']['controller']['bbcodeHelpToggle']; ?>
</a>
								<div class="form-bbcodehelp" style="display:none;font-size:11px; font-family:'Courier New', Courier, monospace">
									<?php echo $this->_tpl_vars['lang']['global']['diaryBBcode']; ?>

								</div>
							</div>	
						</div>
					</div>
					
					<div class="form-entry">
						<div class="form-entry-label"></div>
						<div>
						<label title="<?php echo $this->_tpl_vars['lang']['global']['diaryPrivateTip']; ?>
"><input style="width:30px;" type="checkbox" <?php if ($this->_tpl_vars['formData']['fprivate'] == 1): ?>checked="checked"<?php endif; ?> name="fprivate" value="1" /><?php echo $this->_tpl_vars['lang']['global']['diaryPrivate']; ?>
</label></div>
					</div>
					
					
					<div class="form-entry">
						<div class="form-entry-label">&nbsp;</div>
						<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controller']['submitLabel']; ?>
" /></div>
					</div>
					<div class="clearboth"></div>
					
				</form>
			</div><!-- end of .mainform-form-register -->
	</div>
	
</div><!-- end of #content -->
