<?php /* Smarty version 2.6.26, created on 2010-07-12 13:39:35
         compiled from _controller/admin/diary/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'nl2br', '_controller/admin/diary/edit.tpl', 42, false),array('modifier', 'date_format', '_controller/admin/diary/edit.tpl', 60, false),)), $this); ?>
<h2><?php echo $this->_tpl_vars['lang']['controller']['head_edit']; ?>
</h2>


<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3><?php echo $this->_tpl_vars['lang']['controller']['title_edit']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" id="tab1_link" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['formFormLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['backUrl']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['formBackLabel']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."notification.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'],'notifyWarning' => $this->_tpl_vars['warning'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		<div class="tab-content default-tab" id="tab1">
			<form action="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
diary/edit/id/<?php echo $this->_tpl_vars['myEntry']->id; ?>
/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
" method="post" name="myform">
			<input type="hidden" name="ftoken" value="<?php echo $_SESSION['diaryEditToken']; ?>
" />
			<table class="form" cellpadding="5" cellspacing="5">
				<tr>
					<td width="150" class="label" valign="middle"></td>
					<td><img title="<?php echo $this->_tpl_vars['myEntry']->emoticon; ?>
" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/emoticon/32/<?php echo $this->_tpl_vars['myEntry']->emoticon; ?>
.png" alt="<?php echo $this->_tpl_vars['myEntry']->emoticon; ?>
" /></td>
				</tr>
				<tr>
					<td width="150" class="label" valign="middle">ID:</td>
					<td><?php echo $this->_tpl_vars['myEntry']->id; ?>
</td>
				</tr>
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formTypeLabel']; ?>
 : </td>
					<td><?php echo $this->_tpl_vars['myEntry']->getTypeName(); ?>
</td>
				</tr>	
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
 : </td>
					<td><a style="font-weight:bold;" target="_blank" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->user->username; ?>
"><?php echo $this->_tpl_vars['myEntry']->user->username; ?>
</a></td>
				</tr>	
					
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formContentLabel']; ?>
 : </td>
					<td style="font-size:14px; font-style:italic;">
						<a target="_blank" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['diary']['seoUrl']; ?>
/index/user/<?php echo $this->_tpl_vars['myEntry']->user->username; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/quote_icon.png" alt="quote" border="0" /></a><?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
<a target="_blank" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['diary']['seoUrl']; ?>
/index/user/<?php echo $this->_tpl_vars['myEntry']->user->username; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/quote_icon.png" alt="quote" border="0" /></a>
						
					</td>
				</tr>				
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formModeLabel']; ?>
 : </td>
					<td><?php echo $this->_tpl_vars['myEntry']->mode; ?>
</td>
				</tr>	
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formEnableLabel']; ?>
 : </td>
					<td><select name="fenable" id="fenable">
						<option value="1" <?php if ($this->_tpl_vars['formData']['fenable'] == '1'): ?>selected="selected"<?php endif; ?>>Enabled</option>
						<option value="0" <?php if ($this->_tpl_vars['formData']['fenable'] == '0'): ?>selected="selected"<?php endif; ?>>Disabled</option>
					</select></td>
				</tr>
				
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formDateActionLabel']; ?>
 :</td>
					<td><?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->dateaction)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty'])); ?>
</td>
				</tr>
				
				<tr>
					<td class="label" valign="middle"><?php echo $this->_tpl_vars['lang']['controller']['formDateCreatedLabel']; ?>
 :</td>
					<td><?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty']) : smarty_modifier_date_format($_tmp, $this->_tpl_vars['lang']['controllergroup']['dateFormatTimeSmarty'])); ?>
 (<?php echo $this->_tpl_vars['lang']['controller']['formIpAddressLabel']; ?>
 : <?php echo $this->_tpl_vars['myEntry']->ipaddress; ?>
)</td>
				</tr>
				
			</table>
			<fieldset>
			<p>
				<input type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['formUpdateSubmit']; ?>
" class="button buttonbig">
			</p>
			</fieldset>
			
			</form>
		</div>
		
		
	</div>
	
	
</div>
