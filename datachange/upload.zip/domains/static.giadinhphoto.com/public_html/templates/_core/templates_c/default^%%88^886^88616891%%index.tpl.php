<?php /* Smarty version 2.6.26, created on 2013-10-28 22:28:01
         compiled from _controller/site/memberarea/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/memberarea/index.tpl', 213, false),array('modifier', 'truncate', '_controller/site/memberarea/index.tpl', 219, false),array('modifier', 'date_format', '_controller/site/memberarea/index.tpl', 220, false),)), $this); ?>
<script src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/js/tabcontent.js" type="text/javascript"></script>
<link href="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/css/tabcontent.css" rel="stylesheet" type="text/css" />
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
		<!-- code html o day -->
		
		<div style="padding:20px 0px 20px 0px">
        <ul class="tabs" data-persist="true">
            <li><a <?php if ($this->_tpl_vars['tab'] == 'info'): ?>class="selected"<?php endif; ?> href="#tabinfo"><?php echo $this->_tpl_vars['lang']['controller']['tabInfo']; ?>
</a></li>
            <li><a <?php if ($this->_tpl_vars['tab'] == 'upload'): ?>class="selected"<?php endif; ?> href="#tabupload"><?php echo $this->_tpl_vars['lang']['controller']['tabWork']; ?>
</a></a></li>
            <li><a <?php if ($this->_tpl_vars['tab'] == 'payment'): ?>class="selected"<?php endif; ?> href="#tabpayment"><?php echo $this->_tpl_vars['lang']['controller']['tabPayment']; ?>
</a></li>
        </ul>
        <div class="tabcontents">
            <div id="tabinfo">
				<strong><?php echo $this->_tpl_vars['lang']['controller']['personalDetail']; ?>
</strong>
				<table width="630" border="0" cellspacing="0" cellpadding="0">
					<tbody>
						<!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['global']['fullname']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input disabled="disabled" type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->fullname; ?>
"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  <!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['email']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->email; ?>
" disabled="disabled"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  <!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['address']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->address; ?>
" disabled="disabled"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  
						  <!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['country']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->getCountryName(); ?>
" disabled="disabled"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  
						  <!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['city']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->city; ?>
" disabled="disabled"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  
						  <!-- row -->
						  <tr>
							<td><span class="content_txt_12"><?php echo $this->_tpl_vars['lang']['controller']['phone1']; ?>
</span></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="8"></td>
							<td></td>
						  </tr>
						  <tr>
							<td><input type="text" style="width:280px;" maxlength="20" value="<?php echo $this->_tpl_vars['me']->phone1; ?>
" disabled="disabled"></td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td colspan="2" class="footer_btn"><em class="content_txt_10">&nbsp;</em></td>
							<td height="20">&nbsp;</td>
						  </tr>
						  <!-- end row -->
						  
					</tbody>
				</table>
			   
       		 </div><!-- end #tabinfo -->
            
			<div id="tabupload">
            <strong><?php echo $this->_tpl_vars['lang']['controller']['photoSubmit']; ?>
</strong>
            <p class="text"><?php echo $this->_tpl_vars['lang']['controller']['photoSubmitHelp']; ?>
</p>
            
            <form method="post" action="<?php if ($this->_tpl_vars['formData']['fremoteupload'] != ''): ?><?php echo $this->_tpl_vars['formData']['fremoteactionurl']; ?>
<?php else: ?><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=upload<?php endif; ?>" enctype="multipart/form-data">
            
            <?php if ($this->_tpl_vars['formData']['fremoteupload'] != ''): ?>
                <input type="hidden" name="uid" value="<?php echo $this->_tpl_vars['formData']['fremoteuid']; ?>
" />
                <input type="hidden" name="sid" value="<?php echo $this->_tpl_vars['formData']['fremotesessionid']; ?>
" />
                <input type="hidden" name="token" value="<?php echo $this->_tpl_vars['formData']['fremotetoken']; ?>
" />
            <?php else: ?>
                <input type="hidden" name="ftoken" value="<?php echo $_SESSION['addPhotoToken']; ?>
" />
            <?php endif; ?>
            <p class="computer"><?php echo $this->_tpl_vars['lang']['controller']['photoSubmitHelp2']; ?>
</p>
            <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
            <div>
                <table>
                    <tr>
                        <td align="right" width="150" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['section']; ?>
:</td>
                        <td style="padding:5px;"><select name="fsection" style="padding:3px;">
                                <option value=""><?php echo $this->_tpl_vars['lang']['global']['photoSectionSelectOne']; ?>
</option>
                                <option value="envir" <?php if ($this->_tpl_vars['formData']['fsection'] == 'envir'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionEnvir']; ?>
</option>
                                <option value="land" <?php if ($this->_tpl_vars['formData']['fsection'] == 'land'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionLand']; ?>
</option>
                                <option value="wild" <?php if ($this->_tpl_vars['formData']['fsection'] == 'wild'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionWild']; ?>
</option>
                                <option value="flo" <?php if ($this->_tpl_vars['formData']['fsection'] == 'flo'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionFlo']; ?>
</option>
								<option value="in" <?php if ($this->_tpl_vars['formData']['fsection'] == 'in'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['photoSectionIn']; ?>
</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td align="right" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['photoupload']; ?>
:</td>
                        <td style="padding:5px;"><input type="file" name="fimage" size="40" />
                        </td>
                    </tr>
                    <tr>
                        <td align="right" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['photoname']; ?>
:</td>
                        <td style="padding:5px;"><input type="text" name="fname" value="<?php echo $this->_tpl_vars['formData']['fname']; ?>
" size="40" />
                        </td>
                    </tr>
                    
                    
                    <tr>
                        <td align="right" style="padding:5px;"><?php echo $this->_tpl_vars['lang']['controller']['photodescription']; ?>
:</td>
                        <td style="padding:5px;"><input type="text" name="fdescription" value="<?php echo $this->_tpl_vars['formData']['fdescription']; ?>
" size="40" />
                        </td>
                    </tr>
                    <tr>
                        <td align="right" style="padding:5px;"></td>
                        <td style="padding:5px;"><input type="submit" class="btnSubmit" name="fsubmitphoto" value="<?php echo $this->_tpl_vars['lang']['controller']['photoSubmitBtn']; ?>
" />
                        </td>
                    </tr>
					
                </table>
                
            </div>           
            
			<table width="100%">
				<tr>
					<td height="45" background="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/showmore_bg.gif">&nbsp</td>

				</tr>
			</table>
            
            </form>
			<strong><?php echo $this->_tpl_vars['lang']['controller']['myphoto']; ?>
</strong>
			<!-- anh cua toi -->
			<table width="100%" class="myphoto">
				<tr>
					<td width="160"><strong><?php echo $this->_tpl_vars['lang']['global']['photoSectionEnvir']; ?>
(<?php echo count($this->_tpl_vars['myPhotoList']['envi']); ?>
)</strong></td>
					<td>
					<ul>
					<?php $_from = $this->_tpl_vars['myPhotoList']['envi']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<li>
						<p><a target="" href="#" title="[<?php echo $this->_tpl_vars['photo']->getSection(); ?>
] <?php echo $this->_tpl_vars['photo']->name; ?>
"><img alt="<?php echo $this->_tpl_vars['photo']->name; ?>
" src="<?php echo $this->_tpl_vars['photo']->getImage('thumb2'); ?>
" width="160"></a></p>
						<p class="name"><a target="" href="#" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->name)) ? $this->_run_mod_handler('truncate', true, $_tmp, 32) : smarty_modifier_truncate($_tmp, 32)); ?>
</a></p>
						<p class="date"><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</p>
						<p class="action"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photoedit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> &nbsp;| &nbsp;<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photodelete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
');"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a> &nbsp;|&nbsp; <a href="<?php echo $this->_tpl_vars['photo']->getPhotoPath(); ?>
#comment"><?php echo $this->_tpl_vars['photo']->comment; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['comment']; ?>
</a></p>
						</li>
					<?php endforeach; endif; unset($_from); ?>
					</ul>
					</td>
				</tr>
				
				<tr>
					<td><strong><?php echo $this->_tpl_vars['lang']['global']['photoSectionLand']; ?>
(<?php echo count($this->_tpl_vars['myPhotoList']['land']); ?>
)</strong></td>
					<td>
						<ul>
					<?php $_from = $this->_tpl_vars['myPhotoList']['land']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<li>
						<p><a target="" href="#" title="[<?php echo $this->_tpl_vars['photo']->getSection(); ?>
] <?php echo $this->_tpl_vars['photo']->name; ?>
"><img alt="<?php echo $this->_tpl_vars['photo']->name; ?>
" src="<?php echo $this->_tpl_vars['photo']->getImage('thumb2'); ?>
" width="160"></a></p>
						<p class="name"><a target="" href="#" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->name)) ? $this->_run_mod_handler('truncate', true, $_tmp, 32) : smarty_modifier_truncate($_tmp, 32)); ?>
</a></p>
						<p class="date"><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</p>
						<p class="action"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photoedit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> &nbsp;| &nbsp;<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photodelete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
');"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a> &nbsp;|&nbsp; <a href="<?php echo $this->_tpl_vars['photo']->getPhotoPath(); ?>
#comment"><?php echo $this->_tpl_vars['photo']->comment; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['comment']; ?>
</a></p>
						</li>
					<?php endforeach; endif; unset($_from); ?>
					</ul>
					</td>
				</tr>
				
				<tr>
					<td><strong><?php echo $this->_tpl_vars['lang']['global']['photoSectionWild']; ?>
(<?php echo count($this->_tpl_vars['myPhotoList']['wild']); ?>
)</strong></td>
					<td>
						<ul>
					<?php $_from = $this->_tpl_vars['myPhotoList']['wild']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<li>
						<p><a target="" href="#" title="[<?php echo $this->_tpl_vars['photo']->getSection(); ?>
] <?php echo $this->_tpl_vars['photo']->name; ?>
"><img alt="<?php echo $this->_tpl_vars['photo']->name; ?>
" src="<?php echo $this->_tpl_vars['photo']->getImage('thumb2'); ?>
" width="160"></a></p>
						<p class="name"><a target="" href="#" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->name)) ? $this->_run_mod_handler('truncate', true, $_tmp, 32) : smarty_modifier_truncate($_tmp, 32)); ?>
</a></p>
						<p class="date"><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</p>
						<p class="action"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photoedit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> &nbsp;| &nbsp;<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photodelete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
');"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a> &nbsp;|&nbsp; <a href="<?php echo $this->_tpl_vars['photo']->getPhotoPath(); ?>
#comment"><?php echo $this->_tpl_vars['photo']->comment; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['comment']; ?>
</a></p>
						</li>
					<?php endforeach; endif; unset($_from); ?>
					</ul>
					</td>
				</tr>
				
				<tr>
					<td><strong><?php echo $this->_tpl_vars['lang']['global']['photoSectionFlo']; ?>
(<?php echo count($this->_tpl_vars['myPhotoList']['flo']); ?>
)</strong></td>
					<td>
						<ul>
					<?php $_from = $this->_tpl_vars['myPhotoList']['flo']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<li>
						<p><a target="" href="#" title="[<?php echo $this->_tpl_vars['photo']->getSection(); ?>
] <?php echo $this->_tpl_vars['photo']->name; ?>
"><img alt="<?php echo $this->_tpl_vars['photo']->name; ?>
" src="<?php echo $this->_tpl_vars['photo']->getImage('thumb2'); ?>
" width="160"></a></p>
						<p class="name"><a target="" href="#" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->name)) ? $this->_run_mod_handler('truncate', true, $_tmp, 32) : smarty_modifier_truncate($_tmp, 32)); ?>
</a></p>
						<p class="date"><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</p>
						<p class="action"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photoedit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> &nbsp;| &nbsp;<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photodelete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
');"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a> &nbsp;|&nbsp; <a href="<?php echo $this->_tpl_vars['photo']->getPhotoPath(); ?>
#comment"><?php echo $this->_tpl_vars['photo']->comment; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['comment']; ?>
</a></p>
						</li>
					<?php endforeach; endif; unset($_from); ?>
					</ul>
					</td>
				</tr>
				
				<tr>
					<td><strong><?php echo $this->_tpl_vars['lang']['global']['photoSectionIn']; ?>
(<?php echo count($this->_tpl_vars['myPhotoList']['in']); ?>
)</strong></td>
					<td>
						<ul>
					<?php $_from = $this->_tpl_vars['myPhotoList']['in']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
						<li>
						<p><a target="" href="#" title="[<?php echo $this->_tpl_vars['photo']->getSection(); ?>
] <?php echo $this->_tpl_vars['photo']->name; ?>
"><img alt="<?php echo $this->_tpl_vars['photo']->name; ?>
" src="<?php echo $this->_tpl_vars['photo']->getImage('thumb2'); ?>
" width="160"></a></p>
						<p class="name"><a target="" href="#" title="<?php echo $this->_tpl_vars['photo']->name; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->name)) ? $this->_run_mod_handler('truncate', true, $_tmp, 32) : smarty_modifier_truncate($_tmp, 32)); ?>
</a></p>
						<p class="date"><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['photo']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d/%m/%Y") : smarty_modifier_date_format($_tmp, "%d/%m/%Y")); ?>
</p>
						<p class="action"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photoedit/id/<?php echo $this->_tpl_vars['photo']->id; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['editLabel']; ?>
</a> &nbsp;| &nbsp;<a href="javascript:delm('<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/memberarea/photodelete/id/<?php echo $this->_tpl_vars['photo']->id; ?>
');"><?php echo $this->_tpl_vars['lang']['controller']['deleteLabel']; ?>
</a> &nbsp;|&nbsp; <a href="<?php echo $this->_tpl_vars['photo']->getPhotoPath(); ?>
#comment"><?php echo $this->_tpl_vars['photo']->comment; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['comment']; ?>
</a></p>
						</li>
					<?php endforeach; endif; unset($_from); ?>
					</ul>
					</td>
				</tr>
			
			</table>
			        
        </div><!-- end #tabupload -->
        
			
		<div id="tabpayment">  
		
		<?php if ($this->_tpl_vars['me']->paidEnvir == 0): ?>
			<br />
                <div class="infoEmpty"><?php echo $this->_tpl_vars['lang']['controller']['paymentEmpty']; ?>
</div>
				<div style="padding:10px 0 10px 0;">
                <form name="currencyForm" method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=payment">
                        <?php echo $this->_tpl_vars['lang']['controller']['currency']; ?>
: 
						<select style="border: 1px solid rgb(221, 221, 221); font-size: 12px; padding:0; width:100px" onchange="javascript:document.currencyForm.submit();" name="fcurrency">
							<option value="usd" <?php if ($this->_tpl_vars['currency']->currencyCode == 'usd'): ?>selected="selected"<?php endif; ?>>USD</option>
							<option value="vnd" <?php if ($this->_tpl_vars['currency']->currencyCode == 'vnd'): ?>selected="selected"<?php endif; ?>>VND</option>
							<option value="eur" <?php if ($this->_tpl_vars['currency']->currencyCode == 'eur'): ?>selected="selected"<?php endif; ?>>EUR</option>
						</select>
                </form>
            </div>
            <?php endif; ?>              
                
        <form action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=payment" method="post">
            
            
            <?php if ($this->_tpl_vars['me']->paidEnvir == 1): ?>
			<br />
				<br />
				<br />
				<br />
                <br />
                <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyInformation' => $this->_tpl_vars['lang']['controller']['paymentFullAlready'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<br />
				<br />
				<br />
				<br />
				<br />
								<br />
												<br />
																<br />
																				<br />
            <?php else: ?>
              
                <div class="paymentOptionCart" style="padding:20px 0px 0px 0px">
                    <input type="image" name="fsubmitsection" value="<?php echo $this->_tpl_vars['lang']['controller']['paymentSectionCart']; ?>
" src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['lang']['controller']['paymentButton']; ?>
"/>
					<br />
					<br />

                </div>
                <div class="paymentMethod">
                    <strong><?php echo $this->_tpl_vars['myPaymentPage']->title[$this->_tpl_vars['langCode']]; ?>
</strong>
                    <div><?php echo $this->_tpl_vars['myPaymentPage']->contents[$this->_tpl_vars['langCode']]; ?>
</div>
                </div>
            <?php endif; ?>
            
        </form>
        
        </div>

<!-- end #tabpayment -->

        </div>
    </div>
		
		
		
		<!-- ---->
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->