<?php /* Smarty version 2.6.26, created on 2010-07-16 13:34:21
         compiled from _controller/site/entrymoderatorform.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', '_controller/site/entrymoderatorform.tpl', 11, false),)), $this); ?>
			<?php if (in_array ( $this->_tpl_vars['me']->groupid , $this->_tpl_vars['setting']['entry']['moderatorGroupId'] ) || $this->_tpl_vars['myEntry']->id > 0): ?>
				<?php if (in_array ( $this->_tpl_vars['me']->groupid , $this->_tpl_vars['setting']['entry']['moderatorGroupId'] ) || $this->_tpl_vars['myEntry']->canModerate()): ?>
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"></div>
					<div class="form-entry-textbox"><hr size="1" /><strong>Moderator:</strong></div>
				</div>
					
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryPostBy']; ?>
 :</label></div>
					<div class="form-entry-input">
						<div class="form-entry-text"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myEntry']->username; ?>
" title="<?php echo $this->_tpl_vars['myEntry']->username; ?>
"><?php echo $this->_tpl_vars['myEntry']->username; ?>
</a> &lt; <?php echo $this->_tpl_vars['lang']['controllergroup']['entryPostAt']; ?>
 : <?php echo ((is_array($_tmp=$this->_tpl_vars['myEntry']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M - %A, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M - %A, %B %e, %Y")); ?>
 &gt;<br /><br /></div>
					</div>
				</div>
					
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedLabel']; ?>
 :</label></div>
					<div class="form-entry-input">
						<div class="form-entry-checkbox"><input type="hidden" name="fismoderated" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedTooltip']; ?>
" type="checkbox" name="fismoderated" value="1"<?php if ($this->_tpl_vars['formData']['fismoderated'] == '1' || ( $this->_tpl_vars['action'] == 'add' && $this->_tpl_vars['formData']['fsubmit'] == '' )): ?> checked="checked"<?php endif; ?> /></div>
					</div>
				</div>
				
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextLabel']; ?>
 :</label></div>
					<div class="form-entry-input">
						<div class="form-entry-checkbox"><input type="hidden" name="fignorecleanbadword" value="0" /><input title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNotCleanTextTooltip']; ?>
" type="checkbox" name="fignorecleanbadword" value="1"<?php if ($this->_tpl_vars['formData']['fignorecleanbadword'] == '1' || ( $this->_tpl_vars['action'] == 'add' && $this->_tpl_vars['formData']['fsubmit'] == '' )): ?> checked="checked"<?php endif; ?> /></div>
					</div>
				</div>
				<?php else: ?>
					<?php if ($this->_tpl_vars['formData']['fismoderated'] == 0): ?>
					<div class="form-entry" >
						<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
						<div class="form-entry-input">
							<span class="required"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryModeratedNoLabel']; ?>
</span><br /><br />
						</div>
					</div>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>