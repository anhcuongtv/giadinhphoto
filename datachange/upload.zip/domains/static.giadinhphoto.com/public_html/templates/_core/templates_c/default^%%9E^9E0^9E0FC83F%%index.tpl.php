<?php /* Smarty version 2.6.26, created on 2013-10-27 18:33:15
         compiled from _controller/site/statuslist/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'math', '_controller/site/statuslist/index.tpl', 48, false),array('function', 'paginate', '_controller/site/statuslist/index.tpl', 61, false),array('modifier', 'date_format', '_controller/site/statuslist/index.tpl', 52, false),)), $this); ?>
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
<div id="page">
		
<table width="580" border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
	<td height="8"></td>
	</tr>  
	<tr>
	<td height="40" align="left" style="border-bottom:2px solid #67b718; text-transform:uppercase"><strong style="font-size:21px"><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
 (<?php echo $this->_tpl_vars['total']; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['userLabel']; ?>
)</strong></td>
	</tr>
	
	<tr>
	<td height="8"></td>
</tr>  
</tbody></table>

<div style="text-align:left;font-size:14px;padding:0 100px 20px 0px">
            <img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="Yes" /><?php echo $this->_tpl_vars['lang']['controller']['isPaid']; ?>
 &nbsp;     
            <img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="No" /> <?php echo $this->_tpl_vars['lang']['controller']['isNotPaid']; ?>

			
        </div>
        
        <table border="1" id="statuslisttable" bordercolor="#CCCCCC" style="border-collapse:collapse;">

            <tr>
                <th width="30" style="text-align: center !important;">#</th>
                <th width="250px"><?php echo $this->_tpl_vars['lang']['controller']['fullname']; ?>
</th>
                <th width="150"><?php echo $this->_tpl_vars['lang']['controller']['region']; ?>
</th>
                <th width="100"><?php echo $this->_tpl_vars['lang']['controller']['country']; ?>
</th>
                <th><?php echo $this->_tpl_vars['lang']['controller']['datecreated']; ?>
</th>
                <th style="text-align: center !important;"><?php echo $this->_tpl_vars['lang']['controller']['isPaid']; ?>
</th>
                
            </tr>
            <?php $_from = $this->_tpl_vars['userList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['userlist'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['userlist']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['user']):
        $this->_foreach['userlist']['iteration']++;
?>
                <tr>
                    <td align="center"><?php echo smarty_function_math(array('equation' => "a+b",'a' => $this->_tpl_vars['orderStartCount'],'b' => $this->_foreach['userlist']['iteration']), $this);?>
</td>
                    <td><?php echo $this->_tpl_vars['user']->fullname; ?>
</td>
                    <td><?php echo $this->_tpl_vars['user']->city; ?>
</td>
                    <td><?php $this->assign('country', $this->_tpl_vars['user']->country); ?><?php echo $this->_tpl_vars['setting']['country'][$this->_tpl_vars['country']]; ?>
 </td>
                    <td><?php echo ((is_array($_tmp=$this->_tpl_vars['user']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp) : smarty_modifier_date_format($_tmp)); ?>
</td>
                    <td align="center" class="center"><?php if ($this->_tpl_vars['user']->paidOpen == 1): ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="Yes" /><?php else: ?><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="No" /><?php endif; ?></td>

                </tr>
            <?php endforeach; endif; unset($_from); ?>

        </table>
        
        <?php $this->assign('pageurl', "page/::PAGE::"); ?>
            <?php echo smarty_function_paginate(array('count' => $this->_tpl_vars['totalPage'],'curr' => $this->_tpl_vars['curPage'],'lang' => $this->_tpl_vars['paginateLang'],'max' => 10,'url' => ($this->_tpl_vars['paginateurl']).($this->_tpl_vars['pageurl'])), $this);?>

        
        
    
    </div>

					
                   
				</div>        	
        </div><!-- content -->
</div>

<?php echo '
<style type="text/css">
#statuslisttable{border-color:#CCC; width:100%;}
#statuslisttable tr{}
#statuslisttable th,#statuslisttable td{border: 1px solid #CCCCCC;padding:4px;}
#statuslisttable th{font-weight:bold;}
#statuslisttable td{}
#statuslisttable td.center{text-align:center}
</style>
'; ?>