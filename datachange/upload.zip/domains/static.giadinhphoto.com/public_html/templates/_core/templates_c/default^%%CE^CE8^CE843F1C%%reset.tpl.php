<?php /* Smarty version 2.6.26, created on 2013-10-30 16:44:23
         compiled from _controller/site/forgotpass/reset.tpl */ ?>
<div id="pagebody">
    	<h1 id="title">
		<?php if ($_SESSION['language'] == 'vn'): ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		<?php else: ?>
		<img src="<?php echo $this->_tpl_vars['staticserver']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/title-en.png" alt="Cuộc Thi Ảnh Quốc Tế Môi trường xanh 2013" />
		
		<?php endif; ?>
		
		</h1>
        <div id="content">
		
		<!-- code html o day -->
		
		<div id="page">
        <h1><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</h1>
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    
        <form action="" method="post">
            
            <div class="form-entry" >
                <div class="form-entry-label"><label><?php echo $this->_tpl_vars['lang']['controller']['password']; ?>
 :</label></div>
                <div class="form-entry-big-textbox"><input type="password" name="fpassword" value="" /></div>
            </div>
            <div class="form-entry" >
                <div class="form-entry-label"><label><?php echo $this->_tpl_vars['lang']['controller']['password2']; ?>
 :</label></div>
                <div class="form-entry-big-textbox"><input type="password" name="fpassword2" value="" /></div>
            </div>
            
                
                
            <div class="form-entry">
                <div class="form-entry-label">&nbsp;</div>
                <div class="form-entry-submit"><input class="btnSubmit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controller']['submitLabel']; ?>
" />
                <span class="form-entry-login-register"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
login.html<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>?redirect=<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['global']['mLogin']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLogin']; ?>
</a></span>
                </div>
                
        
            </div>
            <div class="clearboth"></div>
            
        </form>
    </div>
		
		
		
		<!-- ---->
        	
            
        	<!-- layout -->
        </div><!-- content -->
    </div><!-- pagebody -->
    
</div><!-- wrapper -->