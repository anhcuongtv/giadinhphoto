<?php /* Smarty version 2.6.26, created on 2013-10-22 17:19:20
         compiled from _controller/admin/footer.tpl */ ?>
			<div id="footer">
				<small> <!-- Remove this notice or replace it with whatever you want -->
						&#169; Copyright 2011 iMSVietnam.com | <a href="#">Top</a>
				</small>
			</div><!-- End #footer -->
			
		</div> <!-- End #main-content -->
		
	</div>
	
	</body>
  

</html>