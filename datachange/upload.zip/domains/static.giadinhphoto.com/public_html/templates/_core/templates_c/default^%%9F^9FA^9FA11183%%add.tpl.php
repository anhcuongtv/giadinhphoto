<?php /* Smarty version 2.6.26, created on 2010-07-03 20:45:22
         compiled from _controller/site/entryphotoalbum/add.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrysidebar.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div id="content-wide">
	<div id="heading"><h1><?php echo $this->_tpl_vars['lang']['controller']['headingPrefixAdd']; ?>
 <?php if ($this->_tpl_vars['formData']['parentCategory']->id > 0): ?><em>"<?php echo $this->_tpl_vars['formData']['myCategory']->name; ?>
"</em><?php endif; ?></h1></div>
	<div id="page-content">
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		
		<div id="mainform-form">
			<form action="" method="post" enctype="multipart/form-data">
				<input type="hidden" name="ftoken" value="<?php echo $_SESSION['entryAddToken']; ?>
" />
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['titleLabel']; ?>
 :</label></div>
					<div class="form-entry-big-textbox"><input class="entry-textbox-long" type="text" id="ftitle" name="ftitle" value="<?php echo $this->_tpl_vars['formData']['ftitle']; ?>
" /></div>
				</div>
				

				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCategory']; ?>
 :</label></div>
					<div>
						<select class="entry-selectbox" id="fcategoryidentifier" name="fcategoryidentifier">
							<option value="---">- - - - - - - - - -</option>
							<option value="hinh-ky-niem" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'hinh-ky-niem'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mPhotoCelebration']; ?>
</option>
							<option value="hinh-cuoi" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'hinh-cuoi'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mPhotoWedding']; ?>
</option>
							<option value="hinh-du-lich" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'hinh-du-lich'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mPhotoTravel']; ?>
</option>
							<option value="hinh-em-be" <?php if ($this->_tpl_vars['formData']['fcategoryidentifier'] == 'hinh-em-be'): ?>selected="selected"<?php endif; ?>><?php echo $this->_tpl_vars['lang']['global']['mPhotoBaby']; ?>
</option>
						</select>
					</div>
				</div>

				
				
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryImage']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input type="file" id="fimage" name="fimage" /></div>
				</div>
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryslideshowform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				<div class="form-entry" >
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controller']['descriptionLabel']; ?>
 :</label></div>
					<div class="form-entry-input">
						<textarea name="fdescription" class="entry-textarea disablefocusfx wysiwyg" rows="10"><?php echo $this->_tpl_vars['formData']['fdescription']; ?>
</textarea><br />
					</div>
				</div>
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryTag']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryTagTooltip']; ?>
" value="<?php echo $this->_tpl_vars['formData']['ftag']; ?>
" type="text" id="ftag" name="ftag" /></div>
				</div>
				
				
				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelated']; ?>
 :</label></div>
					<div class="form-entry-textbox"><input class="myTip" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRelatedTooltip']; ?>
 <?php echo $this->_tpl_vars['setting']['entry']['maxRelatedNumber']; ?>
)" type="text" id="frelated" name="frelated" value="<?php echo $this->_tpl_vars['formData']['frelated']; ?>
" /></div>
				</div>
				
				
				
				
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entryseoform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."entrymoderatorform.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				
				
				
				
				
				
				

				<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small">&nbsp;</div>
					<div class="form-entry-submit"><input class="form-button-submit" type="submit" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryAddBtn']; ?>
" />
				</div>
				</div>
				<div class="clearboth"></div>
				
			</form>
		</div><!-- end of .mainform-form -->
	</div><!-- end of #page-content -->
	
</div><!-- end of #content -->


