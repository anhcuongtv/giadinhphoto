<?php /* Smarty version 2.6.26, created on 2010-07-15 21:13:33
         compiled from _controller/site/entryratingbar.tpl */ ?>
<?php if ($this->_tpl_vars['me']->id > 0): ?>
<div class="ratingbar" rel="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingSuccess']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
: 
	<div class="ratingcontainer">
		<select id="userrating" class="userrating">
			<option value="1"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingOp1']; ?>
</option>
			<option value="2"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingOp2']; ?>
</option>
			<option value="3" selected="selected"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingOp3']; ?>
</option>
			<option value="4"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingOp4']; ?>
</option>
			<option value="5"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingOp5']; ?>
</option>

		</select>
		<input type="button" onclick="entryRating('<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/rate', $('#userrating').val(), '<?php echo $_SESSION['securityToken']; ?>
')" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingBtn']; ?>
" />
	</div>
	<div class="indicator"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/progress.gif" alt="loading..." /> <?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingLoading']; ?>
</div>
	<div class="indicatorsuccess"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick.png" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingSuccess']; ?>
" /> <?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingSuccess']; ?>
</div>
</div>
<?php endif; ?>