<?php /* Smarty version 2.6.26, created on 2013-10-21 16:43:38
         compiled from _controller/site/maincontent.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'sslashes', '_controller/site/maincontent.tpl', 1, false),array('modifier', 'default', '_controller/site/maincontent.tpl', 1, false),)), $this); ?>
<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['contents'])) ? $this->_run_mod_handler('sslashes', true, $_tmp) : smarty_modifier_sslashes($_tmp)))) ? $this->_run_mod_handler('default', true, $_tmp, "") : smarty_modifier_default($_tmp, "")); ?>
	