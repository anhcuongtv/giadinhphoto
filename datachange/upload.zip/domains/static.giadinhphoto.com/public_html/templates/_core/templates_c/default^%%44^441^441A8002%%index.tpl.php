<?php /* Smarty version 2.6.26, created on 2010-09-05 11:59:56
         compiled from _controller/site/checkout/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', '_controller/site/checkout/index.tpl', 87, false),)), $this); ?>


<div id="pageBody">
<div id="primary">
<dl class="information">
<dt><?php echo $this->_tpl_vars['lang']['controller']['title']; ?>
</dt>
<dd></dd>
</dl>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div id="paymentContent">
	
	
	<?php if ($this->_tpl_vars['paymentSuccess'] == 1): ?>
		<div class="paymentSuccess">
			<?php if ($this->_tpl_vars['paymentGate'] == 'paypal' || $this->_tpl_vars['paymentGate'] == 'expresscheckout'): ?>
				<?php echo $this->_tpl_vars['lang']['controller']['succPaymentOnline']; ?>

			<?php else: ?>
				<?php echo $this->_tpl_vars['lang']['controller']['succPaymentOffline']; ?>

			<?php endif; ?>
		</div>
		
		<div>Quick Link: <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html" title="Member Area">Member Area</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=upload" title="Upload Photo">Upload Photo</a></div>
	<?php else: ?>
	
		<div class="infoSelectPayment"><?php echo $this->_tpl_vars['lang']['controller']['paymentYourSelect']; ?>
</div>
		<div class="paymentOptionList">
			<?php if ($this->_tpl_vars['packId'] == 1 || $this->_tpl_vars['packId'] == 3 || $this->_tpl_vars['packId'] == 5 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionColor']; ?>
 <br />
			
			<?php if ($this->_tpl_vars['packId'] == 2 || $this->_tpl_vars['packId'] == 3 || $this->_tpl_vars['packId'] == 6 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionMono']; ?>
 <br />
			
			<?php if ($this->_tpl_vars['packId'] == 4 || $this->_tpl_vars['packId'] == 5 || $this->_tpl_vars['packId'] == 6 || $this->_tpl_vars['packId'] == 7): ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/tick_circle.png" alt="YES" /><?php else: ?><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/cross_circle.png" alt="YES" /><?php endif; ?> <?php echo $this->_tpl_vars['lang']['global']['photoSectionNature']; ?>
 <br />
		</div>
		
		<div><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
memberarea.html?tab=payment" title="Back">Change</a></div>
		
		<div class="paymentOptionTotal">
			<?php echo $this->_tpl_vars['lang']['controller']['paymentTotal']; ?>
 : <span id="paymentOptionPrice"><?php echo $this->_tpl_vars['currency']->formatPrice($this->_tpl_vars['myProduct']->price); ?>
</span>
		</div>
		
		<div class="paymentMethodSelect">
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectPaypal">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectPaypal');">Thanh toan truc tuyen</div>
				<div class="paymentMethodBody">
					<table border="0" width="100%">
					 <tbody><tr>
						<td colspan="2">
						 <form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
checkout/payment" name="manage">
							<table width="100%">
							<tr>
								<td colspan="2" style="font-weight:bold;"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormHelp']; ?>
</td>
							</tr>
							<tr>
								<td width="150" align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCardType']; ?>
:</td>
								<td>
									<label><input type="radio" name="fcardtype" value="MasterCard" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'MasterCard'): ?>checked<?php endif; ?> /><img align="top" alt="MasterCard" title="MasterCard" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_mastercard.gif" border="1"/></label>
									&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Visa" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Visa'): ?>checked<?php endif; ?> /><img align="top" alt="Visa" title="Visa" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_visa.gif" border="1"/></label>
									&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Discover" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Discover'): ?>checked<?php endif; ?> /><img align="top" alt="Discover" title="Discover" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_discover.gif" border="1"/></label>
									&nbsp;&nbsp;&nbsp;<label><input type="radio" name="fcardtype" value="Amex" <?php if ($this->_tpl_vars['formData']['fcardtype'] == 'Amex'): ?>checked<?php endif; ?> /><img align="top" alt="Amex" title="Amex" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_amex.gif" border="1"/></label>
								</td>
							</tr>
							
							<tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormFirstname']; ?>
:</td>
								<td align="left"><input type="text" name="ffirstname" value="<?php if ($this->_tpl_vars['formData']['ffirstname'] != ''): ?><?php echo $this->_tpl_vars['formData']['ffirstname']; ?>
<?php else: ?><?php echo $this->_tpl_vars['orderInformation']['billing_firstname']; ?>
<?php endif; ?>"/></td>
							</tr>
							<tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormLastname']; ?>
:</td>
								<td align="left"><input type="text" name="flastname" value="<?php if ($this->_tpl_vars['formData']['flastname'] != ''): ?><?php echo $this->_tpl_vars['formData']['flastname']; ?>
<?php else: ?><?php echo $this->_tpl_vars['orderInformation']['billing_lastname']; ?>
<?php endif; ?>"/></td>
							</tr>
							
							<tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormZipcode']; ?>
:</td>
								<td align="left"><input type="text" name="fzipcode" value="<?php echo $this->_tpl_vars['formData']['fzipcode']; ?>
" size="5"/></td>
							</tr>
							<tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCardNumber']; ?>
:</td>
								<td align="left"><input type="text" name="fcardnumber" value="<?php echo $this->_tpl_vars['formData']['fcardnumber']; ?>
" size="30"/></td>
							</tr>
							<tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormCvv']; ?>
:</td>
								<td align="left"><input type="text" name="fcvvnumber" value="<?php echo $this->_tpl_vars['formData']['cvvnumber']; ?>
" size="5"/></td>
							</tr>
						 <tr class="directpayment_data">
								<td align="left"><?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDate']; ?>
:</td>
								<td align="left"><select name="fexpiredmonth"><option value="0">- <?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDateMonth']; ?>
 -</option><?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['monthOptions'],'selected' => $this->_tpl_vars['formData']['fexpiredmonth']), $this);?>
</select>
										<select name="fexpiredyear"><option value="0">- <?php echo $this->_tpl_vars['lang']['controller']['paymentFormExpiredDateYear']; ?>
 -</option><?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['yearOptions'],'selected' => $this->_tpl_vars['formData']['fexpiredyear']), $this);?>
</select>
								
								</td>
							</tr>
							
							<tr>
								<td></td>
								<td align="left"><input type="image" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/<?php echo $this->_tpl_vars['langCode']; ?>
/paynow_btn.gif" style="border:0;" name="submitimage" />
										<input type="hidden" name="fsubmit" value="1" />
								</td>
							</tr>
						</table>
						</form>
						</td>
						</tr>
						
					
						<tr>
                            <td width="150"></td>
                            <td align="right"><br /><div style="padding-right:70px;font-style:italic;"><?php echo $this->_tpl_vars['lang']['controller']['paymentOrLabel']; ?>
</div>
                            <form method="post" action="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
site/checkout/payment<?php if ($this->_tpl_vars['orderInformation']['invoiceid'] != ''): ?>/invoice/<?php echo $this->_tpl_vars['orderInformation']['invoiceid']; ?>
<?php endif; ?>#selectpayment"> 
                                 <input type="hidden" name="method" value="SetExpressCheckout" />
                                 <input type="hidden" name="fsubmit" value="1" />
                                    <input type="image" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/site/cardtype_paypal.gif" style="border:0;"/>
                            </form>
                            </td>
                        </tr>
						
											
					</tbody></table>		
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectCash">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectCash');">Thanh toan bang tien mat</div>
				<div class="paymentMethodBody">
					<div class="button"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=cash" title="Nhan vao day de Luu don hang"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/<?php echo $this->_tpl_vars['langCode']; ?>
/place_order_btn.gif" alt="Pay" /></a></div>
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			<div class="paymentMethodSelectGroup" id="paymentMethodSelectBank">
				<div class="paymentMethodHead" onclick="togglePaymentMethodGroup('paymentMethodSelectBank');">Goi tien qua ngan hang</div>
				<div class="paymentMethodBody">
					<div class="button"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
payment.html?pay=bank" title="Nhan vao day de Luu don hang"><img src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/<?php echo $this->_tpl_vars['langCode']; ?>
/place_order_btn.gif" alt="Pay" /></a></div>
				</div>
			</div><!-- end .paymentMethodSelectGroup -->
			
		</div>
		
		
		<?php echo '
		<script type="text/javascript">
			function togglePaymentMethodGroup(groupid)
			{
				$(\'#\' + groupid + \' .paymentMethodBody\').slideToggle();		
			}
		</script>
		'; ?>

		
		<div class="paymentMethod">
			<h2><?php echo $this->_tpl_vars['myPaymentPage']->title[$this->_tpl_vars['langCode']]; ?>
</h2>
			<div><?php echo $this->_tpl_vars['myPaymentPage']->contents[$this->_tpl_vars['langCode']]; ?>
</div>
		</div>
	
	<?php endif; ?>
</div>

<!-- / id primary --></div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."sidebar_home.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<!-- / id pageBody --></div>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => ($this->_tpl_vars['smartyControllerGroupContainer'])."footer_banner.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>