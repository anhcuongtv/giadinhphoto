<?php /* Smarty version 2.6.26, created on 2010-07-07 18:41:15
         compiled from _controller/admin/entry/topposter.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/admin/entry/topposter.tpl', 21, false),array('modifier', 'htmlspecialchars', '_controller/admin/entry/topposter.tpl', 59, false),)), $this); ?>
<h2>TOP <?php echo $this->_tpl_vars['formData']['limit']; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
[ <?php echo $this->_tpl_vars['lang']['controller']['formFromTimeLabel']; ?>
 <?php echo $this->_tpl_vars['formData']['datestart']; ?>
 - <?php echo $this->_tpl_vars['lang']['controller']['formToTimeLabel']; ?>
 <?php echo $this->_tpl_vars['formData']['dateend']; ?>
 ] </h2>

<div class="content-box"><!-- Start Content Box -->
	<div class="content-box-header">		
		<h3>TOP <?php echo $this->_tpl_vars['formData']['limit']; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
</h3>
		<ul class="content-box-tabs">
			<li><a href="#tab1" class="default-tab"><?php echo $this->_tpl_vars['lang']['controllergroup']['tableTabLabel']; ?>
</a></li> <!-- href must be unique and match the id of target div -->
			<li><a href="#tab2"><?php echo $this->_tpl_vars['lang']['controllergroup']['filterLabel']; ?>
</a></li>
		</ul>
		<ul class="content-box-link">
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
entry/topposter/limit/10"><?php echo $this->_tpl_vars['lang']['controller']['top10']; ?>
 (<?php echo $this->_tpl_vars['formData']['defaultDateStart']; ?>
 - <?php echo $this->_tpl_vars['formData']['defaultDateEnd']; ?>
)</a></li>
			<li><a href="<?php echo $this->_tpl_vars['conf']['rooturl_admin']; ?>
entry/topposter/limit/10?datestart=<?php echo $this->_tpl_vars['formData']['weekStart']; ?>
&dateend=<?php echo $this->_tpl_vars['formData']['weekEnd']; ?>
" title="<?php echo $this->_tpl_vars['lang']['controller']['formFromTimeLabel']; ?>
 <?php echo $this->_tpl_vars['formData']['weekStart']; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['formToTimeLabel']; ?>
 <?php echo $this->_tpl_vars['formData']['weekEnd']; ?>
"><?php echo $this->_tpl_vars['lang']['controller']['top10']; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['topCurWeek']; ?>
</a></li>
		</ul>
		<div class="clear"></div>  
	</div> <!-- End .content-box-header -->
	
	<div class="content-box-content">
		<div class="tab-content default-tab" id="tab1">
				<table class="grid">
					
				<?php if (count($this->_tpl_vars['posters']) > 0): ?>
					<thead>
						<tr>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formUsernameLabel']; ?>
</th>
							<th><?php echo $this->_tpl_vars['lang']['controller']['formQuantityLabel']; ?>
</th>	
							
						</tr>
					</thead>
					
					
					<tbody>
				<?php $_from = $this->_tpl_vars['posters']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['user']):
?>
					
						<tr>
							<td style="font-weight:bold;"><a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['user']->username; ?>
" target="_blank"><?php echo $this->_tpl_vars['user']->username; ?>
</a> (ID: #<?php echo $this->_tpl_vars['user']->uid; ?>
)</td>
							<td><?php echo $this->_tpl_vars['user']->postcount; ?>
</td>
						</tr>
						
					
				<?php endforeach; endif; unset($_from); ?>
				</tbody>
					
				  
				<?php else: ?>
					<tr>
						<td colspan="4"> <?php echo $this->_tpl_vars['lang']['controllergroup']['notfound']; ?>
</td>
					</tr>
				<?php endif; ?>
				
				</table>
			</form>
	
		</div>
		
		<div class="tab-content" id="tab2">
			<form action="" method="post" style="padding:0px;margin:0px;" onsubmit="return false;">
	
				<?php echo $this->_tpl_vars['lang']['controller']['formTopLimitLabel']; ?>
: 
				<input type="text" name="flimit" id="flimit" size="4" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['limit']); ?>
" class="text-input" /> - 
				<?php echo $this->_tpl_vars['lang']['controller']['formFromTimeLabel']; ?>
: 
				<input type="text" name="fdatestart" id="fdatestart" size="8" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['datestart']); ?>
" class="text-input" /> - 
				<?php echo $this->_tpl_vars['lang']['controller']['formToTimeLabel']; ?>
: 
				<input type="text" name="fdateend" id="fdateend" size="8" value="<?php echo htmlspecialchars($this->_tpl_vars['formData']['dateend']); ?>
" class="text-input" /> - 
				
								
				<input type="button" name="fsubmit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['filterSubmit']; ?>
" class="button" onclick="gosearchposter();"  />
		
			</form>
		</div>
		
		
	
	</div>
	

    	
</div>

<?php echo '
<script type="text/javascript">
	function gosearchposter()
	{
		var path = rooturl_admin + "entry/topposter";
		
		var limit = $("#flimit").val();
		if(parseInt(limit) > 0)
		{
			path += "/limit/" + limit;
		}
		path += \'?\';
		
		var datestart = $("#fdatestart").val();
		if(datestart.length > 0)
		{
			path += "datestart=" + datestart;
		}
		
		var dateend = $("#fdateend").val();
		if(dateend.length > 0)
		{
			path += "&dateend=" + dateend;
		}
		
				
				
		document.location.href= path;
	}
</script>
'; ?>



