<?php /* Smarty version 2.6.26, created on 2010-07-15 21:13:33
         compiled from _controller/site/entrycomment.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entrycomment.tpl', 1, false),array('modifier', 'default', '_controller/site/entrycomment.tpl', 17, false),array('modifier', 'date_format', '_controller/site/entrycomment.tpl', 27, false),array('modifier', 'relative_datetime', '_controller/site/entrycomment.tpl', 27, false),array('modifier', 'nl2br', '_controller/site/entrycomment.tpl', 30, false),)), $this); ?>
<?php $this->assign('commentCount', count($this->_tpl_vars['myEntry']->comments)); ?>
<div id="comment">
	<div class="head">
		<div class="headleft"><?php if ($this->_tpl_vars['commentCount'] > 0): ?><?php echo count($this->_tpl_vars['myEntry']->comments); ?>
 <?php echo $this->_tpl_vars['lang']['controller']['commentHeadLabel']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controller']['commentEmptyLabel']; ?>
<?php endif; ?> “<?php echo $this->_tpl_vars['myEntry']->title; ?>
”</div>
		<div class="headright"><a<?php if ($this->_tpl_vars['me']->id > 0): ?> href="javascript:void(0);" onclick="javascript:$('#fcomment').focus();"<?php else: ?> href="#commentbox"<?php endif; ?> title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentWrite']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/comment_add.png" border="0" alt="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentWrite']; ?>
" /></a></div>
	</div>
	<ul class="commentlist">
		<?php $_from = $this->_tpl_vars['myEntry']->comments; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['comment']):
?>
			<li id="li-comment-<?php echo $this->_tpl_vars['comment']->id; ?>
" class="comment even thread-even depth-1 clearfix">
				<div id="comment-<?php echo $this->_tpl_vars['comment']->id; ?>
">
					<a name="comment-<?php echo $this->_tpl_vars['comment']->id; ?>
" title="comment"></a>
					<div class="comment-meta commentmetadata clearfix">
						<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['comment']->sender->username; ?>
" title="<?php echo $this->_tpl_vars['comment']->sender->username; ?>
">
						 	<img width="36" height="36" class="avatar avatar-36 photo" src="<?php if ($this->_tpl_vars['comment']->sender->avatar == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noavatar-small.png<?php else: ?><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['avatar']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['comment']->sender->thumbImage(); ?>
<?php endif; ?>" alt="<?php echo $this->_tpl_vars['comment']->sender->username; ?>
" />
						</a>
						<span> 
							<?php if ($this->_tpl_vars['me']->id > 0): ?><a class="reportabuse" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
reportabuse.html?type=<?php echo ((is_array($_tmp=@$this->_tpl_vars['reportabusetype'])) ? $this->_run_mod_handler('default', true, $_tmp, 'entrycomment') : smarty_modifier_default($_tmp, 'entrycomment')); ?>
&id=<?php echo $this->_tpl_vars['comment']->id; ?>
" rel="shadowbox;width=500;height=250" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_report.gif" alt="report" /> <?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
</a><?php endif; ?>
							<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['comment']->sender->username; ?>
" title="<?php echo $this->_tpl_vars['comment']->sender->username; ?>
"><strong><?php echo $this->_tpl_vars['comment']->sender->username; ?>
</strong></a>
							
							 
							<?php if ($this->_tpl_vars['comment']->canModify()): ?><a class="delete" href="javascript:delm('<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/commentdelete/<?php echo $this->_tpl_vars['comment']->id; ?>
?commenttoken=<?php echo $_SESSION['commentToken']; ?>
')" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentDelete']; ?>
">[<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentDelete']; ?>
]</a><?php endif; ?> 
							
							
							
							
							
							<br><span title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentPostAt']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['comment']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M, %B %e, %Y") : smarty_modifier_date_format($_tmp, "%H:%M, %B %e, %Y")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['comment']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span>
						</span>
						<div class="text">
							<p><?php echo ((is_array($_tmp=$this->_tpl_vars['comment']->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</p>
						</div>
					</div>
					
					<?php if (count($this->_tpl_vars['comment']->replies) > 0): ?>
					<ul class="children">
						<?php $_from = $this->_tpl_vars['comment']->replies; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['reply']):
?>
						   <li id="li-comment-<?php echo $this->_tpl_vars['reply']->id; ?>
" class="comment byuser comment-author-admin bypostauthor odd alt depth-2 clearfix">
						
							 <div id="comment-<?php echo $this->_tpl_vars['reply']->id; ?>
">
							 	<a name="comment-<?php echo $this->_tpl_vars['comment']->id; ?>
" title="comment"></a>
							  	<div class="comment-meta commentmetadata clearfix">
									<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['reply']->sender->username; ?>
" title="<?php echo $this->_tpl_vars['reply']->sender->username; ?>
">
										<img width="36" height="36" class="avatar avatar-36 photo" src="<?php if ($this->_tpl_vars['reply']->sender->avatar == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noavatar-small.png<?php else: ?><?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['avatar']['imageDirectory']; ?>
<?php echo $this->_tpl_vars['reply']->sender->thumbImage(); ?>
<?php endif; ?>" alt="<?php echo $this->_tpl_vars['reply']->sender->username; ?>
" />
									</a>
									<span> 
										<?php if ($this->_tpl_vars['me']->id > 0): ?><a class="reportabuse" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
reportabuse.html?type=<?php echo ((is_array($_tmp=@$this->_tpl_vars['reportabusetype'])) ? $this->_run_mod_handler('default', true, $_tmp, 'entrycomment') : smarty_modifier_default($_tmp, 'entrycomment')); ?>
&id=<?php echo $this->_tpl_vars['comment']->id; ?>
" rel="shadowbox;width=500;height=250" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_report.gif" /> <?php echo $this->_tpl_vars['lang']['controllergroup']['abuseText']; ?>
</a><?php endif; ?>
										<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['reply']->sender->username; ?>
" title="<?php echo $this->_tpl_vars['reply']->sender->username; ?>
"><strong><?php echo $this->_tpl_vars['reply']->sender->username; ?>
</strong></a>
										<?php if ($this->_tpl_vars['reply']->canModify()): ?><a class="delete" href="javascript:delm('<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
/commentdelete/<?php echo $this->_tpl_vars['reply']->id; ?>
?commenttoken=<?php echo $_SESSION['commentToken']; ?>
')" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentDelete']; ?>
">[<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentDelete']; ?>
]</a><?php endif; ?> 
										
										<br><span title="<?php echo ((is_array($_tmp=$this->_tpl_vars['reply']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%B %e, %Y") : smarty_modifier_date_format($_tmp, "%B %e, %Y")); ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentPostBy']; ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['reply']->datecreated)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['reply']->datecreated)) ? $this->_run_mod_handler('relative_datetime', true, $_tmp) : smarty_modifier_relative_datetime($_tmp)); ?>
</span>
									</span>
									<div class="text">
										<p><?php echo ((is_array($_tmp=$this->_tpl_vars['reply']->content)) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>
</p>
									</div>
								</div>
							</div>
						  </li>
						<?php endforeach; endif; unset($_from); ?>
					</ul>
					<?php endif; ?>
				
					<div class="reply">
        		 		<a title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentReplyToTooltip']; ?>
 <?php echo $this->_tpl_vars['comment']->sender->username; ?>
"<?php if ($this->_tpl_vars['me']->id > 0): ?> onclick="entryCommentReply(<?php echo $this->_tpl_vars['comment']->id; ?>
)" href="javascript:void(0)"<?php else: ?> href="#commentbox"<?php endif; ?> class="comment-reply-link" rel="nofollow"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentReply']; ?>
</a>      
					</div>
				</div>
				
			</li><!-- end of .comment -->
		<?php endforeach; endif; unset($_from); ?>	
	</ul><!-- end of .comment-list -->
	
	
	
	<form id="commentform" method="post" action="<?php echo $this->_tpl_vars['myEntry']->getFullSeoUrl(); ?>
#commentbox">
		<input type="hidden" name="ftoken" value="<?php echo $_SESSION['commentToken']; ?>
" />
		<a name="commentbox" title="commentbox"></a>
		<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "notify.tpl", 'smarty_include_vars' => array('notifyError' => $this->_tpl_vars['error'],'notifySuccess' => $this->_tpl_vars['success'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
		<p><label for="comment"><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentWrite']; ?>
 :</label></p>
		<?php if ($this->_tpl_vars['me']->id > 0): ?>
			<p><textarea tabindex="4" rows="10" cols="100%" id="fcomment" name="fcomment"><?php echo $_POST['fcomment']; ?>
</textarea></p>
			<p><input type="submit" class="form-button-submit" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentSubmit']; ?>
" tabindex="5" id="submit" name="fsubmitcomment">
			<input type="hidden" value="<?php echo ((is_array($_tmp=@$_POST['fcommentparent'])) ? $this->_run_mod_handler('default', true, $_tmp, 0) : smarty_modifier_default($_tmp, 0)); ?>
" id="fcommentParent" name="fcommentparent">
			</p>
		<?php else: ?>
			<p><em><?php echo $this->_tpl_vars['lang']['controllergroup']['entryCommentLoginRequired']; ?>
 : (<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
login.html?redirect=<?php echo $this->_tpl_vars['redirectUrlComment']; ?>
" title="<?php echo $this->_tpl_vars['lang']['global']['mLogin']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mLogin']; ?>
</a> | <a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
register.html?redirect=<?php echo $this->_tpl_vars['redirectUrlComment']; ?>
" title="<?php echo $this->_tpl_vars['lang']['global']['mRegisterLong']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mRegister']; ?>
</a>)</em></p>
		<?php endif; ?>
	</form>


</div><!-- end of #comment -->

