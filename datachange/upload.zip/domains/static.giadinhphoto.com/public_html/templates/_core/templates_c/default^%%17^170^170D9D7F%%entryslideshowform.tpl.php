<?php /* Smarty version 2.6.26, created on 2010-07-16 23:36:56
         compiled from _controller/site/entryslideshowform.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entryslideshowform.tpl', 62, false),)), $this); ?>
<script type="text/javascript">
				
	var shash = '<?php echo session_id(); ?>';
	var langAddCaption = '<?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowAddCaptionLabel']; ?>
';
	
	<?php echo '
	

			var swfu;
	
			
		
			window.onload = function() {
				var settings = {
					flash_url : "'; ?>
<?php echo $this->_tpl_vars['currentTemplate']; ?>
<?php echo '" + "/js/swfupload.swf",
					upload_url:  "'; ?>
<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo '" + "photo-upload",
					post_params: {"SHASH" : shash},
					file_size_limit : "100 MB",
					file_types : "*.jpg;*.png;*.gif",
					file_types_description : "Image Files",
					file_upload_limit : 100,
					file_queue_limit : 0,
					custom_settings : {
						progressTarget : "fsUploadProgress",
						cancelButtonId : "btnCancel"
					},
					debug: false,
	
					// Button settings
					button_image_url: currentTemplate + "/images/swfupload-button-100x22.png",
					button_width: "100",
					button_height: "22",
					button_placeholder_id: "spanButtonPlaceholder",
	
					
					// The event handler functions are defined in handlers.js
					file_queued_handler : fileQueued,
					file_queue_error_handler : fileQueueError,
					file_dialog_complete_handler : fileDialogComplete,
					upload_start_handler : uploadStart,
					upload_progress_handler : uploadProgress,
					upload_error_handler : uploadError,
					upload_success_handler : uploadSuccess,
					upload_complete_handler : uploadComplete,
					queue_complete_handler : queueComplete	// Queue plugin event
				};
	
				swfu = new SWFUpload(settings);
			 };
	
		
		
	'; ?>

	//]]>
		
		</script>


<div class="form-entry">
					<div class="form-entry-label form-entry-label-normalfont form-entry-label-small"><label><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShow']; ?>
 :</label></div>
					<div>
						<?php if (count($this->_tpl_vars['myEntry']->photos) > 0): ?>
							<div class="form-entry-photos">
								<?php $_from = $this->_tpl_vars['myEntry']->photos; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['photo']):
?>
									<div class="progressContainer blue"><div class="form-entry-photo-delete"><label><input type="checkbox" name="fdeletephoto[<?php echo $this->_tpl_vars['photo']->id; ?>
]" value="1" /><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowDelete']; ?>
</label></div><div class="progressImageHolder"><a rel="shadowbox[slideshow]" href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['photo']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['photo']->filepath; ?>
" title="<?php echo $this->_tpl_vars['photo']->filepath; ?>
"><img border="0" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['photo']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['photo']->filepathSmall; ?>
" alt="<?php echo $this->_tpl_vars['photo']->filepathSmall; ?>
"></a></div><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowAddCaptionLabel']; ?>
: <br><input type="text" value="<?php echo $this->_tpl_vars['photo']->caption; ?>
" name="fcurrentcaption[<?php echo $this->_tpl_vars['photo']->id; ?>
]" class="text-input progressCaption"><div class="progressBarComplete" style=""></div></div>
								<?php endforeach; endif; unset($_from); ?>
							</div>
						<?php endif; ?>
						<div class="form-entry-slideshow-toggle"><a href="javascript:void(0)" onclick="$('.form-entry-slideshow').show();$('.form-entry-slideshow-toggle').hide();" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowAdd']; ?>
"><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowAdd']; ?>
</a></div>
						<div id="divSWFUploadUI" class="form-entry-slideshow" style="display:none;">
							<div class="fieldset flash" id="fsUploadProgress">
								<span class="legend myTip" onclick="$('.form-entry-slideshow').hide();$('.form-entry-slideshow-toggle').show();"><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowAdd']; ?>
 <span class="form-entry-slideshow-help"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/icon_help.gif" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowHelp']; ?>
" class="myTip" alt="help" /></span></span>
								
								<p>
									<span id="spanButtonPlaceholder"></span>
									<input id="btnCancel" type="button" value="<?php echo $this->_tpl_vars['lang']['controllergroup']['entrySlideShowCancelAllUpload']; ?>
" disabled="disabled" style="margin-left: 2px; height: 22px; font-size: 8pt;" />
									<br />
								</p>
								<p id="divStatus" style="display:none;">0 Files Uploaded</p>
							</div>
							
						</div>
					
					</div>
				</div>