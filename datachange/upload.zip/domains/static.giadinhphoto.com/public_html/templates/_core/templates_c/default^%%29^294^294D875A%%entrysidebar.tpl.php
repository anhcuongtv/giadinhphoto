<?php /* Smarty version 2.6.26, created on 2010-07-15 22:49:15
         compiled from _controller/site/entrysidebar.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'count', '_controller/site/entrysidebar.tpl', 17, false),array('modifier', 'strip_tags', '_controller/site/entrysidebar.tpl', 30, false),array('modifier', 'truncate', '_controller/site/entrysidebar.tpl', 30, false),array('modifier', 'escape', '_controller/site/entrysidebar.tpl', 30, false),array('function', 'gettopquiz', '_controller/site/entrysidebar.tpl', 111, false),)), $this); ?>
<div id="sidebar1">
	<?php if ($this->_tpl_vars['action'] == 'add' || $this->_tpl_vars['action'] == 'edit'): ?>
		<div id="entry-addbutton">
			<a href="<?php echo $this->_tpl_vars['backUrl']; ?>
" title="Back"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/entry-back-button.png" border="0" alt="back" /></a>
		</div>
		<?php if ($this->_tpl_vars['action'] == 'edit'): ?>
			<div id="entry-addbutton">
				<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/add<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['addEntryTitle']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/entry-add-button.png" border="0" /></a>
			</div>	
		<?php endif; ?>
	<?php else: ?>
		<div id="entry-addbutton">
			<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/add<?php if ($this->_tpl_vars['redirectUrl'] != ''): ?>/redirect/<?php echo $this->_tpl_vars['redirectUrl']; ?>
<?php endif; ?>" title="<?php echo $this->_tpl_vars['lang']['controllergroup']['addEntryTitle']; ?>
"><img src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/entry-add-button.png" border="0" alt="add" /></a>
		</div>
	<?php endif; ?>
	
	<?php if (count($this->_tpl_vars['sameCategoryEntries']) > 0): ?>
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-blue">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySameCategoryLabel']; ?>
</div>
		</div>
		<div class="sidebar-box-body">
			<?php $_from = $this->_tpl_vars['sameCategoryEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
			<div class="sidebar-entry">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->view; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewTooltip']; ?>
"><?php echo $this->_tpl_vars['entry']->view; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						
					</div>
				</div>
				
			</div>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="sidebar-box-foot">
			<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/topview" title="<?php echo $this->_tpl_vars['myCategory']->name; ?>
<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingTopview']; ?>
"><?php echo $this->_tpl_vars['myCategory']->name; ?>
 &raquo;</a>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if (count($this->_tpl_vars['topRatingEntries']) > 0): ?>
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-blue">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['entryTopRatingLabel']; ?>
</div>
		</div>
		<div class="sidebar-box-body">
			<?php $_from = $this->_tpl_vars['topRatingEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
			<div class="sidebar-entry">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
[<?php echo $this->_tpl_vars['entry']->getCategoryName(); ?>
]"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->view; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewTooltip']; ?>
"><?php echo $this->_tpl_vars['entry']->view; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						
					</div>
				</div>
				
			</div>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="sidebar-box-foot">
			<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['parentCategory']->id > 0): ?><?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/<?php endif; ?><?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/toprate" title="<?php echo $this->_tpl_vars['myCategory']->name; ?>
<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingToprate']; ?>
"><?php echo $this->_tpl_vars['myCategory']->name; ?>
 &raquo;</a>
		</div>
	</div>
	<?php endif; ?>
	
	<?php if (count($this->_tpl_vars['sameParentCategoryEntries']) > 0): ?>
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-pink">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['entrySameParentCategoryLabel']; ?>
</div>
		</div>
		<div class="sidebar-box-body">
			<?php $_from = $this->_tpl_vars['sameParentCategoryEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
			<div class="sidebar-entry">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
[<?php echo $this->_tpl_vars['entry']->getCategoryName(); ?>
]"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->view; ?>
 <?php echo $this->_tpl_vars['lang']['controllergroup']['entryViewTooltip']; ?>
"><?php echo $this->_tpl_vars['entry']->view; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						
					</div>
				</div>
				
			</div>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="sidebar-box-foot">
			<?php if ($this->_tpl_vars['myCategory']->parentid > 0): ?>
				<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['parentCategory']->identifier; ?>
/topview" title="<?php echo $this->_tpl_vars['parentCategory']->name; ?>
<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingTopview']; ?>
"><?php echo $this->_tpl_vars['parentCategory']->name; ?>
 &raquo;</a>
			<?php else: ?>
				<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['myCategory']->identifier; ?>
/topview" title="<?php echo $this->_tpl_vars['myCategory']->name; ?>
<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingTopview']; ?>
"><?php echo $this->_tpl_vars['myCategory']->name; ?>
 &raquo;</a>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
	
	<?php echo smarty_function_gettopquiz(array('var' => 'topPlayEntries'), $this);?>

	<?php if (count($this->_tpl_vars['topPlayEntries']) > 0): ?>
	<div class="sidebar-box">
		<div class="sidebar-box-head sidebar-box-head-green">
			<div><?php echo $this->_tpl_vars['lang']['controllergroup']['quizTopPlay']; ?>
</div>
		</div>
		<div class="sidebar-box-body">
			<?php $_from = $this->_tpl_vars['topPlayEntries']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['entry']):
?>
			<div class="sidebar-entry">
				<div class="image">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" title="<?php echo $this->_tpl_vars['entry']->title; ?>
"><img alt="<?php echo $this->_tpl_vars['entry']->title; ?>
" src="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php if ($this->_tpl_vars['entry']->image == ''): ?><?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/noimage-small.png<?php else: ?><?php echo $this->_tpl_vars['entry']->uploadImageDirectory; ?>
<?php echo $this->_tpl_vars['entry']->getSmallImage(); ?>
<?php endif; ?>" /></a>
					
				</div>
				<div class="title">
					<a href="<?php echo $this->_tpl_vars['entry']->getFullSeoUrl(); ?>
" class="myTip" title="<?php echo ((is_array($_tmp=((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['entry']->description)) ? $this->_run_mod_handler('strip_tags', true, $_tmp) : smarty_modifier_strip_tags($_tmp)))) ? $this->_run_mod_handler('truncate', true, $_tmp, 200, '..') : smarty_modifier_truncate($_tmp, 200, '..')))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo $this->_tpl_vars['entry']->title; ?>
</a>
					<span class="bubble" title="<?php echo $this->_tpl_vars['entry']->play; ?>
 <?php echo $this->_tpl_vars['lang']['controller']['playCountLabel']; ?>
"><?php echo $this->_tpl_vars['entry']->play; ?>
</span>
					<div class="rating">
						<img alt="rate-<?php echo $this->_tpl_vars['entry']->rating; ?>
" title="<?php if ($this->_tpl_vars['entry']->rating == 0): ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRatingNotSet']; ?>
<?php else: ?><?php echo $this->_tpl_vars['lang']['controllergroup']['entryRating']; ?>
 : <?php echo $this->_tpl_vars['entry']->rating; ?>
<?php endif; ?>" src="<?php echo $this->_tpl_vars['currentTemplate']; ?>
/images/rating/heart-rating-<?php echo $this->_tpl_vars['entry']->getRoundRating(); ?>
.png" />
						
					</div>
				</div>
				
			</div>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<div class="sidebar-box-foot">
			<a href="<?php echo $this->_tpl_vars['conf']['rooturl']; ?>
<?php echo $this->_tpl_vars['setting']['quiz']['seoUrl']; ?>
/topplay" title="<?php echo $this->_tpl_vars['lang']['global']['mQuiz']; ?>
<?php echo $this->_tpl_vars['lang']['controllergroup']['seoTitlePaddingTopplay']; ?>
"><?php echo $this->_tpl_vars['lang']['global']['mQuiz']; ?>
 &raquo;</a>
			
		</div>
	</div>
	<?php endif; ?>
	
	
	
</div><!-- end of #sidebar1 -->

