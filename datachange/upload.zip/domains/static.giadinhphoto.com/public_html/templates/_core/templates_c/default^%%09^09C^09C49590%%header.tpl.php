<?php /* Smarty version 2.6.26, created on 2013-10-24 15:06:08
         compiled from _mail/site/header.tpl */ ?>

<div style="line-height:2;background:#67b718;padding:30px;"><!-- container -->
	<div style="padding:20px; background:#fff;">