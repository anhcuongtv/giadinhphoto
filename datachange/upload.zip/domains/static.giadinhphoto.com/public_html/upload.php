<?php
	
	/**
	* File dac biet, dung de standalone xu ly upload image len remote server (truong hop nay la upload len 1 server vietnam)
	* 
	*/
	
	include('setting.php');
	include('classes/class.imageresizer.php');
	include('classes/class.helper.php');
	include('classes/class.uploader.php');
	$mainsiteCombackUrl = 'http://giadinhphotocontest.com/memberarea.html?tab=upload&submitreturn=1';
	

	//xoa file vi request to main server
	if(isset($_GET['delete']))
	{
		//check valid token to not delete wrong image ^^
		$uid = (int)$_GET['uid'];
		$sessionid = $_GET['sid'];
		$fileserver = $_GET['fileserver'];
		$filepath = base64_decode($_GET['filepath']);
		$filethumb1 = base64_decode($_GET['filethumb1']);
		$filethumb2 = base64_decode($_GET['filethumb2']);
		$token = $_GET['token'];
		
		if($token == calculateSecurityToken($uid, $sessionid, $fileserver . $filepath . $filethumb1 . $filethumb2))
		{
			//start delete 3 files
			@unlink($setting['contestphoto']['imageDirectory'] . $filepath);
			@unlink($setting['contestphoto']['imageDirectory'] . $filethumb1);
			@unlink($setting['contestphoto']['imageDirectory'] . $filethumb2);
		}
		
		//after delete file, return to mainsite
		header('location: ' . $mainsiteCombackUrl);
		die();
	}
	
	
	
	////////////////////////////////////////////////////////////////
	//
	//checking request from user before upload file
	//for security, because must check valid user upload session from original server
	$uid = (int)$_POST['uid'];
	$sessionid = $_POST['sid'];
	$token = $_POST['token'];
	$error = '';
	
	if($token != calculateSecurityToken($uid, $sessionid))
	{
		$error = 'token';
	}
	//end check security -->
	
	
	//////////////////////////////////////////
	//
	//check form submit (name,filesize,type)
	$filename = $_FILES['fimage']['name'];
	
	$ext = strtoupper(substr($filename, strrpos($filename, '.') + 1));
	$fileserver = 'vn';
	$filepath = '';
	$filethumb1 = '';
	$filethumb2 = '';
	$filesizeinbyte = $_FILES['fimage']['size'];
	$width = 0;
	$height = 0;

	
	if($filename == '')
	{
		$error = 'empty';
	}
	elseif($filesizeinbyte > $setting['contestphoto']['maxFileSize'])
	{
		$error = 'size';
	}
	elseif(!in_array($ext, $setting['contestphoto']['validType']))
	{
		$error = 'type';
	}
	elseif(trim($_POST['fsection']) == '')
	{
		$error = 'section';
	}
	elseif(trim($_POST['fname']) == '')
	{
		$error = 'name';
	}
	else
	{
		//check landscape image or portrait
		$imageinfo = getimagesize($_FILES['fimage']['tmp_name']);
		$width = $imageinfo[0];
		$height = $imageinfo[1];
		
		//padding image with image's width
		$namePadding = '';
		if($imageinfo[0] < $imageinfo[1])
		{
			//it's portrait image, padding _p after image
			$namePadding = '_p';
		}
		else
		{
			//it's landscape image, padding _l after image
			$namePadding = '_l';
		}
		
		
		$curDateDir = Helper::getCurrentDateDirName(); 
		$extPart = strtolower(substr(strrchr($_FILES['fimage']['name'],'.'),1));
		$namePart =  $uid . '-' . Helper::codau2khongdau( $_POST['fname'], true)  . '-' . Helper::RandomNumber(1000,9999) . '-' . strtoupper($_POST['fsection'][0]);
		$name = $namePart . $namePadding . '.' . $extPart;
		
		$uploader = new Uploader($_FILES['fimage']['tmp_name'], $name, $setting['contestphoto']['imageDirectory'] . $curDateDir, '', $setting['contestphoto']['validType']);
		
		$uploadError = $uploader->upload(false, $name);
		if($uploadError != Uploader::ERROR_UPLOAD_OK)
		{
			$error = 'upload';
		}
		else
		{
			//Create thum 1 image
			$nameThumb1 = $uid . '-' . Helper::codau2khongdau( $_POST['fname'], true) . '-thumb1-' . Helper::RandomNumber(1000,9999) . '-' . strtoupper($_POST['fsection'][0]) . $namePadding . '.' . $extPart;
			$myImageResizer = new ImageResizer(	$setting['contestphoto']['imageDirectory'] . $curDateDir, $name, 
												$setting['contestphoto']['imageDirectory'] . $curDateDir, $nameThumb1, 
												$setting['contestphoto']['imageThumb1Width'], 
												$setting['contestphoto']['imageThumb1Height'], 
												'', 
												$setting['contestphoto']['imageQuality']);
			$myImageResizer->output();	
			unset($myImageResizer);
			
			//Create thum 2 image
			$nameThumb2 = $uid . '-' . Helper::codau2khongdau( $_POST['fname'], true) . '-thumb2-' . Helper::RandomNumber(1000,9999) . '-' . strtoupper($_POST['fsection'][0]) . $namePadding . '.' . $extPart;
			$myImageResizer = new ImageResizer(	$setting['contestphoto']['imageDirectory'] . $curDateDir, $name, 
												$setting['contestphoto']['imageDirectory'] . $curDateDir, $nameThumb2, 
												$setting['contestphoto']['imageThumb2Width'], 
												$setting['contestphoto']['imageThumb2Height'], 
												'1:1', 
												$setting['contestphoto']['imageQuality']);
			$myImageResizer->output();	
			unset($myImageResizer);
			
			//update database
			$filepath = $curDateDir . $name;
			$filethumb1 = $curDateDir . $nameThumb1;
			$filethumb2 = $curDateDir . $nameThumb2;
		}
	}

	////////////////////////////////////////
	//	OUTPUT FORM
	if($error == '')
	{
		//echo $fileserver . $filepath . $filethumb1 . $filethumb2 . $filesizeinbyte . $width . $height;
		//redirect to show error
		echo '
			<html>
				<head><title>Uploading image...</title></head>
				<script type="text/javascript">
				function submitForm(){
					document.getElementById("submitbutton").style.visibility="hidden"; // hide
					document.form.submit();
				 	
				}
				</script>
				<body onload="submitForm()">
				<form method="post" name="form" action="'.$mainsiteCombackUrl.'">
					<input type="hidden" name="fsubmitphotoremote" value="1">
					<input type="hidden" name="fsection" value="'.$_POST['fsection'].'">
					<input type="hidden" name="fname" value="'.$_POST['fname'].'">
					<input type="hidden" name="fdescription" value="'.$_POST['fdescription'].'">
					<input type="hidden" name="ffileserver" value="'.$fileserver.'">
					<input type="hidden" name="ffilepath" value="'.$filepath.'">
					<input type="hidden" name="ffilethumb1" value="'.$filethumb1.'">
					<input type="hidden" name="ffilethumb2" value="'.$filethumb2.'">
					<input type="hidden" name="ffilesizeinbyte" value="'.$filesizeinbyte.'">
					<input type="hidden" name="fwidth" value="'.$width.'">
					<input type="hidden" name="fheight" value="'.$height.'">
					<input type="hidden" name="ftoken" value="'.calculateSecurityToken($uid, $sessionid, $fileserver . $filepath . $filethumb1 . $filethumb2 . $filesizeinbyte . $width . $height).'">
					<input type="submit" id="submitbutton" name="fsubmitphotoremote" value="Next">
				</form>
				</body>
			</html>
		
		';
	}
	else
	{
		header('location: ' . $mainsiteCombackUrl . '&error=' . $error);
	}
	
	
	/**
	* Thuan toan tuong tu nhu phia server goc, de check tinh hop le cua request
	* 
	* @param mixed $uid
	* @param mixed $sessionid
	*/
	function calculateSecurityToken($uid, $sessionid, $morestring = '')
	{
		return md5($uid . 'vdt234234sdfsf3234234' . $sessionid . 'c234234234hk' . $morestring);
	}
	
	
?>